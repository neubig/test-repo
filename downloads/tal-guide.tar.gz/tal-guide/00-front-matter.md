# Front Matter

## Title Page

**TAL Programmer's Guide**

**Languages Library**

### Publication Information

- **Part Number**: 096254
- **Edition**: Second
- **Published**: September 1993
- **Product Version**: TAL C30, TAL D10, TAL D20
- **Release ID**: D20.00
- **Supported Releases**: This manual supports C30/D10.00 and all subsequent releases until otherwise indicated in a new edition.

### Abstract

This manual provides usage information for TAL (Transaction Application Language) and the TAL compiler for system and application programmers.

---

## Document History

| Edition | Part Number | Product Version | Earliest Supported Release | Published |
|---------|-------------|-----------------|---------------------------|-----------|
| First | 065721 | TAL D10 | N/A | January 1993 |
| Second | 096254 | TAL C30, TAL D10, TAL D20 | C30/D10.00 | September 1993 |

New editions incorporate any updates issued since the previous edition. A plus sign (+) after a release ID indicates that this manual describes function added to the base release, either by an interim product modification (IPM) or by a product update tape (PUT).

---


## Additional Front Matter

Languages Library
TAL
Programmer’sGuide
Abstract This manual provides usage information for TAL (Transaction Application Language) and the TAL
compiler for system and application programmers.
Part Number 096254
Edition Second
Published September 1993
Product Version TAL C30, TAL D10, TAL D20
Release ID D20.00
Supported Releases This manual supports C30/D10.00 and all subsequent releases until otherwise indicated in a new
edition.

Document History Edition Part Number Product Version Earliest Supported Release Published
First 065721 TAL D10 N/A January 1993
Second 096254 TAL C30
TAL D10TAL D20C30/D10.00 September 1993
New editions incorporate any updates issued since the previous edition.
A plus sign (+) after a release ID indicates that this manual describes function added to the base release,
either by an interim product modification (IPM) or by a new product version on a .99 site update tape (SUT).
Copyright Copyright © 1993 by Tandem Computers Incorporated. Printed in the U.S.A. All rights reserved. No part of this
document may be reproduced in any form, including photocopying or translation to another language, withoutthe prior written consent of Tandem Computers Incorporated.
Export Statement Export of the information contained in this manual may require authorization from the U. S. Department of
Commerce.
Examples Examples and sample programs are for illustration only and may not be suited for your particular purpose.
Tandem does not warrant, guarantee, or make any representations regarding the use or the results of the useof any examples or sample programs in any documentation. You should verify the applicability of any exampleor sample program before placing the software into productive use.
Ordering Information For manual ordering information:  Domestic U.S. customers, call 1-800-243-6886; international customers,
contact your local sales representative.

New and Changed Information
096254 Tandem Computers Incorporated iiiThe TAL Programmer’s Guide  gives guidelines for using TAL.  This edition incorporates
new features introduced in the D20 release and corrects text in response to readercomment forms.
This edition includes the following new features:
For INT, REAL, and UNSIGNED data types and parameter types, a width
argument can consist of any constant expression, including LITERALs andDEFINEs.
FIXED( *) is now a data type and a parameter type.
A variable can have the same identifier as the encompassing BLOCK declaration.
In addition to the implicit block named #GLOBAL, TAL creates an  implicit block
for each template structure declared outside a BLOCK declaration.
The compiler ignores extra commas in, or adjacent to, procedure attribute lists.
In CALL statements, the CALL keyword is optional.
The RETURN statement lets you specify a condition-code value and a returnexpression.
$OPTIONAL, a new standard function, lets you conditionally pass parameters toVARIABLE and EXTENSIBLE procedures.
DEFINETOG, a new directive, lets you create named and numeric toggles.  Itleaves new toggles turned off but does not change the settings of existing toggles.
The IF, IFNOT, and ENDIF directives now support named toggles.
The operating system for Tandem NonStop systems, formerly called the Guardian
operating system, is now called the Tandem NonStop Kernel.  This change reflectsTandem's current and future operating system enhancements that further enable opensystems and application portability.

New and Changed Information
iv 096254 Tandem Computers Incorporated

Contents
096254 Tandem Computers Incorporated vAbout This Manual xxv
Notation Conventions    xxxiii
Section 1 Introducing TAL
Using TAL    1-1Major Features    1-1System Services    1-3System Procedures    1-3TAL Run-Time Library    1-3CRE Services    1-3
Section 2 Getting Started
Sample Source File    2-1Creating Source Files    2-2
Compiler Directives    2-2System Procedures    2-3Procedures    2-3Data Declarations    2-3Statements    2-4Comments    2-4
Compiling Source Files    2-4Running Programs    2-5
Section 3 Structuring Programs
Source Files    3-1Compilation Units    3-1
Structuring Compilation Units    3-1Order of Components    3-3
Naming Compilation Units    3-4Declaring Data    3-4Declaring Global Data    3-5
Declaring Unblocked Global Data    3-5Declaring Blocked Global Data    3-5

Contents
vi 096254 Tandem Computers IncorporatedDeclaring Procedures    3-6
Procedure Heading    3-6Procedure Body    3-6FORWARD Procedures    3-6EXTERNAL Procedures    3-7Procedure Entry Points    3-7Local Data    3-8Local Labels    3-8Local Statements    3-8
Declaring Subprocedures    3-10
Subprocedure Heading    3-10Subprocedure Body    3-10FORWARD Subprocedures    3-10Subprocedure Entry Points    3-11Sublocal Data    3-12Sublocal Labels    3-12Sublocal Statements    3-12
Formatting Programs    3-13
Formatting With Comments    3-14Formatting With BEGIN-END Constructs    3-16Using Semicolons    3-17
Using Compiler Directives    3-18
Section 4 Introducing the Env