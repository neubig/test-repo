# Glossary

Glossary
096254 Tandem Computers Incorporated Glossary–1actual parameter.   An argument that a calling procedure or subprocedure passes to a
called procedure or subprocedure.
addressing mode.   The mode in which a variable is to be accessed—direct addressing,
standard indirect addressing, or extended indirect addressing—as specified in the datadeclaration.
AND.   A Boolean operator that produces a true state if both adjacent conditions are true.
arithmetic expression.   An expression that computes a single numeric value.
array.   A variable that represents a collectively stored set of elements of the same data
type.
ASSERT statement.   A statement that conditionally calls an error-handling procedure.
assignment expression.   An expression that stores a value in a variable.
assignment statement.   A statement that stores a value in a variable.
ASSIGN Command.   A TACL command that lets you associate a logical file name with a
Tandem file name.  The Tandem file name is a fully qualified file ID.  See “file name”and “file ID.”
ASSIGN SSV Command.   A TACL command that lets you specify the D-series node (or
C-series system), volume, and subvolume from which the compiler is to resolveincomplete file names specified in SEARCH, SOURCE, and USEGLOBALS directives.
automatic extended data segment.   A segment that is automatically allocated by the
compiler when you declare extended indirect arrays or extended indirect structures.
Binder.   A stand-alone binder you can use to bind separately compiled object files (or
modules) into a new object file.
BINSERV.   A binder that is integrated with the TAL compiler.
bit deposit.   The assignment of a value to a bit field in a previously allocated STRING or
INT variable, but not in an UNSIGNED(1–16) variable.  A bit-deposit field has theform < n> or < n:n>.
bit extraction.   The access of a bit field in an INT expression (which can include STRING,
INT, or UNSIGNED(1–16) variables).  A bit-extraction field has the form < n> or < n:n>.
bit field.   One of the following units:
An n-bit storage unit that is allocated for a variable of the UNSIGNED data type.
For an UNSIGNED simple variable, the bit field can be 1 to 31 bits wide.  For anUNSIGNED array element, the bit field can be 1, 2, 4, or 8 bits wide.
A bit field in the form < n> or < n:n>, used in bit-deposit or bit-extraction
operations.

Glossary
Glossary–2 096254 Tandem Computers Incorporatedbit shift.   The shifting of bits within an INT or INT(32) expression a specified number of
positions to the left or right.  An INT expression can consist of STRING, INT, orUNSIGNED(1–16) values.  An INT(32) expression can consist of INT(32) orUNSIGNED(17–31) values.
bit-shift operators.   Unsigned ('<<',  '>>') or signed (<<,  >>) operators that left shift or
right shift a bit field within an INT or INT(32) expression.
bitwise logical operator.   The LOR, LAND, or XOR operator, which performs a bit-by-bit
operation on INT expressions.
blocked global data.   Data you declare within BLOCK declarations.  See “BLOCK
declaration.”
BLOCK declaration.   A means by which you can group global data declarations into a
relocatable data block that is either shareable with all compilation units in a programor private to the current compilation unit.
Boolean operator.   The NOT, OR, or AND operator, which sets the state of a single value
or the relationship between two values.
breakpoint.   A location in a program at which execution is suspended so that you can
examine and modify the program state.  Breakpoints are set by Inspect or Debugcommands.
built-in function.   See “standard function.”
byte.   An 8-bit storage unit; the smallest addressable unit of memory.
CALL statement.   A statement that invokes a procedure or a subprocedure.
CALLABLE procedure.   A procedure you declare using the CALLABLE keyword; a
procedure that can call a PRIV procedure.  (A PRIV procedure can execute privilegedinstructions.)
CASE expression.   An expression that selects an expression based on a selector value.
CASE statement.   A statement that selects a statement based on a selector value.
central processing unit.   See “CPU.”
character string constant.    A string of one or more ASCII characters that you enclose
within quotation mark delimiters.  Also referred to as a character string.
CISC.  Complex instruction set computing.  A processor architecture based on a large
instruction set, characterized by numerous addressing modes, multicycle machineinstructions, and many special-purpose instructions.  Contrast with “RISC.”
CLUDECS.   A file, provided by the CRE, that contains external declarations for CLULIB
functions.  See also “CLULIB.”
CLULIB.    A library file, provided by the CRE, that contains Saved Messages Utility
(SMU) functions for manipulating saved startup, ASSIGN, and PARAM messages.
code segment.   A segment that contains program instructions to be executed, plus
related information.  Applications can read code segments but cannot write to them.

Glossary
096254 Tandem Computers Incorporated Glossary–3code space.  A part of virtual memory that is reserved for user code, user library code,
system code, and system library code.  The current code space of your process consistsof an optional library code space and a user code space.
CODE statement.   A statement that specifies machine codes or constants for inclusion in
the object code.
comment.   A note that you insert into the source code to describe a construct or
operation in your source code.  The compiler ignores comments during compilation.A comment must either:
Begin with two hyphens ( --) and terminate with the end of the line
Begin with an exclamation point ( !) and terminate with either another
exclamation point or the end of the line
Common Run-Time Environment.   See “CRE.”
compilation unit.   A source file plus source code that is read in from other source files by
SOURCE directives, which together compose a single input to the compiler.
compiler directive.   A compiler option that lets you control compilation, compiler
listings, and object code generation.  For example, compiler directives let you compileparts of the source file conditionally or suppress parts of a compiler listing.
compiler listing.   The listing produced by the compiler after successful compilation.  A
compiler listing can include a header, banner, warning and error messages, sourcelisting, maps, cross-references, and compilation statistics.
completion code.   A value used to return information about a process to its caller when
the process completes execution.  For example, the compiler returns to the TACLproduct a completion code indicating the status of the compilation.
complex instruction set computing.   See “CISC.”
condition.   An operand that represents a true or false state.
condition code.   A status returned by expressions and by some file system procedure
calls as follows:
Condition Code Meaning Expression Status Procedure Call StatusCCG Condition-code-greater-than Positive Warning
CCL Condition-code-less-than 0 Error
CCE Condition-code-equal-to Negative Successful execution
conditional expression.   An expression that establishes the relationship between values
and results in a true or false value;  an expression that consists of relational or Booleanconditions and conditional operators.
constant.   A number or a character string.
constant expression.   An arithmetic expression that contains only constants, LITERALs,
and DEFINEs as operands.

Glossary
Glossary–4 096254 Tandem Computers IncorporatedCPU.   Central processing unit.  Historically, the main data processing unit of a
computer.  A Tandem system has multiple cooperating processors rather than a singleCPU;  processors are sometimes called CPUs.
CRE.  Common Run-Time Environment.  Services that facilitate D-series mixed-
language programs.
CREDECS.   A file, provided by the CRE, that contains external declarations for CRELIB
functions whose names begin with CRE_.  See also “CRELIB.”
CRELIB.   A library file, provided by the CRE, that contains functions for sharing files,
manipulating $RECEIVE, terminating the CRE, and performing standard mathfunctions and other tasks.
Crossref.   A stand-alone product that collects cross-reference information for your
program.
CROSSREF.   A compiler directive that collects cross-reference information for your
program.
cross-references.   Source-level cross-reference information produced for your program
by the CROSSREF compiler directive or the Crossref stand-alone product.
C-series system.   A system that is running a C-series release version of the Guardian 90
operating system.
data declaration.   A means by which to allocate storage for a variable and to associate an
identifier with a variable, a DEFINE, or a LITERAL.
data segment.   A segment that contains information to be processed by the instructions
in the related code segment.  Applications can read and write to data segments.  Datasegments contain no executable instructions.
data space.   The area of virtual memory that is reserved for user data and system data.
The current data space of your process consists of a user data segment, an automaticextended data segment if needed, and any user-defined extended data segments.
data stack.   The local and sublocal storage areas of the user data segment.
data type.   A part of a variable declaration that determines the kind of values the
variable can represent, the operations you can perform on the variable, and theamount of storage to allocate.  TAL data types are STRING, INT, INT(32), UNSIGNED,FIXED, REAL, and REAL(64).
data type alias.   An alternate way to specify INT, REAL, and FIXED(0) data types.  The
respective aliases are INT(16), REAL(32), and INT(64).
Debug.   A machine-level interactive debugger.
DEFINE command.   A TACL command that lets you specify a named set of attributes and
values to pass to a process.
DEFINE.   A TAL declaration that associates an identifier with text such as a sequence of
statements.

Glossary
096254 Tandem Computers Incorporated Glossary–5definition structure.   A declaration that describes a structure layout and allocates storage
for the structure layout.  Contrast with “referral structure”  and “template  structure.”
dereferencing operator.   A period (.) prefixed to an INT simple variable, which causes the
content of the variable to become the standard word address of another data item.
direct addressing.   Data access that requires only one memory reference and that is
relative to the base of the global, local, or sublocal area of the user data segment.
directive.   See “compiler directive.”
DO statement.    A statement that executes a posttest loop until a true condition occurs.
doubleword.    A 32-bit storage unit for the INT(32) or REAL data type.
DROP statement.   A statement that frees a reserved index register or removes a label
from the symbol table.
D-series system.   A system that is running a D-series release version of the operating
system.
entry point.   An identifier by which a procedure can be invoked.  The primary entry
point is the procedure identifier specified in the procedure declaration.  Secondaryentry points are identifiers specified in entry-point declarations.
entry -point declaration .  A declaration within a procedure that provides a secondary
entry point by which that procedure can be invoked.  The primary entry point is theprocedure identifier specified in the procedure declaration.
environment register.   A facility that contains information about the current process, such
as the current RP value and whether traps are enabled.
equivalenced variable.   A declaration that associates an alternate identifier and
description with a location in a primary storage area.
expression.   A sequence of operands and operators that, when evaluated, produces a
single value.
EXTDECS.  A file, provided by the operating system, that contains external declarations
for system procedures.  System procedures, for example, manage files, activate andterminate programs, and monitor the operations of processes.
extended data segment.   A segment that provides up to 127.5 megabytes of indirect data
storage.  A process can have more than one extended data segment:
The compiler allocates an extended data segment when you declare extendedindirect arrays or indirect structures.
Your process can also allocate explicit extended data segments.
extended indirect addressing.   Data access through an extended (32-bit) pointer.
extended pointer.   A 32-bit simple pointer or structure pointer.  An extended pointer can
contain a 32-bit byte address of any location in virtual memory.

Glossary
Glossary–6 096254 Tandem Computers Incorporatedextended stack.   A data block named $EXTENDED#STACK that is created in the
automatic extended data segment by the compiler when you declare extended indirectarrays and structures.
EXTENSIBLE procedure.   A procedure that you declare using the EXTENSIBLE keyword;
a procedure to which you can add formal parameters without recompiling its callers;a procedure for which the compiler considers all parameters to be optional, even ifsome are required by your program.  Contrast with “VARIABLE procedure.”
external declarations file.   A file that contains declarations for procedures declared in
other source files.
EXTERNAL procedure declaration.   A procedure declaration that includes the EXTERNAL
keyword and no procedure body;  a declaration that enables you to call a procedurethat is declared in another source file.
file ID.   The last of the four parts of a file name.
file name.   A fully qualified file ID.  A file name contains four parts separated by
periods:
Node name (system name)
Volume name
Subvolume name
File ID
file system.   A set of operating system procedures and data structures that allows
communication between a process and a file, which can be a disk file, a device, or aprocess.
filler bit.   A declaration that allocates a bit place holder for data or unused space in a
structure.
filler byte.   A declaration that allocates a byte place holder for data or unused space in a
structure.
FIXED.   A data type that requires a quadrupleword of storage and that can represent a
64-bit fixed-point number.
FOR statement.   A statement that executes a pretest loop n times.
formal parameter.   A specification, within a procedure or subprocedure, of an argument
that is provided by the calling procedure or subprocedure.
FORWARD procedure declaration.   A procedure declaration that includes the FORWARD
keyword but no procedure body;  a declaration that allows you to call a procedurebefore you declare the procedure body.
fpoint.   An integer in the range –19 through 19 that specifies the implied decimal point
position in a FIXED value.  A positive fpoint denotes the number of decimal places tothe right of the decimal point.  A negative fpoint denotes the number of integer placesto the left of the decimal point; that is, the number of integer digits to replace withzeros leftward from the decimal point.

Glossary
096254 Tandem Computers Incorporated Glossary–7function.   A procedure or subprocedure that returns a value to the calling procedure or
subprocedure.
global data.   Data declarations that appear before the first procedure declaration;
identifiers that are accessible to all compilation units in a program, unless the the datadeclarations appear in a BLOCK declaration that includes the PRIVATE keyword.
GOTO statement.   A statement that unconditionally branches to a label within a
procedure or subprocedure.
group comparison expression.   An expression that compares a variable with another
variable or with a constant.
high PIN.   A process identification number (PIN) that is greater than 255.  Contrast with
“low PIN.”
home terminal.   Usually the terminal from which a process was started.
Identifier.   A name you declare for an object such as a variable, LITERAL, or procedure.
IF expression.   An expression that selects the THEN expression for a true state or the
ELSE expression for a false state.
IF statement.   A statement that selects the THEN statement for a true state or the ELSE
statement for a false state.
implicit pointer.   A pointer the compiler provides when you declare an indirect array or
indirect structure.  See also “pointer.”
index register.   Register R5, R6, or R7 of the register stack.
index .  An element (byte, word, doubleword, or quadrupleword) offset or an
occurrence offset as follows:
Array index—an element offset from the zeroth element
Simple pointer index —an element offset from the address stored in the pointer
Structure or substructure index—an occurrence offset from the zeroth occurrence
indexing.   Data access through an index appended to a variable name.
Inspect product.   A source-level and machine-level interactive debugger.
INITIALIZER.   A system procedure that reads and processes messages during process
startup.
instruction register.   A facility that contains the instruction currently executing the
current code segment.
INT.  A data type that requires a word of storage and that can represent one or two
ASCII characters or a 16-bit integer.
INT(16).   An alias for INT.
INT(32).   A data type that requires a doubleword of storage and that can represent a
32-bit integer.
INT(64).   An alias for FIXED(0).

Glossary
Glossary–8 096254 Tandem Computers IncorporatedINTERRUPT attribute.   A procedure attribute (used only for operating system
procedures) that causes the compiler to generate an IXIT (interrupt exit) instructioninstead of an EXIT instruction at the end of execution.
keyword.   A term that has a predefined meaning to the compiler.
label.   An identifier you place before a statement for access by other statements within
the encompassing procedure, usually a GOTO statement.
labeled tape.   A magnetic tape file described by standard ANSI or IBM file labels.
LAND.   A bitwise logical operator that performs a bitwise logical AND operation.
LANGUAGE attribute.   A procedure attribute that lets you specify in which language (C,
COBOL, FORTRAN, or Pascal) a D-series EXTERNAL procedure is written.
large-memory-model program.   A C or Pascal program that uses 32-bit addressing and
stores data in an extended data segment.
LITERAL.   A declaration that associates an identifier with a constant.
local data.   Data that you declare within a procedure;  identifiers that are accessible only
from within that procedure.
local register.   A facility that contains the address of the beginning of the local data area
for the most recently called procedure.
logical operator.   See “bitwise logical operator .”
LOR.   A bitwise logical operator that performs a bitwise logical OR operation.
low PIN.   A process identification number (PIN) in the range 0 through 254.  Contrast
with “high PIN.”
lower 32K-word area.   The lower half of the user data segment.  The global, local, and
sublocal storage areas.
MAIN procedure.   A procedure that you declare using the MAIN keyword;  the
procedure that executes first when you run the program regardless of where theMAIN procedure appears in the source code.
memory page.   A unit of virtual storage.  TAL supports the 1048-byte memory page
regardless of the memory-page size supported by the system hardware.
mixed-language program.   A program that contains source files written in different
Tandem programming languages.
modular program.   A program that is divided into smaller, more manageable
compilation units that you can compile separately and then bind together.
move statement.   A statement that copies a group of elements from one location to
another.
multidimensional array.   A structure that contains nested substructures.
NAME declaration.   A declaration that associates an identifier with a compilation unit
(and with its private global data block if any).

Glossary
096254 Tandem Computers Incorporated Glossary–9named data block.   A BLOCK declaration that specifies a data-block identifier.  The
global data declared within the BLOCK declaration is accessible to all compilationunits in the program.  Contrast with “private data block.”
network.   Two or more nodes linked together for intersystem communication.
node.   A computer system connected to one or more computer systems in a network.
NonStop SQL.   A relational database management system that provides efficient online
access to large distributed databases.
NOT.   A Boolean operator that tests a condition for the false state and that performs
Boolean negation.
object file.   A file, generated by a compiler or binder, that contains machine instructions
and other information needed to construct the executable code spaces and initial datafor a process.  The file can be a complete program ready for execution, or it can beincomplete and require binding with other object files before execution.
offset.    Represents, when used in place of an index, the distance in bytes of an item
from either the location of a direct variable or the location of the pointer of an indirectvariable, not from the location of the data to which the pointer points.  Contrast with“index.”
operand.   A value that appears in an expression.  An operand can be a constant, a
variable identifier, a LITERAL identifier, or a function invocation.
operator.   A symbol—such as an arithmetic or conditional operator—that performs a
specific operation on operands.
OR.  A Boolean operator that produces a true state if either adjacent condition is true.
output listing.    See “compiler listing.”
page.   See “memory page.”
PARAM command.   A TACL command that lets you associate an ASCII value with a
parameter name.
parameter.   An argument that can be passed between procedures or subprocedures.
parameter mask.   A means by which the compiler keeps track of which actual
parameters are passed by a procedure to an EXTENSIBLE or VARIABLE procedure.
parameter pair.   Two parameters connected by a colon that together describe a single
data type to some languages.
PIN.  A process identification number; an unsigned integer that identifies a process in a
processor module.
pointer.   A variable that contains the address of another variable.  Pointers include:
Simple pointers and structure pointers that you declare and manage
Implicit pointers (pointers the compiler provides and manages when you declare
indirect arrays and indirect structures)
See also “extended pointer” and “standard pointer.”

Glossary
Glossary–10 096254 Tandem Computers Incorporatedprecedence of operators.   The order in which the compiler evaluates operators in
expressions.
primary storage area.   The area of the user data segment that can store pointers and
directly addressed variables.  Contrast with “secondary storage area.”
PRIV procedure.  A procedure you declare using the PRIV keyword; a procedure that
can execute privileged instructions.  Normally only operating system procedures arePRIV procedures.
private data area.   The part of the data space that is reserved for the sole use of a
procedure or subprocedure while it is executing.
private data block.   A BLOCK declaration that specifies the PRIVATE keyword.  Global
data declared within such a BLOCK declaration is accessible only to procedures withinthe current compilation unit.  Contrast with “named data block.”
procedure.   A program unit that can contain the executable parts of a program and that
is callable from anywhere in a program;  a named sequence of machine instructions.
procedure declaration.   Declaration of a program unit that can contain the executable
parts of a program and that is callable from anywhere in a program.  Consists of aprocedure heading and either a procedure body or the keyword FORWARD orEXTERNAL.
process.   An instance of execution of a program.
process environment.   The software environment that exists when the processor module
is executing instructions that are part of a user process or a system process.
process identification number.  See “PIN.”
program.   A set of instructions that a computer is capable of executing.
program register.   A facility that contains the address of the next instruction to be
executed in the current code segment.
program structure.   The order and level at which major components such as data
declarations and statements appear in a source file.
public name.   A specification within a procedure declaration of a procedure name to use
in Binder, not within the compiler.  Only a D-series EXTERNAL procedure declarationcan include a public name.  If you do not specify a public name, the procedureidentifier becomes the public name.
quadrupleword.   A 64-bit storage unit for the REAL(64) or FIXED data type.
read-only array.   An array that you can read but cannot modify;  an array that is located
in the user code segment.
REAL.   A data type that requires a doubleword of storage and that can represent a
32-bit floating-point number.
REAL(32).   An alias for REAL.

Glossary
096254 Tandem Computers Incorporated Glossary–11REAL(64).   A data type that requires a quadrupleword of storage and that can represent
a 64-bit floating-point number.
recursion.   The ability of a procedure or subprocedure to call itself.
redefinition.   A declaration, within a structure, that associates a new identifier and
sometimes a new description with a previously declared item in the same structure.
reduced instruction set computing.   See “RISC.”
reference parameter.   An argument for which a calling procedure (or subprocedure)
passes an address to a called procedure (or subprocedure).  The called procedure orsubprocedure can modify the original argument in the caller’s scope.  Contrast with“value parameter.”
referral structure.   A declaration that allocates storage for a structure whose layout is the
same as the layout of a specified structure or structure pointer.  Contrast with“definition structure” and “template structure.”
register.   A facility that stores information about a running process.  Registers include
the program register, the instruction register, the local register, the stack register, theregister stack, and the environment register.
register stack.   A facility that contains the registers R0 through R7 for arithmetic
operations, of which R5, R6, and R7 also serve as index registers.
register pointer (RP).   An indicator that points to the top of the register stack.
relational operator.   A signed (<, =, >, <=, >= <>) or unsigned ('<', '=', '>', '<=', '>=', '<>')
operator that performs signed or unsigned comparison, respectively, of two operandsand then returns a true or false state.
relocatable data.   A global data block that Binder can relocate during the binding
session.
RESIDENT procedure.   A procedure you declare using the RESIDENT keyword;  a
procedure that remains in main memory for the duration of program execution.  Theoperating system does not swap pages of RESIDENT code.
RETURN statement.   A statement that returns control from a procedure or a
subprocedure to the caller.  From functions, the RETURN statement can return a value.As of the D20 release, RETURN can also return a condition-code value.
RISC.  Reduced instruction set computing.  A processor architecture based on a
relatively small and simple instruction set, a large number of general-purposeregisters, and an optimized instruction pipeline that supports high-performanceinstruction execution.  Contrast with “CISC.”
RP.  Register pointer.  An indicator that points to the top of the register stack.
RSCAN statement.   A statement that scans sequential bytes, right to left, for a test
character.
RTLDECS.   A file, provided by the CRE, that contains external declarations for CRELIB
functions whose names begin with RTL_.  See also “CRELIB.”

Glossary
Glossary–12 096254 Tandem Computers IncorporatedSaved Messages Utility.  See "SMU functions."
SCAN statement.   A statement that scans sequential bytes, left to right, for a test
character.
scope.   The set of levels—global, local, or sublocal—at which you can access each
identifier.
secondary storage area.   The part of the user data segment that stores the data of indirect
arrays and structures.  For standard indirection, the secondary storage area is in theuser data segment.  For extended indirection, the secondary storage area is in theautomatic extended data segment.  Contrast with “primary storage area.”
segment ID.   A number that identifies an extended data segment and that specifies the
kind of extended data segment to allocate.
signed arithmetic operators.   The following operators:  + (unary plus),    – (unary minus),
+ (binary signed addition),   – (binary signed subtraction),   * (binary signed
multiplication),  and   / (binary signed division).
simple pointer.   A variable that contains the address of a memory location, usually of a
simple variable or an array element, that you can access with this simple pointer.
simple variable.   A variable that contains one item of a specified data type.
small-memory-model program.   A C or Pascal program that uses 16-bit addressing,
contains up to 64K bytes of data, and has a limited number of named static variables.
SMU functions.  Saved Messages Utility (SMU) functions, provided by the CLULIB
library, for manipulating saved startup, ASSIGN, and PARAM messages.
source file.   A file that contains source text such as data declarations, statements,
compiler directives, and comments.  The source file, together with any source coderead in from other source files by SOURCE directives, compose a compilation unit thatyou can compile into an object file.
stack register.   A register that contains the address of the last allocated word in the data
stack.
STACK statement.   A statement that loads a value onto the register stack.
standard function.   A built-in function that you can use for an operation such as type
transfer or address conversion.
standard indirect addressing.   Data access through a standard (16-bit) pointer.
standard pointer.   A 16-bit simple pointer or structure pointer.  A standard pointer can
contain a 16-bit address in the user data segment.
statement.   An executable sequence of keywords, operators, and values.  A statement
performs a specific action such as assigning a value to a variable or calling aprocedure.
STORE statement.   A statement that stores a value from a register stack element into a
variable.

Glossary
096254 Tandem Computers Incorporated Glossary–13STRING.   A data type that requires a byte or word of storage and that can represent an
ASCII character or an 8-bit integer.
structure.   A variable that can contain different kinds of variables of different data
types.  A definition structure, a template structure, or a referral structure.
structure data item.   An accessible structure field declared within a structure, including a
simple variable, array, substructure, simple pointer, structure pointer, or redefinition.Contrast with “structure item.”
structure item.   Any structure field, including a structure data item, a bit filler, or a byte
filler.  Also see “structure data item.”
structure pointer.   A variable that contains the address of a structure that you can access
with this structure pointer.
sublocal data.   Data that you declare within a subprocedure;  identifiers that are
accessible only from within that subprocedure.
subprocedure.   A named sequence of machine instructions that is nested (declared)
within a procedure and that is callable only from within that procedure.
substructure.   A structure that is nested (declared) within a structure or substructure.
SYMSERV.   A process, integrated with the TAL compiler, that on request provides
symbol-table information to the object file for use by the Inspect and Crossrefproducts.
system.   The processors, memory, controllers, peripheral devices, and related
components that are directly connected together by buses and interfaces to form anentity that is operated as one computer.
system procedure.   A procedure provided by the operating system for your use.  System
procedures, for example, manage files, activate and terminate programs, and monitorthe operations of processes.
TAL.  Transaction Application Language.  A high-level, block-structured language that
works efficiently with the system hardware to provide optimal object programperformance.
TALDECS.   A file, provided by the TAL compiler, that contains external declarations for
TALLIB functions.  See also “TALLIB.”
TALLIB.   A library file, provided by the TAL compiler, that contains procedures for
initializing the CRE and for preparing a program for SQL statements.
Tandem NonStop Series system.    See “TNS system.”
Tandem NonStop Series/RISC system.    See “TNS/R system.”
template structure.   A declaration that describes a structure layout but allocates no
storage for the structure.  Contrast with “definition structure” and “referral structure.”
TNS system.    Tandem NonStop Series system.  Tandem computers that are based on
CISC technology.  TNS processors implement the TNS instruction set.