# Document Structure

This directory contains the extracted and organized content from the TAL Programmer's Guide PDF (Part Number 096254, Second Edition, September 1993).

## Directory Organization

```
tal-guide/
├── README.md                    # Main navigation and overview
├── STRUCTURE.md                 # This file - explains organization
├── 00-front-matter.md          # Title page, document history, TOC
├── glossary.md                 # Comprehensive glossary of terms
├── index.md                    # Complete alphabetical index
├── sections/                    # Main content sections (16 sections)
│   ├── section-01.md           # Introducing TAL
│   ├── section-02.md           # Getting Started
│   ├── section-03.md           # Structuring Programs
│   ├── section-04.md           # Introducing the Environment
│   ├── section-05.md           # Using Expressions
│   ├── section-06.md           # Using Simple Variables
│   ├── section-07.md           # Using Arrays
│   ├── section-08.md           # Using Structures
│   ├── section-09.md           # Using Pointers
│   ├── section-10.md           # Using Equivalenced Variables
│   ├── section-11.md           # Using Procedures
│   ├── section-12.md           # Controlling Program Flow
│   ├── section-13.md           # Using Special Expressions
│   ├── section-14.md           # Compiling Programs
│   ├── section-15.md           # Compiler Listing
│   └── section-16.md           # Running and Debugging
└── appendices/                  # Reference appendices (6 appendices)
    ├── appendix-A.md           # Sample Programs
    ├── appendix-B.md           # Managing Addressing
    ├── appendix-C.md           # Improving Performance
    ├── appendix-D.md           # ASCII Character Set
    ├── appendix-E.md           # File Names and TACL
    └── appendix-F.md           # Data Type Correspondence
```

## File Sizes and Content

### Sections
| File | Size | Description | PDF Pages |
|------|------|-------------|-----------|
| section-01.md | 6.9K | Introduction to TAL features | 4 pages |
| section-02.md | 6.7K | Creating and running programs | 5 pages |
| section-03.md | 26K | Program structure and organization | 19 pages |
| section-04.md | 18K | Process environment and memory | 11 pages |
| section-05.md | 51K | Arithmetic and conditional expressions | 31 pages |
| section-06.md | 17K | Simple variable operations | 13 pages |
| section-07.md | 37K | Array manipulation | 25 pages |
| section-08.md | 64K | Structure data types | 43 pages |
| section-09.md | 39K | Pointer operations | 25 pages |
| section-10.md | 22K | Variable equivalencing | 21 pages |
| section-11.md | 74K | Procedure declarations and calls | 52 pages |
| section-12.md | 28K | Control flow statements | 25 pages |
| section-13.md | 15K | Special expression features | 9 pages |
| section-14.md | 46K | Compilation process | 29 pages |
| section-15.md | 27K | Compiler output | 17 pages |
| section-16.md | 93K | Debugging techniques | 60 pages |

### Appendices
| File | Size | Description | PDF Pages |
|------|------|-------------|-----------|
| appendix-A.md | 33K | Complete example programs | 22 pages |
| appendix-B.md | 38K | Memory addressing techniques | 24 pages |
| appendix-C.md | 6.3K | Performance optimization | 3 pages |
| appendix-D.md | 4.4K | ASCII character reference | 4 pages |
| appendix-E.md | 17K | File naming and TACL commands | 10 pages |
| appendix-F.md | 4.9K | Type correspondence tables | 5 pages |

### Reference Materials
| File | Size | Description | PDF Pages |
|------|------|-------------|-----------|
| glossary.md | 33K | Glossary of TAL terms | 14 pages |
| index.md | 45K | Alphabetical index | 49 pages |

## Total Content

- **Total Markdown Files**: 27 files
- **Total Size**: ~780KB of text content
- **Source PDF**: 553 pages
- **Extracted Content**: All 553 pages fully extracted

## Content Organization Logic

The document has been organized into logical units:

1. **Front Matter** (`00-front-matter.md`): Contains publication information, document history, and metadata
2. **Sections 1-16**: Main instructional content organized by topic
3. **Appendices A-F**: Reference materials and supplementary information
4. **Glossary** (`glossary.md`): Comprehensive glossary of TAL programming terms
5. **Index** (`index.md`): Complete alphabetical index of all topics

Each markdown file:
- Starts with a clear heading indicating section/appendix number and title
- Contains cleaned text with reduced PDF extraction artifacts
- Preserves code examples in code blocks where appropriate
- Maintains the logical flow of the original document

## Navigation

Start with `README.md` for a comprehensive table of contents with descriptions of each section.

## Extraction Notes

- Text was extracted from PDF using PyPDF2
- Headers, footers, and page numbers have been removed
- Code examples are formatted in markdown code blocks
- Tables and structured content are preserved as closely as possible
- Some formatting may be imperfect due to PDF extraction limitations

## Source Document

**Original PDF**: TAL Programmer's Guide (Tal-Guide.pdf)
- Publisher: Tandem Computers Incorporated
- Part Number: 096254
- Edition: Second
- Published: September 1993
- URL: http://nonstoptools.com/manuals/Tal-Guide.pdf
