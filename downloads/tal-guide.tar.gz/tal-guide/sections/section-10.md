# Section 10: Using Equivalenced Variables

in a primary storage area.  This section describes how to equivalence a new variableto a previously declared variable.  You can declare:
Equivalenced simple variables
Equivalenced simple pointers
Equivalenced structures
Equivalenced structure pointers
The new and previous variables can have different data types and byte-addressing
and word-addressing attributes.  You can, for example, refer to an INT(32) variable astwo separate words or four separate bytes.
Other kinds of equivalencing are described in the TAL manual set as follows:
Information Manual SectionRedefinitions (equivalencing
within structures)TAL Programmer’s Guide
TAL Reference Manual8, “Using Structures”
8, “Structures”  (syntax)
Base-address equivalencing TAL Reference Manual 10, “Equivalenced Variables”
'SG'-equivalencing TAL Reference Manual 15, “Privileged Procedures”
Example Diagrams The diagrams in this section show the relationship of an equivalenced variable to the
previous variable.  Unless otherwise noted, the diagrams refer to memory locationsin the primary area of the user data segment.  Here is a sample diagram:
The shaded box is the previous (allocated) variable
The unshaded box is the equivalenced (new) variable
INT word1;
INT word2 = word1;      WORD1 WORD2
Variables You Can
EquivalenceYou can equivalence any variable in the first column of Table 10-1 to any variable in
the second column.  (You cannot equivalence an array to another variable.)
Table 10-1.  Equivalenced Variables
Equivalenced (New) Variable Previous VariableSimple variable
Simple pointerStructureStructure pointerSimple variable
Simple pointerStructureStructure pointerArrayEquivalenced variable
For compatibility with future software platforms, however, equivalence indirect
structures only to indirect structures or indirect arrays.

Equivalencing Simple Variables Using Equivalenced Variables
Simple VariablesYou can equivalence a new simple variable to a previously declared variable as listed
in Table 10-1 earlier in this section.
Declaring Equivalenced
Simple VariablesTo declare an equivalenced simple variable, specify:
Any data type  but UNSIGNED
The identifier  of the new simple variable
An equal sign (=)
The identifier of the previous variable
For portability to future software platforms, declare equivalenced variables that fit
within the previous variable.
Equivalencing INT Simple Variables
For example, you can equivalence an INT variable (WORD2) to a previous INT
variable (WORD1):
INT word1;
INT word2 = word1;      WORD1 WORD2
Equivalencing STRING Simple Variables
You can equivalence a STRING variable (S2) to a previous STRING variable (S1):
STRING s1 := "A";
STRING s2 = s1;
301S1 ? S2
Equivalencing Mixed Simple Variables
The data type of the new variable can differ from the data type of the previous
variable.  For example, you can equivalence STRING and INT(32) variables to aprevious INT array.  (The middle box looks like an array, but it is an equivalencedSTRING simple variable shown with indexes.)
INT w[0:1];
STRING b = w[0];INT(32) d = b;
w[0]
w[1]B[0] B[1]
B[2] B[3]
302D

Equivalencing Simple Variables Using Equivalenced Variables
If you equivalence a simple variable to a simple pointer, the simple variable is
equivalenced to the location occupied by the simple pointer, not to the locationwhose address is stored in the pointer:
INT .ptr := 200;
INT addr = ptr;
332ADDR PTR = 200
.
..
G[200]
Avoid Equivalencing Simple Variables to Indirect Variables
If you equivalence a simple variable to an indirect variable, the simple variable is
equivalenced to the location occupied by the implicit pointer, not to the location ofthe data whose address is stored in the implicit pointer.
Therefore, avoid equivalencing a simple variable to a standard indirect array:
INT .array[0:9];
INT var = array;
327ptr to ARRAYUser data segment
Primary area
Secondary areaVAR
.
..
ARRAY
...

Equivalencing Simple Variables Using Equivalenced Variables
INT .EXT array[0:999];
INT(32) addr = array;
309Automatic extended data segmentARRAY
.
.. ptr to ARRAY  ADDR
Avoid Odd-Byte Equivalencing
If you equivalence a STRING variable to an odd-byte array element, the compiler
converts the odd-byte index to the previous word boundary as shown in the diagramand issues a warning.
Avoid the following practice:
STRING a[0:1];
STRING b = a[1];
303A[0] A[1] B
Avoid Equivalenced Arrays
You cannot equivalence arrays to other variables.  Avoid the following practice:
INT a[0:5];
INT b;INT c[0:5] = a;              !ErrorINT d[0:5] = b;              !Error

Equivalencing Simple Variables Using Equivalenced Variables
Simple VariablesOnce you have declared an equivalenced variable, you access it in the same way as
you access any other variable, by specifying its identifier in a statement.
Accessing Words in Doublewords
You can declare two INT variables, each equivalent to one of the two words of an
INT(32) variable.  You can then access the location either as an INT variable or as anINT(32) variable:
A
B
304INT(32) dbl;
INT a = dbl;  INT b = a[1];   a := 0;     !Access first word of DBLdbl := -1D; !Access DBL as a doublewordDBL
Accessing Bytes in Words
You can equivalence a STRING variable to an INT array, and then access bytes in the
INT array by indexing the STRING variable:
INT word[0:2];
STRING s = word;
s[3] := 0;
IF s[4] > 2 THEN ...;
305WORD[0]
WORD[1]
WORD[2]S[0] S[1]
S[2] S[3]
S[4] S[5]

Equivalencing Simple PointersUsing Equivalenced Variables
Simple PointersYou can equivalence a new simple pointer to a previously declared variable as listed
in Table 10-1 earlier in this section.
Declaring Equivalenced
Simple PointersTo declare an equivalenced simple pointer, specify:
Any data type  except UNSIGNED
The identifier  of the new simple pointer, preceded by an indirection symbol
An equal sign (=)
The identifier of the previous variable
For portability to future software platforms, declare equivalenced variables that fit
within the previous variable.
Matching Byte or Word Addressing
If the previous variable is a pointer, an indirect array, or an indirect structure, the
previous pointer and the new pointer must both contain either:
A standard byte address
A standard word address
An extended address
Otherwise, the pointers will point to different locations, even if they both contain the
same value.  That is, a standard STRING or extended pointer normally points to abyte address, and a standard pointer of any other data type normally points to aword address.
When you equivalence standard pointers, ensure that the byte or word addressing
match.  For example, INT and INT(32) standard pointers both contain a wordaddress:
INT .ptr1 := 200;
INT(32) .ptr2 = ptr1;
307PTR2 = 200 PTR1 = 200
.
..
G[200]

Equivalencing Simple PointersUsing Equivalenced Variables
addressing mismatches, because extended pointers always point to byte addresses.Thus, you can equivalence an extended INT pointer to an extended STRING pointer:
STRING .EXT xstrptr
```
          := %2000000D;INT    .EXT xintptr           = xstrptr;Primary area of user data segment
```
399Automatic extended data segmentXSTRPTR =
%2000000D  XINTPTR
%2000000D
.
..
Avoid Mixing Byte and Word Addressing
If you equivalence a STRING standard pointer to an INT standard pointer, the INT
pointer points to a word address and the STRING pointer points to a byte address.
Avoid the following practice:
INT  .ptr1 := 200;
STRING .ptr2 = ptr1;
308PTR2 = 200
G[200]PTR1 = 200
.
..
...
G[200]Byte address
Word address
Equivalencing Simple Pointers to Direct Variables
You can equivalence a simple pointer to a direct variable.  The content of the simple
variable becomes the address of the data to which the pointer points.
You can equivalence a standard pointer to a simple variable:
INT dir := 200;
INT .ptr = dir;PTR = 200
306G[200]DIR = 200
.
..

Equivalencing Simple PointersUsing Equivalenced Variables
INT(32) xaddr := %2000000D;
INT .EXT xptr = xaddr;
Automatic extended data segmentPrimary area of user data segment
417XADDR =
%2000000D  XPTR
%2000000D
.
..
Accessing Equivalenced
Simple PointersAfter you declare an equivalenced pointer, you can access it by specifying in a
statement the identifier of the pointer or of the variable to which the pointer isequivalenced.  Suppose you equivalence a simple pointer to a simple variable asfollows:
INT dir := 200;
INT .ptr = dir;
PTR = 200
306G[200]DIR = 200
.
..
If you assign a value to the simple variable in the preceding example, you change the
content of both the simple variable and the simple pointer:
dir := 45; PTR = 45
310G[45]DIR = 45
.
..

Equivalencing StructuresUsing Equivalenced Variables
to the pointer, you change the content of both the direct variable and the simplepointer:
@ptr := 66;
PTR = 66
311G[66]DIR = 66
.
..
If you assign a value to the simple pointer without the @ operator, you change the
content of only the variable to which the simple pointer points.  Location G[66] nowcontains 15:
ptr := 15;
PTR = 66
312G[66]DIR = 66
.
..
Equivalencing
StructuresYou can equivalence a new definition or referral structure to a previously declared
variable as listed in Table 10-1 earlier in this section.
If you want the new structure layout to occupy the same location as the previous
variable, be sure that you match the addressing mode of the new structure and of theprevious variable as follows:
New Structure Previous VariableDirect structure Simple variable
Direct structureDirect array
Standard indirect structure Standard indirect structure
Standard indirect arrayStandard structure pointer *
Extended indirect structure Extended indirect structure
Extended indirect arrayExtended structure pointer *
*   If the previous variable is a pointer, the new structure is really a pointer.
Definition structures and referral structures are described separately in the following
subsections.

Equivalencing StructuresUsing Equivalenced Variables
Definition StructuresTo declare an equivalenced definition structure, specify:
The keyword STRUCT
The identifier  of the new structure, often preceded by an indirection symbol
An equal sign (=)
The identifier of the previous variable
The layout  of the new structure (enclosed in a BEGIN-END construct)
For portability to future software platforms, declare equivalenced variables that fit
within the previous variable.
Equivalencing Direct Structures
You can declare a directly addressed definition structure equivalent to another
directly addressed structure:
STRUCT dir1;
BEGIN  STRING name[0:20];  STRING addr[0:50];  END;
STRUCT dir2 = dir1;
BEGIN   STRING name[0:30];  STRING addr[0:40];  END; DIR2 DIR1
313.
........
Equivalencing Standard Indirect Structures
You can equivalence a standard indirect definition structure to another standard
indirect structure.
For example, you can equivalence standard indirect structure STR2 equivalent to
standard indirect structure STR1:
STRUCT temp(*);
BEGIN  STRING name[0:20];  STRING addr[0:50];  END;
STRUCT .str1 (temp);STRUCT .str2 = str1;
BEGIN   STRING name[0:30];  STRING addr[0:40];  END; ptr to STR1Primary area
Secondary area
314ptr to STR2
STR2.
..
STR1
.........

Equivalencing StructuresUsing Equivalenced Variables
You can equivalence an extended indirect definition structure to another extended
indirect structure:
STRUCT .EXT xstr1;
BEGIN  STRING old_name[0:20];  STRING old_addr[0:50];  END;
STRUCT .EXT xstr2 = xstr1;
BEGIN   STRING new_name[0:30];  STRING new_addr[0:40];  END; XSTR1
315XSTR2
.
..
Automatic extended data segment....
.....Primary area of user data segment
ptr to XSTR1  ptr to XSTR2
Equivalencing Structures to Simple Variables
You can equivalence a structure to a simple variable.  For example, you can declare a
two-word structure to an INT(32) simple variable:
400VAR ASTRUCTHIGH
LOWSTRUCT astruct = var;
BEGIN  INT high;  INT low;  END;INT(32) var;

Equivalencing StructuresUsing Equivalenced Variables
You can equivalence a structure to an array.  The following example equivalences a
standard indirect structure to a standard indirect array:
STRING .array[0:127];
STRUCT .str = array;
BEGIN   STRING name[0:63];  STRING addr[0:63];  END; ptr to ARRAYPrimary area
ARRAY
Secondary area
318ptr to STR
STR.
..
... ...
You can equivalence an extended indirect structure to an extended indirect array:
INT .EXT xarray[0:127];
STRUCT .EXT xstr = xarray;
BEGIN   STRING name[0:30];  STRING addr[0:40];  END; Primary area of user data segment
XARRAY
401XSTR
Automatic extended data segment.
..ptr to XARRAY ptr to XSTR
...

Equivalencing StructuresUsing Equivalenced Variables
If you equivalence an indirect structure to a structure pointer, the indirect structure
behaves exactly like the structure pointer:
ptr to STR1
PTRSTRUCT .str1;
BEGIN  INT a[0:3];  INT b[0:9];  END;
INT .ptr (str1) := @str1; STRUCT .str2 = ptr;
BEGIN  STRING a2[0:7];  STRING b2[0:19];  END;ptr to STR2
STR2 STR1
317Secondary area.
..
......
Avoid Mixing Addressing Modes
Do not equivalence an indirect structure to a direct variable, because the implicit
pointer to the indirect structure cannot point to the structure data.  Avoid thefollowing practice:
319STRUCT dir_str;
BEGIN    STRING a[0:19];  STRING b[0:49];  END;
STRUCT .ind_str = dir_str;
BEGIN           INT a[0:9];  INT b[0:24];  END;DIR_STR ptr to IND_STR
IND_STR
.
..Primary area
Secondary area.
..

Equivalencing StructuresUsing Equivalenced Variables
structure is not equivalenced to the indirect structure.  Avoid the following practice:
Secondary areaSTRUCT .ind_str;
BEGIN    STRING a[0:19];  STRING b[0:49];  END;
STRUCT dir_str = ind_str;
BEGIN           INT a[0:9];  INT b[0:24];  END;
402DIR_STR
.
..ptr to IND_STR
IND_STRPrimary area
...
Accessing Equivalenced Definition Structures
You access equivalenced definition structures as you do any other structure.  That is,
you qualify the structure name with the appropriate structure items, as described inSection 8, “Using Structures.”
Equivalencing
Referral StructuresTo declare an equivalenced referral structure, specify:
The keyword STRUCT
The identifier  of the new structure, often preceded by an indirection symbol
A referral  that associates the new structure with a structure layout—enclose in
parentheses the identifier of a previously declared structure or structure pointer
An equal sign (=)
The identifier of the previous variable
For portability to future software platforms, declare equivalenced variables that fit
within the previous variable.
All other equivalencing guidelines described for equivalenced definition structures
apply to equivalenced referral structures.

Equivalencing Structure PointersUsing Equivalenced Variables
You can equivalence a referral structure to a previous definition structure.  In the
following example, both are standard indirect structures:
STRUCT .d_str;
BEGIN    STRING name[0:19];  STRING address [0:49];  END;
STRUCT tmp (*);
BEGIN           INT name[0:9];  INT address[0:24];  END;
STRUCT .r_str (tmp) = d_str;ptr to D_STR
D_STR
Secondary area
316ptr to R_STR
R_STR.
..
......
Accessing Equivalenced Referral Structures
You access equivalenced definition structures as you do any other structure.  That is,
you qualify the structure name with the appropriate structure items, as described inSection 8, “Using Structures.”
Equivalencing
Structure PointersYou can equivalence a new structure pointer to a previously declared variable as
listed in Table 10-1 earlier in this section.
Be sure that you match the addressing mode of the new structure pointer and of the
previous variable as follows:
New Structure Pointer Previous VariableStandard structure pointer Simple variable
Direct arrayStandard indirect structureStandard indirect arrayStandard structure pointer
Extended structure pointer Simple variable
Direct arrayExtended indirect structureExtended indirect arrayExtended structure pointer

Equivalencing Structure PointersUsing Equivalenced Variables
Structure PointersTo declare an equivalenced structure pointer, specify:
STRING or INT attribute (as described in Table 9-3 in Section 9)
The identifier  of the new structure pointer, preceded by an indirection symbol
A referral  that provides a structure layout—enclose the identifier of a previously
declared structure or structure pointer in parentheses
An equal sign (=)
The identifier of the previous variable
For portability to future software platforms, declare equivalenced variables that fit
within the previous variable.
Equivalencing Structure Pointers to Structure Pointers
You can declare a structure pointer equivalent to another structure pointer as
follows:
STRUCT temp (*);
BEGIN  STRING s[0:71];  END;
STRUCT .EXT str;
BEGIN  STRING name[0:20];  STRING addr[0:50];  END;
INT .EXT ptr1 (str) := @str;INT .EXT ptr2 (temp) = ptr1;
```
       Primary area of user data segment
```
STR
320Automatic extended data segmentPTR2 ptr to STR
PTR1
.
..

Equivalencing Structure PointersUsing Equivalenced Variables
Equivalencing an extended structure pointer to an extended indirect structure is the
same as equivalencing an indirect structure to another indirect structure.
STRUCT .EXT str;
BEGIN  STRING name[0:20];  STRING addr[0:50];  END;
INT .EXT ptr (str) = str;
```
       Primary area of user data segment
```
STR
321Automatic extended data segment ptr to STR  PTR
.
..
Equivalencing Structure Pointers to Simple Variables or Arrays
Before you equivalence a structure pointer to a simple variable or an element of a
direct array, make sure that the simple variable or array element contains the addressof a structure:
Primary area of user data segment
STR
403Automatic extended data segmentSTR_PTR ptr to STR
STR_ADDR
= @STR
.
..STRUCT temp (*);
BEGIN  STRING s[0:71];  END;
STRUCT .EXT str;
BEGIN  STRING name[0:20];  STRING addr[0:50];  END;
INT(32) str_addr := @str;INT .EXT str_ptr (temp)
```
              = str_addr;        
```
Matching Byte or Word Addressing
All guidelines for matching byte or word addressing given earlier in this section
apply to equivalenced structure pointers.

Equivalencing Structure PointersUsing Equivalenced Variables
All guidelines for avoiding mixed address modes given earlier in this section apply
to equivalenced structure pointers.
Accessing Data Through
Equivalenced Structure
PointersTo access a structure through a structure pointer, qualify the name of the pointer
with the appropriate structure item names, as was described in Section 9, “UsingPointers.”
This example accesses item A[2] in structure STR through structure pointer PTR:
Primary area
ptr to STR STRUCT .str;
BEGIN  INT a[0:3];  INT b[0:9];  END;
INT .ptr (str) = str;   ptr.a[2] := %14;
```
     !Assign value to      ! STR.A[2]PTR.A[2]
```
STR
322Secondary area.
..
.
..
Avoiding an Access Error
As previously discussed, you can equivalence a structure pointer to an indirect
structure.  Both the structure pointer and the implicit pointer to the indirect structurethen point to the data of the structure.
Primary area
INT var1;
INT var2;
STRUCT .str;
BEGIN  INT a[0:3];  INT b[0:9];  END;
INT .ptr (str) = str;
Secondary areaVAR2
ptr to STR PTR
STR.
..VAR1 G[0]
323.
..

Using Indexes or Offsets Using Equivalenced Variables
both the structure pointer and the implicit pointer point to the new address, ratherthan to the structure data.  You can no longer access the structure data.
Avoid the last statement in the following example:
418INT var1;
INT var2;
STRUCT .str;
BEGIN  INT a[0:3];  INT b[0:9];  END;
INT .ptr (str) = str;
@ptr := 0;
VAR2
ptr to STR PTR  = 0
STR.
..VAR1 G[0]Primary area
Secondary area.
..
Using Indexes
or OffsetsWhen you declare equivalenced variables, you can append an index  or an offset  to the
previously declared variable.  Table 10-2 compares indexes and offsets.
Table 10-2.  Indexes and Offsets
Specified As: Used With Represents
Index INT constant
(enclosed inbrackets)Direct
previousvariableAn element offset from the location of the previous
variable (which cannot be a pointer, including an implicitpointer).  The element size depends on the data type ofthe previous variable.  The indexed location must beginon a word boundary.
Offset INT constant
(preceded by aplus (+) orminus (–))Direct or
indirectpreviousvariableA word offset from either:
−The location of a direct previous variable.
−The location of the pointer of an indirect previous
variable, not from the location of the data pointed to.

Using Indexes or Offsets Using Equivalenced Variables
INT x[0:1];
INT indx = x[1];INT offst = x + 1;x[0]
x[1] INDX OFFST
For direct previous variables other than INT, indexes have element offsets and offsets
have word offsets:
INT(32) xx;
INT indx = xx[1];  INT offst = xx + 1; OFFST
INDX
325Index Offset
XX+1
XX+2
XX+3XX+0XX[0]
XX[1]
You can equivalence a variable to an offset simple pointer but not to an indexed
simple pointer:
INT addr[0:2];
INT .ptr = addr;INT offst = ptr + 2;   !Offset allowedINT indx = ptr[2];   !Index not allowed
326?
OFFSTOffset
PTR+1
PTR+2PTR+0
?
?

Emulating Pascal Variant PartsUsing Equivalenced Variables
Variant PartsYou can simulate variant parts of a Pascal record type by using equivalenced
structures as follows.  (For information on record type variant parts, see the Pascal
Reference Manual.)
LITERAL triangle, rectangle, circle;STRUCT geometry (*);
BEGIN  REAL x, y;  REAL area;  INT shape;                  ! 0 = TRIANGLE,                              ! 1 = RECTANGLE,                              ! 2 = CIRCLE
STRUCT triangle_info;       !If SHAPE = TRIANGLE
```
    BEGIN    REAL side1, side2, side3;    REAL(64) angle1, angle2, angle3;    END;
```
STRUCT rectangle_info = triangle_info;
```
                              !If SHAPE = RECTANGLE    BEGIN    REAL side1, side2;    END;
```
STRUCT circle_info = triangle_info;
```
                              !If SHAPE = CIRCLE    BEGIN    REAL diameter;    END;
```
END;