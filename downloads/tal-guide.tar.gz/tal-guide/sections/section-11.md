# Section 11: Using Procedures

program and that are callable from anywhere in the program.  Procedures let yousegment a program into discrete parts that each perform a particular operation such asI/O or error-handling.
A procedure can call other procedures, one at a time, or it can call another procedure
that in turn calls another, and so on.  It can pass parameters (arguments).  It cancontain subprocedures, which are callable from various points within the sameprocedure.
A function is a procedure or subprocedure that returns a value to the caller.  A
function is also known as a typed procedure or a typed subprocedure.
This section discusses:
How to declare and call procedures and subprocedures
How to declare and pass parameters
How the compiler allocates storage for procedures and parameters
How the compiler provides parameter masks
How to declare and use labels
How to get the addresses of procedures and subprocedures
Procedures and
Code SegmentsThe procedures in a program are located in one or more code segments within the user
code space.  A procedure can call a procedure that is located:
In the same (or current) segment
In another segment of the same code space
In the system code segment
In a system library segment
In a user library segment
The starting address of a procedure is known as the entry point.  The operating system
records entry points in the following system tables:
System Table Content of Table Location of TableProcedure Entry Point
(PEP) tableEntry points of all procedures located
in the current code segmentAt the beginning of the current
code segment
External Entry Point(XEP) tableEntry points of procedures located in
other code segmentsNear the end of the current code
segment
When a procedure calls another procedure in the current segment, control passes to
the called procedure through the segment’s PEP table.
When a procedure calls a procedure in a another code segment, control passes out of
the current segment through its XEP table to the called procedure through the othersegment's PEP table.
You can declare procedures that are up to 32K words in size, minus the size of either:
The PEP table (for procedures in the lower 32K-word area of the code segment)
The XEP table (for procedures in the upper 32K-word area of the code segment)

Declaring ProceduresUsing Procedures
The keyword PROC
The procedure identifier , followed by a semicolon
The procedure  body —a BEGIN-END construct that can include data declarations,
subprocedure declarations, and statements
Here is an example of a procedure declaration:
PROC my_proc;                  !Declare procedure MY_PROC
BEGIN  INT var;                     !Declare local data  !Declare subprocedures, if any  var := 99;                   !Specify local statements  CALL some_proc;  END;                         !End MY_PROC
Calling Procedures When you run your program, a procedure is activated by a CALL statement in another
procedure or subprocedure (the caller).
For example, a caller can call the preceding procedure (MY_PROC) as follows:
PROC caller_proc;              !Declare CALLER_PROC
BEGIN  !Lots of code  CALL my_proc;                !Call MY_PROC  !More code  END;                         !End CALLER_PROC
When the called procedure finishes executing, control returns to the statement
following the CALL statement in the caller.

Declaring Parameters in ProceduresUsing Procedures
in ProceduresYou can include formal parameters in the procedure declaration.  Callers can then pass
corresponding actual parameters for use in the called procedure.
Specifying a Formal
Parameter ListTo include formal parameters in a procedure declaration, specify a comma-separated
list (enclosed in parentheses) of up to 32 formal parameters.
PROC proc_a (param1, param2);  !Declare PROC_A; include
```
                               ! formal parameter list
```
Declaring Formal
ParametersAfter specifying the formal parameter list, declare each formal parameter by
specifying:
A parameter type  (for example, STRING, INT, STRUCT, or PROC).  A procedure
can have any number of parameter words.
The identifier  of the parameter.
If the parameter is a reference parameter, precede the identifier with an indirection
symbol (. or .EXT).  The absence of an indirection symbol denotes a valueparameter.  Table 11-1 describes value and reference parameters.
Table 11-1.  Value and Reference Parameters
Formal
Parameter DescriptionIndirection
Symbol Passed Value
Value The caller passes a value.  The called
procedure cannot change the original value inthe caller's scope.No Simple variable,
constant expression,or procedure
Reference The caller passes the address of a value.  The
called procedure can change the original value in the caller's scope.Yes Address of simple
variable, array, orstructure
For example, you can declare simple variables as value and reference formal
parameters.  The compiler treats the value parameter as if it were a simple variable.The compiler treats the reference parameter as if it were a simple pointer:
PROC proc_x (val_param, ref_param); !Include parameter list
```
    INT val_param;          !Declare value parameter    INT .ref_param;         !Declare reference parameter  BEGIN  ref_param := val_param + ref_param;                            !Manipulate parameters  END;
```
For more information on parameter specifications, see Table 11-3 later in this section.

Declaring Data in ProceduresUsing Procedures
procedure declares the actual parameters.  For example, if the called proceduredeclares a simple variable as a formal reference parameter, the calling procedure mustdeclare a simple pointer as the actual parameter.
The calling procedure passes actual parameters by specifying an actual parameter list
in a CALL statement.  In the following example, PROC_Y calls PROC_X (declared inthe previous example).  PROC_Y passes VAR1 by value and VAR2 by reference asdictated by the formal parameter declarations in PROX_X:
PROC proc_y;                !Declare PROC_Y
BEGIN  INT var1 := 50;           !Declare simple variable  INT .var2 := 20;          !Declare simple pointer  CALL proc_x (var1, var2); !Call PROC_X and pass  END;                      !actual parameters to it
When a CALL statement occurs, the compiler assigns each actual parameter to a
formal parameter in order.  More information on parameters is provided in “UsingParameters” later in this section.
Declaring Data
in ProceduresData items you declare before the first procedure declaration have global scope.  You
can access global data from any procedure in the program.
Data items you declare within a procedure have local scope.  You can access local data
only from within the same procedure.
A local data item can have the same identifier as a global data item.  In this case,
however, you cannot access the global data item from within that procedure.  Forexample, if you declare global variables A and B and local variables A and B, theprocedure can access local variables A and B but not global variables A and B.  If youdeclare a variable named C only at the global level, the procedure can access C:
INT a := 9;                   !Declare global A, B, and C
INT b := 3;INT c;
PROC a_proc MAIN;             !Declare A_PROC
BEGIN  INT a := 4;                 !Declare local A and B  INT b := 1;  c := a + b;                 !Access local A and B  END;                        !End A_PROC

Declaring Data in ProceduresUsing Procedures
variables in the procedure's private local storage area, which consists of a primary anda secondary storage area.
Local Primary Area
The primary area for each procedure can store up to 127 words of the following kinds
of local variables:
Directly addressed simple variables, arrays, and structures
Pointers you declare
Implicit pointers (those the compiler provides when you declare indirect arrays orindirect structures)
When a procedure is activated, the compiler allocates storage at the current top of the
data stack for each direct local variable and each pointer.  The addresses of thevariables are at an increasingly higher offset from L[1].
Local Secondary Area
The local secondary area begins immediately after the last pointer or direct variable of
the procedure’s local primary area.  The local secondary area of a procedure has noexplicit size, but the total of all global and local primary and secondary areas cannotexceed the lower 32K-word area of the user data segment.
For each standard indirect array or structure you declare in the procedure:1. The compiler provides an implicit standard pointer and allocates a word of
storage for the pointer in the procedure’s local primary area.
2. The compiler allocates storage for the array or structure in the procedure’s
secondary area, which begins immediately following the procedure’s last directitem.
If you declare indirect arrays or indirect structures within BLOCK declarations,
however, the compiler allocates such data blocks anywhere in the procedure’ssecondary data blocks, as described in Section 14, “Compiling Programs.”
3. The compiler initializes the implicit pointer (provided in step 1) with the address
of the array or structure in the procedure’s secondary area.
For a STRING array, the pointer contains the byte address of the array.
For any other array, the pointer contains the word address of the array.
For a structure, the pointer contains the word address of the structure.
Allocating Parameters
and VariablesFigure 11-1 shows how the compiler allocates storage for the called procedure’s
parameters and variables in the procedure’s local primary and secondary storageareas.

Declaring Data in ProceduresUsing Procedures
Global storage area
Local storage for
main procedure
Local storage  for
called procedures
Parameter storage for
current procedure
Local storage for
current procedure
Sublocal data and
parameter storage for
current subprocedure
Available for dynamic
allocation by the TAL
compiler
G[32767]G[0]
L[0]
L[1]
S[0]Global  area
Local area
Sublocal area
Lower 32-K word area of
user data segment
Data allocation for current procedureStack marker for
current procedureDummy stack marker
for main procedure
Top of data stack
Limit of data stack

Using Procedure OptionsUsing Procedures
a ProcedureA called procedure returns control to the caller when a RETURN statement is executed
or the last END keyword is reached.  (In a nonfunction procedure, a RETURNstatement is optional.)  In the following example, MY_PROC returns control when A isless than B, which invokes the RETURN statement, or when the last END is reached:
PROC my_proc;
BEGIN  INT a, b;  !Lots of code  IF a < b THEN    RETURN;                !Return to caller if A < B  !Lots more code  END;                     !Last END keyword
Using Procedure
OptionsBy specifying procedure declaration options, you can declare:
The MAIN procedure
Functions
FORWARD procedures
EXTERNAL procedures
VARIABLE procedures
EXTENSIBLE procedures
Other procedure declaration options include:
Public name and LANGUAGE options, described in Section 17, “Mixed-Language
Programming.”
INTERRUPT, RESIDENT, CALLABLE, and PRIV options, described in the TAL
Reference Manual .  Most of these options are used only by system procedures.
Declaring the
MAIN ProcedureAn executable program requires a MAIN procedure.  It is the first procedure executed
when you run the program (although it often appears last.)  The MAIN procedurecannot have parameters.  If more than one MAIN procedure appears in a program, thecompiler issues a warning and uses the first one it encounters as the MAIN procedure.When the MAIN procedure completes execution, it passes control to thePROCESS_STOP_ system procedure, rather than executing an EXIT instruction.
To declare the MAIN procedure, include the MAIN keyword following the procedure
identifier:
PROC mymain MAIN;            !Declare MAIN procedure
BEGIN  !Lots of code  CALL some_procedure;  END;

Using Procedure OptionsUsing Procedures
declare a function as you would a procedure, plus you specify:
The data type  of the result value to be returned by the function
A RETURN statement that returns the result (and optionally a condition code)
For example, you can declare a function that has two formal parameters, multiplies
them, and returns an INT result to the caller:
INT PROC mult_function (var1, var2);  !INT return type
```
    INT var1, var2;       !Declare formal parameters  BEGIN  RETURN var1 * var2;     !RETURN statement returns result  END;                    !  and control to caller
```
Callers normally invoke functions by using the function identifiers in expressions.  For
example, an assignment statement in a procedure can invoke the precedingMULT_FUNCTION, passing two actual parameters to it:
PROC caller;              !Declare CALLER
BEGIN  INT num1 := 5,      num2 := 3,      answer;  answer := mult_function (num1, num2);                          !Assignment statement invokes  END;                    ! MULT_FUNCTION
For information on returning condition codes, see the RETURN statement in
Section 12, “Controlling Program Flow.”
Declaring FORWARD
ProceduresA FORWARD procedure declaration lets you call a procedure before you declare the
procedure.  You can then declare the procedure anywhere in the same compilationunit.
To declare a FORWARD procedure, specify the FORWARD keyword in place of the
procedure body.  For example, you can declare PROC1 as a FORWARD procedure,declare PROC2 which calls PROC1, and finally declare the body of PROC1:
PROC proc1 (param1, param2);    !Declare PROC1 as a FORWARD
```
    INT .param1, param2;         ! procedure    FORWARD;
```
PROC proc2 MAIN;                !Declare PROC2
BEGIN  INT i1 := 1;  CALL proc1 (i1, 2);           !Call PROC1  END;
PROC proc1 (param1, param2);    !Declare the real PROC1
```
    INT .param1, param2;  BEGIN  param1 := param1 - param2;  END;
```

Using Procedure OptionsUsing Procedures
ProceduresAn EXTERNAL procedure declaration lets the current compilation unit call a
procedure that is declared in another compilation unit.  The other compilation unit canbe a system library, a user library, or a user file.
To declare an EXTERNAL procedure, specify the EXTERNAL keyword in place of the
procedure body:
PROC PROCESS_DEBUG_; EXTERNAL; !Declare EXTERNAL procedurePROC issue_warning (param);
```
    INT param;  EXTERNAL;                    !Declare EXTERNAL procedure
```
PROC a MAIN;
BEGIN  INT x, y, z;  !Manipulate X, Y, and Z  If x = 5 THEN CALL issue_warning (5);                               !Call EXTERNAL procedure  CALL PROCESS_DEBUG_;         !Call EXTERNAL procedure  END;
Declaring VARIABLE
ProceduresFor a VARIABLE procedure, the compiler treats all formal parameters as if they were
optional, even if some are required by the procedure's code.  If you add newparameters to a VARIABLE procedure, all procedures that call it must be recompiled.
To declare a VARIABLE procedure, specify:
The data type  of the return value (optional)
The keyword PROC
The procedure identifier
The formal parameter list , enclosed in parentheses
The keyword VARIABLE, followed by a semicolon
The formal parameter declarations , each followed by a semicolon
The procedure body —a BEGIN-END construct that can include data declarations,
subprocedure declarations, and statements
Following is an example of a VARIABLE procedure declaration:
PROC v (a, b) VARIABLE;        !Declare VARIABLE procedure
```
    INT a;                     !Declare formal parameters    INT b;  BEGIN  !Lots of code  END;
```
Checking for Actual Parameters
Each VARIABLE procedure must check for the presence or absence of actual
parameters that are required by the procedure's code.  The procedure can use the$PARAM standard function to check for required or optional parameters.

Using Procedure OptionsUsing Procedures
required parameter is absent.  Also the procedure provides a default 0 to use if theoptional parameter is absent.
PROC errmsg (msg, count, errnum) VARIABLE;
```
    INT .msg;                  !Required by your code    INT count;                 !Required by your code    INT errnum;                !Optional  BEGIN  IF NOT $PARAM (msg) OR       !Check for required parameters     NOT $PARAM (count) THEN     RETURN;                   !Return to caller if either                               ! required parameter is absent  IF NOT $PARAM (errnum) THEN  !Check for optional parameter    errnum := 0;               !Use 0 if optional parameter                               ! is absent  !Process the error  END;
```
Declaring EXTENSIBLE
ProceduresAn EXTENSIBLE procedure lets you add new formal parameters to it without
recompiling callers unless the callers use the new parameters.  The compiler treats allparameters of an EXTENSIBLE procedure as if they were optional, even if some arerequired by the procedure's code.
To declare an EXTENSIBLE procedure, specify:
The data type  of the return value (optional)
The keyword PROC
The procedure identifier
The formal parameter list , enclosed in parentheses
The keyword EXTENSIBLE, followed by a semicolon
The formal parameter declarations , each followed by a semicolon
The procedure body —a BEGIN-END construct that can include local data
declarations, subprocedure declarations and statements
Following is an example of an EXTENSIBLE procedure declaration:
PROC x (a, b, c) EXTENSIBLE;    !Declare EXTENSIBLE procedure
```
    INT a;    INT(32) b;    FIXED c;  BEGIN  !Process the parameter values  END;
```
Checking for Actual Parameters
Each EXTENSIBLE procedure must check for the presence or absence of actual
parameters that are required by the procedure's code.  The procedure can use$PARAM to check for required or optional parameters.

Using Procedure OptionsUsing Procedures
either required parameter is absent.  Also the procedure provides a default 0 to use ifthe optional parameter is absent.
PROC errmsg (msg, count, errnum) EXTENSIBLE;
```
    INT .msg;                  !Required by your code    INT count;                 !Required by your code    INT errnum;                !Optional  BEGIN  IF NOT $PARAM (msg) OR       !Check for required parameters     NOT $PARAM (count) THEN     RETURN;                   !Return to caller if either                               ! required parameter is absent  IF NOT $PARAM (errnum) THEN  !Check for optional parameter    errnum := 0;               !Use 0 if optional parameter                               ! is absent  !Process the error  END;
```
Passing Parameters to
VARIABLE or EXTENSIBLE
ProceduresWhen you call a VARIABLE or EXTENSIBLE procedure, you can omit parameters
indicated as being optional in the called procedure.  You can pass or omit suchparameters unconditionally or conditionally.
Passing Parameters Unconditionally
To pass parameters or parameter pairs unconditionally, specify the parameter name in
the CALL statement parameter list.  To omit parameters or parameter pairsunconditionally, use a place-holding comma for each omitted parameter or parameterpair up to the last specified parameter.
Comments within a CALL statement can help you keep track of which actual
parameters you are omitting.  Here is an example:
PROC some_proc (index, error_num, length, limit, total)
EXTENSIBLE;    INT index, error_num, length, limit, .total;  BEGIN  !Lots of code  END;
PROC caller_proc;
BEGIN  INT total;  !Some code  CALL some_proc (0, !error_num!, !length!, 40, total);                             !Comments within CALL statement                             ! identify omitted parameters  !More code  END;

Using Procedure OptionsUsing Procedures
As of the D20 release, you can pass a parameter or parameter pair to a VARIABLE or
EXTENSIBLE procedure based on a condition at execution time by using the$OPTIONAL function.  $OPTIONAL is evaluated each time the encompassing CALLstatement is executed:
If the conditional expression is true, the actual parameter is passed.
If the conditional expression is false, the actual parameter is not passed.
In the following example, parameter pair S:I is passed because I equals 1, which is less
than 9.  Parameter J is not passed because J equals 1, which is not greater than 2.
PROC p1 (str:len, b) EXTENSIBLE;
```
    STRING .str;    INT len;    INT b;  BEGIN  !Lots of code  END;
```
PROC p2;
BEGIN  STRING .s[0:79];  INT i:= 1;  INT j:= 1;  CALL p1 ($OPTIONAL (i < 9, s:i),   !Pass S:I if I < 9.           $OPTIONAL (j > 2, j) );   !Pass J if J > 2.  END;
You can use $OPTIONAL and $PARAM when one procedure provides a front-end
interface for another procedure that does the actual work:
PROC p1 (i, j) EXTENSIBLE;
```
    INT .i;    INT .j;  BEGIN  !Lots of code  END;
```
PROC p2 (p, q) EXTENSIBLE;
```
    INT .p;    INT .q;  BEGIN  !Lots of code  CALL p1 ($OPTIONAL ($PARAM (p), p ),           $OPTIONAL ($PARAM (q), q ));  !Lots of code  END;
```

Using Procedure OptionsUsing Procedures
conditionally and one that is passed unconditionally.  The execution time is shorter,however, when you pass or omit a parameter unconditionally.
To make your code portable to future software platforms, use $OPTIONAL for each
optional parameter when calling a VARIABLE or EXTENSIBLE procedure.
Converting VARIABLE
Procedures to
EXTENSIBLEYou can convert a VARIABLE procedure into an EXTENSIBLE procedure.  When you
do so, the compiler converts the VARIABLE parameter mask into an EXTENSIBLEparameter mask.  Parameter masks are described later in this section.
Converting a VARIABLE procedure to EXTENSIBLE is the only way to add
parameters to the procedure without recompiling all its callers.  You can add newparameters at the time you convert the procedure or later.
You can convert any VARIABLE procedure that meets the following criteria:
It has at least one parameter.
It has at most 16 words of parameters.
All parameters are one word long except the last, which can be a word or longer.
The size of a formal reference parameter is one word if the address mode is standard;
the size is two words if the address mode is extended.
To convert an existing VARIABLE procedure to EXTENSIBLE, redeclare the procedure
and add the following information:
Any new formal parameters
The keyword EXTENSIBLE
The number of formal parameters in the VARIABLE procedure, specified as anINT value  in the range 1 through 15 and enclosed in parentheses
The following example converts a VARIABLE procedure and adds a new formal
parameter.  The value 3 in parentheses specifies that the procedure had three formalparameters before the procedure was converted from VARIABLE to EXTENSIBLE:
PROC errmsg (msg, count, errnum, new_param) EXTENSIBLE (3);
```
                            !Add NEW_PARAM to parameter list    INT .msg;    INT count;              !Redeclare existing parameters    INT errnum;    INT new_param;          !Declare NEW_PARAM  BEGIN  !Do something  END;
```

Comparing Procedures and SubproceduresUsing Procedures
Procedures and
SubproceduresProcedures and subprocedures are program units that can contain executable parts of
your program.  A subprocedure is declared inside a procedure.  A procedure cancontain any number of subprocedures, but a subprocedure cannot contain anothersubprocedure.  Neither procedures or subprocedures can contain another procedure.
You use procedures for operations needed throughout a program;  procedures are
callable from anywhere in the program.  You use subprocedures for operations neededwithin a procedure;  subprocedures are callable only from within the encompassingprocedure.
Procedures and subprocedures can declare formal parameters and receive data from
other procedures and subprocedures.  The same procedure or subprocedure canprocess different sets of data.  The system allocates a private data area for eachactivation of a procedure or subprocedure and deallocates that area when controlreturns to the caller.
When a procedure or subprocedure calls a procedure (or when a subprocedure calls a
subprocedure), the system saves the environment of the caller and restores it when thecalled procedure or subprocedure completes execution.
When a procedure calls a subprocedure, the caller’s environment remains in place
while the subprocedure executes.
Table 11-2 compares the characteristics of procedures and subprocedures.
Table 11-2.  Procedures and Subprocedures
Characteristic Procedure SubprocedureCan have formal parameters Yes, except MAIN procedure Yes
Can be a function and return a value Yes Yes
Can be recursive; it can call itself Yes YesPrivate primary storage 127 words local storage 32 words sublocal storagePrivate secondary storage Yes NoScope of procedure or subprocedure Global LocalScope of data Local SublocalCan refer to which level of variables Global or local Global, local, or sublocalAttributes MAIN
VARIABLEEXTENSIBLERESIDENTCALLABLEPRIVINTERRUPTLANGUAGE (D-seriessystem)VARIABLE
Other options FORWARD
EXTERNALFORWARD

Declaring and Calling SubproceduresUsing Procedures
SubproceduresTo declare a subprocedure in its simplest form, specify:
The keyword SUBPROC
The identifier  of the subprocedure, followed by a semicolon
A subprocedure body —a BEGIN-END construct that can contain sublocal data
declarations and statements
The following example declares MY_SUBPROC within MY_PROC.  A CALL statement
in MY_PROC then calls MY_SUBPROC:
PROC my_proc;                 !Declare MY_PROC
BEGIN  !Declare local data here
SUBPROC my_subproc;         !Declare MY_SUBPROC
```
    BEGIN    !Declare sublocal data here    !Specify sublocal statements here    END;                      !End MY_SUBPROC
```
!Specify local statements here
CALL my_subproc;            !Call MY_SUBPROC  END;                        !End MY_PROC
You can declare FORWARD, VARIABLE, or function subprocedures in the same way
as described for procedures (but inside a procedure).
Including Formal
ParametersSubprocedures have a 32-word storage area for all sublocal data including variables,
temporary results, parameters, and parameter mask if any.  In the following example,MAIN_PROC contains subprocedures SUB1 and SUB2.  MAIN_PROC calls SUB2.SUB2 calls SUB1 and passes parameters to it:
PROC main_proc MAIN;          !Declare MAIN_PROC
BEGIN  INT c := 0;
SUBPROC sub1 (param1);      !Declare SUB1
```
      INT param1;             !Declare formal parameter    BEGIN    INT a := 5;    INT b := 2;    param1 := a + b + c;    END;                      !End of SUB1
```
SUBPROC sub2;               !Declare SUB2
```
    BEGIN    INT var := 89;    CALL sub1 (var);          !Call SUB1    END;                      !End of SUB2
```
CALL sub2;
END;                        !End of MAIN_PROC

Declaring and Calling SubproceduresUsing Procedures
arrays or structures at the global or local level and make them indirect.  Insubprocedures,  declare only pointers and directly addressed variables as follows:
Valid Sublocal Variables ExampleSimple variables INT var;
Arrays INT array[0:5];
Read-only arrays INT ro_array = 'P' := [0,1,2,3,4,5];
Structures STRUCT struct_a;
```
    BEGIN    INT a, b, c;    END;
```
Simple pointers INT .simple_ptr;
Structure pointers STRING .struct_ptr (struct_a);
If you specify an indirection symbol (. or .EXT) when you declare sublocal arrays and
structures, the compiler allocates direct arrays and structures and issues a warning.
Invalid Sublocal Variables ExampleIndirect arrays INT .EXT ext_array[0:5];
Indirect structures STRUCT .EXT ext_struct;
```
    BEGIN    INT a, b, c;    END;
```
Visibility of Identifiers Sublocal statements can normally refer to sublocal identifiers in the subprocedure,
local identifiers in the procedure, and global identifiers.  If, however, you declare thesame identifiers (such as A and B ) at the sublocal, local, and global levels, thesubprocedure can access only the sublocal identifiers (A and B):
INT a := 9;                   !Declare global A and B
INT b := 3;
PROC a_proc MAIN;             !Declare A_PROC
BEGIN  INT a := 4;                 !Declare local A and B  INT b := 1;  INT c;
SUBPROC a_subproc (param);  !Declare A_SUBPROC
```
      INT param;    BEGIN    INT a := 5;               !Declare sublocal A and B    INT b := 2;    c := a + b + param;       !Access sublocal A and B    END;                      !End A_SUBPROC
```
a := a + b;                 !Access local A and B
CALL a_subproc (a);  END;                        !End A_PROC

Declaring and Calling SubproceduresUsing Procedures
LimitationsBecause sublocal storage area is so limited, the way you use sublocal variables is as
important as how many you declare.
When a subprocedure is activated, the compiler allocates the subprocedure's
parameters, variables, and temporary results of expressions in the subprocedure’sprivate storage area.  The compiler allocates each sublocal item at location S[0],pushing previously allocated sublocal items to increasingly negative offsets from S[0].If you attempt to access a sublocal item that is pushed beyond location S[–31], thecompiler issues an error.
To avoid problems, use just a few sublocal parameters and variables and avoid
complex expressions in subprocedures.  For example, avoid the following practice:
PROC main_proc MAIN;
BEGIN  SUBPROC sub_oops (f);        !Declare SUB_OOPS      INT .f;    BEGIN    INT  i[0:24];              !Use 25 sublocal words    f := 1;    f := (f * (f * (f * (f * (f * (f * (f * (f *         (f + 9) + 8) + 7) + 6) + 5) + 4) + 3) + 2) + 1);    END;                       !Too many temporary values  CALL sub_oops;  END;

Declaring and Calling SubproceduresUsing Procedures
Storage LimitationsThe order in which a subprocedure passes parameters could result in a range violation
error.  The error occurs when an actual parameter of the subprocedure refers to asublocal variable located beyond S[–31] in the caller’s sublocal storage area.
The following example shows two subprocedure calls.  The first call passes actual
parameters in reverse order, causing an error:
PROC my_proc MAIN;
BEGIN  !Lots of local declarations  SUBPROC sub1 (a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s);    INT         a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s;    BEGIN    END;  SUBPROC sub2;    BEGIN    INT         A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S;    CALL sub1  (
S,R,Q,P,O,N,M,L,K,J,I,H,G,F,E,D,C,B,A );
```
                                                 !Cause error    CALL sub1  (
```
A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S );
```
                                                 !No error    END;   !Actual parameters are shown in italics to           !distinguish them from variables in the text.  !Lots of code  END;
```
In effect, here is what happens:  When SUB2 is activated, the compiler allocates each
variable at location S[0] in the order declared (from A through S) and pushespreceding variables to increasingly negative offsets from S[0].  Part 1 of Figure 11-2shows the sublocal allocation immediately after activation of SUB2.
The first time SUB2 calls SUB1, SUB2 passes parameters in reverse order from the
order of the variables.  The compiler allocates each actual parameter at S[0], in theorder specified (from S through A) and pushes preceding variables and parameters
away from S[0].  Each parameter (when allocated at S[0]), must access thecorresponding variable to receive its value.  For example, parameter S must receive the
value stored in variable S, and so on.  When parameter D is allocated at S[0], variable
D is allocated at S[–31] and is still accessible.  When parameter C is allocated at S[0],
however, variable C is pushed beyond S[–31], is not accessible, and an error results.Part 2 of Figure 11-2 shows sublocal allocation at the point at which the error occurs.
The second time SUB2 calls SUB1, SUB2 passes parameters in the same order as the
variables, so each variable is accessible when the corresponding parameter is allocatedat S[0].  Part 3 of Figure 11-2, shows that every variable is accessible when thecorresponding parameter is allocated at S[0].

Declaring and Calling SubproceduresUsing Procedures
1. At activation of SUB2:
S[-31]
S[-30]
S[-29]
S[-28]
S[-27]
S[-26]
S[-25]
S[-24]
S[-23]
S[-22]
S[-21]
S[-20]
S[-19]
A S[-18]
B S[-17]
C S[-16]
D S[-15]
E S[-14]
F S[-13]
G S[-12]
H S[-11]
I S[-10]
J S[-9]
K S[-8]
L S[-7]
M S[-6]
N S[-5]
O S[-4]
P S[-3]
Q S[-2]
R S[-1]
S S[0]E S[-31]
F S[-30]
G S[-29]
H S[-28]
I S[-27]
J S[-26]
K S[-25]
L S[-24]
M S[-23]
N S[-22]
O S[-21]
P S[-20]
Q S[-19]
R S[-18]
S S[-17]
S S[-16]
R S[-15]
Q S[-14]
P S[-13]
O S[-12]
N S[-11]
M S[-10]
L S[-9]
K S[-8]
J S[-7]
I S[-6]
H S[-5]
G S[-4]
F S[-3]
E S[-2]
D S[-1]
C S[0]2. First call to SUB1:
338S[-31]
S[-30]
S[-29]
S[-28]
S[-27]
S[-26]
S[-25]
S[-24]
S[-23]
S[-22]
S[-21]
S[-20]
S S[-19]
A S[-18]
B S[-17]
S[-16] C
D S[-15]
E S[-14]
F S[-13]
G S[-12]
H S[-11]
S[-10]
J S[-9]
K S[-8]
L S[-7]
S[-6]
N S[-5]
O S[-4]
P S[-3]
Q S[-2]
R S[-1]
S S[0]3. Second call to SUB1:
Variables Actual parametersI
MRQPONMLKJIHG

Using ParametersUsing Procedures
parameters of procedures and subprocedures.
For portability to future software platforms, treat formal parameters as spatially
unrelated in memory storage.
Declaring Formal
ParametersTable 11-3 summarizes the formal parameter characteristics you can declare
depending on the kind of actual parameter your procedure expects.
Table 11-3.  Formal Parameter Specification
Formal Parameter Characteristics
Actual Parameter Formal Parameter Parameter Type Indirection Referral
Simple variable Value or reference STRING *
INT
INT(32)REALREAL(64)FIXED( n)
FIXED(*)Value, no;
reference,yesNo
Simple variable Value UNSIGNED No No
Array or
simple pointerReference STRING
INTINT(32)REALREAL(64)FIXED( n)Yes No
Definition structure.
referral structure, orstructure pointerReference INT or STRING Yes Yes
Definition structure,*
referral structure, or
structure pointerReference STRUCT Yes Yes
Constant expression **
(including @ identifier )Value STRING
INTINT(32)UNSIGNEDREALREAL(64)FIXED( n)No No
Procedure Value PROC
PROC(32) ***No No
*These features are not supported in future software platforms.
**The data type of the expression and of the formal parameter must match, except that you can
mix the STRING, INT, and UNSIGNED (1–16) data types, and you can mix the INT(32) andUNSIGNED(17–31) data types.
***PROC(32) is a D-series feature.

Using ParametersUsing Procedures
Using Value Parameters If a procedure or subprocedure declares a formal parameter as a value parameter,
callers in effect pass a copy of the actual parameter.  The called procedure orsubprocedure can modify the parameter as if it were a local or sublocal variable butcannot modify the original variable in the caller’s scope.
The compiler allocates storage for parameters in the parameter area of the called
procedure or subprocedure.  For value parameters, the kind of parameter and theparameter type determine the amount of space that is allocated.  Table 11-4summarizes the amount of storage the compiler allocates for formal value parameters:
Table 11-4.  Value Parameter Storage Allocation
Formal Parameter Parameter Type Allocation Actual ParameterSimple variable or
constant expressionSTRING
INT *
UNSIGNED(1–16) *Word Simple variable or
constant expression
Simple variable orconstant expressionINT(32) **
REAL
UNSIGNED(17–31)Doubleword Simple variable or
constant expression
Simple variable REAL(64)
FIXED(*)
FIXED( n)Quadrupleword Simple variable
Constant expression REAL(64)
FIXED( n)Quadrupleword Constant expression
16-bit procedure address PROC—or its alias
PROC(16)Word Procedure with 16-bit
address
32-bit procedure address PROC(32) Doubleword Procedure with 32-bit
address
*    An INT or UNSIGNED(16) actual parameter can be a standard address.
** An INT(32) actual parameter can be an extended address.
Simple Variables as Value Parameters
When you declare a simple variable as a formal value parameter, specify its parameter
type and identifier  but omit any indirection symbol:
PROC my_proc (a, b, c);
```
    INT a, b, c;         !Declare value parameters  BEGIN  !Lots of code  END;
```
Passing INT, INT(32), REAL, and REAL(64) simple variables as value parameters is
straightforward.  Passing STRING, FIXED, and UNSIGNED simple variables isdescribed in the following subsections.

Using ParametersUsing Procedures
possible because:
Passing STRING parameters by value is not portable to future software platforms.
The system places an actual STRING value in the right byte of a word as if thevalue were an INT expression.
If you do declare and pass STRING value parameters, you can use the following
techniques for accessing the STRING parameter value:
The called procedure can declare a DEFINE that indexes to the parameter value:
PROC p (s);
```
    STRING s;  BEGIN  DEFINE str = s[1]#;       !Declare DEFINE STR  IF str = "A" THEN ... ;   !Use STR instead of S  END;
```
The called procedure can left shift the parameter value by eight bits:
PROC p (s);
```
    STRING s;  BEGIN  s := s '<<' 8;            !Eight-bit left shift of value  !Lots of code  END;
```
The caller can left shift the parameter value in the actual parameter list by eight
bits:
CALL proc1 (byte '<<' 8);
FIXED Value Parameters.   If a FIXED actual parameter has a different fpoint  than the
formal parameter, the system applies the fpoint  of the formal parameter to the actual
parameter.
If, however, you specify parameter type FIXED( *), the called procedure treats the
actual parameter as having an fpoint  of 0.  That is, the system copies the content of the
actual parameter to the formal parameter without an fpoint .
UNSIGNED Value Parameters.   You can pass UNSIGNED parameters only as value
parameters.
Procedures as Value Parameters
You can specify procedures (but not subprocedures) as PROC or PROC(32) formal
parameters.

Using ParametersUsing Procedures
parameter is the address of:
A  C  small-memory-model routine
A FORTRAN routine compiled with the NOEXTENDEDREF directive
A TAL procedure or function procedure
For each actual PROC parameter, the compiler allocates a word of storage in the
parameter area of the called procedure.  The actual PROC parameter is a 16-bit addressthat contains the PEP and map information of the passed procedure.
The following example contains the following procedures:
GREATER_THAN, which is passed as an actual PROC parameter
BUBBLE_SORT, which declares the formal PROC parameter
SORT, which calls BUBBLE_SORT and passes GREATER_THAN to itLITERAL s = 10;
INT .a[0:s - 1] := [10,9,8,7,6,5,4,3,2,1];
INT PROC greater_than (a, b);  !Declare actual PROC parameter
```
    INT a, b;  BEGIN  IF a > b THEN RETURN -1  ELSE RETURN 0;  END;
```
PROC bubble_sort (array, size, compare_function);
```
    INT .array;    INT size;    INT PROC compare_function; !Declare formal PROC parameter  BEGIN  INT i, j, temp, limit;  limit := size - 1;  FOR i := 0 TO limit -1 DO    FOR j := i + 1 TO limit DO      IF compare_function (array[i], array[j]) THEN      BEGIN      temp := array[i];      array[i] := array[j];      array[j] := temp;      END;  END;
```
PROC sort MAIN;
BEGIN  CALL bubble_sort (a, s, greater_than);  END;

Using ParametersUsing Procedures
actual parameter is the address of:
A  C  large-memory-model routine
A FORTRAN routine compiled with the EXTENDEDREF directive
A Pascal routine
For each actual PROC(32) parameter, the compiler allocates a doubleword of storage
in the parameter area of the called procedure.  The actual PROC(32) parameter is a32 bit address (the high-order word contains the PEP and map information of thepassed routine;  the low-order word must contain a zero or a trap results).  For moreinformation, see Section 17, “Mixed-Language Programming,”
Procedures as Parameters That Have Parameters.   If a procedure declared as a formal
parameter has formal parameters of its own, you must ensure that its callers pass thenecessary actual parameters.  The compiler does not provide this check.  Callers mustprefix the identifier of each actual reference parameter with either:
The @ operator, which returns a standard address, either the address contained ina pointer or the address of a nonpointer item
The $XADR standard function, which returns an extended address for a variablethat has a standard address
The following example shows use of both @ and $XADR:
PROC a (f);                    !Declare procedure to
```
    STRING .EXT f;             ! pass as actual parameter  BEGIN  !Lots of code  END;
```
PROC hi (p);                   !Declare procedure to call
```
    PROC p;                    !Declare PROC formal parameter  BEGIN  STRING .s[0:7] := "Hi there";  CALL p ($XADR (s));          !Use $XADR  END;
```
PROC bye (p);                  !Declare procedure to call
```
    PROC p;                    !Declare PROC formal parameter  BEGIN  STRING .EXT s[0:6] := "Bye bye";  CALL p (@s);                 !Use @ operator  END;
```
PROC m MAIN;                   !Declare caller procedure
BEGIN  CALL hi (a);                 !Call procedures HI and BYE  CALL bye (a);                ! and pass procedure A to both  END;

Using ParametersUsing Procedures
EXTENSIBLE procedure declared as a formal parameter, include an actual parameterlist as usual.  For each omitted actual parameter, however, you must specify an emptycomma for each word of the parameter.  For example, to omit a FIXED parameter,specify four empty commas, one for each word of the omitted quadrupleword.
In the actual parameter list, you must also include a parameter mask that indicates
which parameters are passed and which are omitted.
In the following example, the actual parameter list in the call to PARAM_PROC
includes:
Two empty commas, one for each word of omitted INT(32) parameter named P2.
A parameter mask (%B101, where 1 denotes a passed parameter and 0 denotes anomitted parameter)
PROC var_proc (p1, p2, p3) VARIABLE;   !Declare VAR_PROC
```
    INT(32) p1, p2, p3;  BEGIN  !Lots of code  END;
```
PROC ext_proc (p1, p2, p3) EXTENSIBLE; !Declare EXT_PROC
```
    INT(32) p1, p2, p3;  BEGIN  !Lots of code  END;
```
PROC normal_proc (param_proc);         !Declare NORMAL_PROC
```
    PROC param_proc;  BEGIN  CALL param_proc (        !Call PARAM_PROC                   0d,     !Pass parameter for p1                   , ,     !Omit parameter for p2 (two words)                  -1d,     !Pass parameter for p3                  %B101);  !Pass parameter mask  END;
```
PROC m MAIN;
BEGIN  CALL normal_proc (var_proc);  CALL normal_proc (ext_proc);  END;
“Parameter Masks” later in this section describes the format of VARIABLE and
EXTENSIBLE parameter masks.  Section 17, “Mixed-Language Programming”describes the use of procedures as parameters in other languages.

Using ParametersUsing Procedures
You can pass the address of a variable or the content of a pointer as an actual value
parameter.  The called procedure can then assign the address to a pointer.
In the actual parameter list, prefix the identifier of the variable or pointer with the @
operator:
INT .EXT array1[0:9];
INT .EXT array2[0:9];INT .EXT ptr := @array2[9];
PROC move1 (x, y);
```
    INT(32) x;    INT(32) y;  BEGIN  INT .EXT xptr := x;  INT .EXT yptr := y;  INT i;  FOR i := 0 TO 9 DO    yptr[i] := xptr[i];  END;
```
PROC m1 MAIN;
BEGIN  CALL move1 (@array1, @ptr);  !Pass address of ARRAY1  END;                         ! and content of PTR
The following example is equivalent to the preceding example:
INT .EXT array1[0:9];
INT .EXT array2[0:9];INT .EXT ptr := @array2[9];
PROC move2 (x, y);
```
    INT .EXT x;    INT .EXT y;  BEGIN  INT .EXT xptr := @x;  INT .EXT yptr := @y;  INT i;  FOR i := 0 TO 9 DO    yptr[i] := xptr[i];  END;
```
PROC m2 MAIN;
BEGIN  CALL move2 (array1, ptr);  END;

Using ParametersUsing Procedures
When you call a procedure or subprocedure, you can pass the content of an index
register as a value parameter.  If the called procedure or subprocedure expects areference parameter, the compiler issues a warning.  When the compiler encountersthe invocation, it saves the content of the index registers, evaluates actual parameters,and branches to the called procedure or subprocedure.  On return to the caller, thecompiler restores the saved register content.
Passing the content of an index register as a parameter, however, is not portable to
future software platforms.  Also, if you accelerate your program for TNS/R systems,the Accelerator requires that you provide additional information, as described in theAccelerator Manual .
In support of existing programs, here are the steps for passing the content of an index
register:
1. Specify a USE statement to reserve an index register and give it a name .
2. Assign a value  to the index register.
3. Specify a CALL statement to pass the index identifier as a value parameter.4. Specify a DROP statement to free the index register.
Here is an example:
PROC some_proc (f);
```
    INT f;  BEGIN  !Lots of code  END;
```
PROC m MAIN;
BEGIN  USE x;               !Reserve and name an index register  x := 1;              !Assign a value to the index register  CALL some_proc (x);  !Pass the index register content  DROP x;              !Free the index register  END;

Using ParametersUsing Procedures
the index register contains the original (unmodified) content when control returns tothe caller, and the compiler emits an error message.  Avoid the following practice:
PROC some_proc (f);
```
    INT f;  BEGIN  !Lots of code  END;
```
PROC m MAIN;
BEGIN  USE x;  x := 1;              !X contains 1  !Lots of code  CALL some_proc (x := x + 2);                       !Pass X; change its value to 3                       !Upon return, X still contains 1  DROP x;  END;
If you must modify the content of an index register, assign a new value to the index
register before listing the index register in the CALL statement.  Here is an example:
PROC some_proc (f);
```
    INT f;  BEGIN  !Lots of code  END;
```
PROC m MAIN;
BEGIN  USE x;  x := 1;              !X contains 1  !Lots of code  x := x + 2;          !Assign new value to X  CALL some_proc (x);  !Pass X                       !Upon return, X contains 3  DROP x;  END;

Using ParametersUsing Procedures
ParametersA reference parameter is a formal parameter for which the caller passes the address of
a value.  The called procedure can access and modify the original value in the caller’sscope.  Except in the case of definition structures, you declare formal referenceparameters as if they were simple pointers or structure pointers (by using anindirection symbol).  When you list reference parameters in the actual parameter list,however, omit any indirection symbol.
The compiler allocates storage for parameters in the parameter area of the called
procedure or subprocedure.  For reference parameters, the standard or extendedaddressing mode determines the amount of space that is allocated.  Table 11-5summarizes the amount of storage the compiler allocates for formal referenceparameters:
Table 11-5.  Reference Parameter Storage Allocation
Formal Parameter Parameter Type Allocation Actual ParameterSimple pointer for
simple variableSTRING
INTINT(32)REALREAL(64)FIXED( n)
FIXED(*)Word (standard indirection) or
doubleword (extendedindirection)Address of simple
variable
Simple pointer forarraySTRING
INTINT(32)REALREAL(64)FIXED( n)Word (standard indirection) or
doubleword (extendedindirection)Address of array
Structure pointer or
indirect structureSTRING
INTSTRUCTWord (standard indirection) or
doubleword (extendedindirection)Address of
structure
Simple Variables as Reference Parameters
If a procedure expects a simple variable as an actual reference parameter, declare the
formal parameter as a simple pointer, preceding its identifier with an indirectionsymbol.

Using ParametersUsing Procedures
If a procedure expects an array as an actual parameter, declare the formal parameter as
a simple pointer, preceding its identifier with an indirection symbol.
The following example declares two formal reference parameters (for array elements)
as simple pointers, one standard and the other extended:
PROC new_proc (array1, array2, elements_to_move);
```
    INT .array1;       !Declare simple pointers as formal    INT .EXT array2;   ! parameters for array elements    INT elements_to_move;  BEGIN  !Manipulate the parameters  array1 ':=' array2 FOR elements_to_move ELEMENTS;  END;
```
Another procedure calls the preceding procedure and passes two arrays as actual
parameters.   No indirection symbols precede the array identifiers in the CALLstatement:
PROC main_proc MAIN;
BEGIN  INT first[0:99];     !Declare arrays to pass  INT second[0:99];
CALL new_proc (first, second, 100);
```
                       !Call NEW_PROC; pass  END;                 ! arrays by reference
```
Passing the Array Size.   When you pass an array, you also might need to pass the array
size or bounds information.  (The declaration of the formal parameter does notprovide such information.)
The following example passes array size information:
LITERAL array_size = 10;
INT .EXT array[0:array_size - 1];
PROC p (a, s);
```
    INT .EXT a;    INT s;  BEGIN  INT i;  INT n := s - 1;  FOR i := 0 TO n DO    a[i] := 0;  END;
```
PROC m MAIN;
BEGIN  CALL p (array, array_size);    !Pass array size  END;

Using ParametersUsing Procedures
LITERAL array_lb = 0;
LITERAL array_ub = 9;INT .array[array_lb:array_ub];
PROC zero (a, lb, ub);
```
    INT .a;    INT lb;    INT ub;BEGIN  INT i;  FOR i := lb TO ub DO    a[i] := 0;  END;
```
PROC m MAIN;
BEGIN  CALL zero (array, array_lb, array_ub);  END;                   !Pass lower and upper array bounds
Structures as Reference Parameters
Either definition structures or referral structures can be formal reference parameters.
You can treat them as if they were structure pointers.  For the address of the structure,the compiler allocates one word for a standard indirect structure and two words for anextended indirect structure.
Definition structures as parameters is described next, followed by referral structures as
parameters.  For portability to future software platforms, declare referral structures(rather than definition structures) as parameters where possible.
Definition Structures as Parameters.   When you declare a definition structure as a formal
reference parameter, include an indirection symbol and a structure layout :
PROC proc_a (def_struct);        !Declare PROC_A
```
    STRUCT .EXT def_struct;      !Declare definition      BEGIN                      ! structure as a      INT a;                     ! formal parameter      INT b;      END;  BEGIN  !Process the parameter  END;
```

Using ParametersUsing Procedures
parameter, include an indirection symbol and a referral  (enclosed in parentheses) that
provides the structure layout.  The referral can be the identifier of an existing structureor structure pointer.
In the following example, STRUCT_A is the referral in the formal parameter
declaration for REF_STRUCT:
STRUCT .EXT struct_a[0:99];     !Declare STRUCT_A
BEGIN  INT a;  INT b;  END;
PROC proc_a (ref_struct);       !Declare PROC_A;
```
    STRUCT .EXT ref_struct (struct_a);  BEGIN  !Process the parameter  END;
```
PROC m MAIN;
BEGIN  CALL proc_a (struct_a);  END;
Passing the Number of Structure Occurrences.   If the structure being passed has more than
one occurrence, you might need to pass the number of occurrences.  (The formalparameter declaration of the structure does not provide such information.)
PROC proc_b (ref_struct, ub);
```
    INT .EXT ref_struct (struct_a);    INT ub;  BEGIN  INT i;  FOR i := 0 TO ub DO    ref_struct[i].a := ref_struct[i].b := 0;  END;
```
FIXED Reference Parameters
If the fpoint  of an actual parameter does not match the fpoint  of the formal parameter,
the compiler issues a warning.  The system then applies the fpoint  of the formal
parameter to the actual parameter.

Using ParametersUsing Procedures
To pass the content of a pointer, prefix the pointer identifier with @ in the actual
parameter list.  The called procedure can then change the pointer content in the caller.An example is:
INT .array1[0:99];      !Declare ARRAY1
INT .array2[0:99];      !Declare ARRAY2
PROC proc1 (wptr);
```
    INT .wptr;          !Declare WPTR (formal parameter)  BEGIN  wptr := @array2[0];   !Assign address of ARRAY2[0] to WPTR  END;
```
PROC proc2 MAIN;
BEGIN  INT .my_ptr := @array1[0];  !Declare MY_PTR; initialize it with address of ARRAY1[0]
array1[0] := 100;
array2[0] := 200;  !MY_PTR = 100 before the following CALL statement  CALL proc1 (@my_ptr);  !MY_PTR = 200 after the preceding CALL statement
!Avoid the following CALL statement:
CALL proc1 (@array1);  !ARRAY1 now refers to ARRAY2; previous ARRAY1 value is lost  END;
Initializing Pointers Passed as Parameters
Before passing pointers as parameters, be sure they contain addresses:
INT .iptr;               !Declare IPTR
INT ivar := 0;           !Declare and initialize IVAR
PROC p (fiptr);
```
    INT .fiptr;          !Declare FIPTR  BEGIN  fiptr := 2;  END;
```
PROC m MAIN;
BEGIN  CALL p (iptr);         !Not OK, IPTR is not initialized  @iptr := @ivar;        !Assign address of IVAR to IPTR;                         ! IPTR = 0 before the following call  CALL p (iptr);         !OK, PTR now contains an address;                         ! IPTR = 2 after the call  END;

Using ParametersUsing Procedures
passing them as reference parameters:
STRUCT t ( *);
BEGIN  INT i;  !More structure items  END;
STRUCT .x (t);
STRING .a (t);          !Uninitialized structure pointer!or INT .a (t);!or STRING .EXT a (t);!or INT .EXT a (t);
PROC p (f);
```
    STRUCT .f (t);      !Formal reference parameter; the!or STRUCT .EXT f(t);   ! corresponding actual parameter!or STRING .f (t);      ! need not be declared in same way!or STRING .EXT f (t);!or INT .f (t);!or INT .EXT f (t);  BEGIN  f.i := 3;  END;
```
PROC m MAIN;
BEGIN  CALL p (a);           !Not OK, A is not initialized  CALL p (x);           !OK, X is initialized  @a := @x;             !Address of X is assigned to A  CALL p (a);           !OK, A contains a value  END;

Using ParametersUsing Procedures
When you pass a reference parameter, its addressing mode should match that of the
formal parameter.  If not, the compiler converts the addressing mode of the actualparameter to match that of the formal parameter.  When converting an address, thecompiler assumes that a STRING pointer contains a byte address and that a pointer ofany other type contains a word address.  In some conversions, part of the address islost.
Table 11-6 lists combinations of addressing modes and the kind of address that results
in each case.
Table 11-6.  Reference Parameter Address Conversions
Formal Parameter’s
Addressing ModeActual Parameter’s
Addressing Mode Converted Address of Actual Parameter
Standard byte Standard word Standard byte address *
Standard word Standard byte Standard word address **
Standard byte Extended word Standard byte address in segment 0 ***
Standard byte Extended byte Standard byte address in segment 0 ***
Standard word Extended word Standard word address in segment 0 ***
Standard word Extended byte Standard word address in segment 0  **   ***
Extended Standard Extended address
Extended word Extended byte No address conversion; the compiler issues a warning
*The most significant bit is lost.
**The left-or-right-byte specifier—bit 15 of a standard byte address, bit 31 of an extended byte
address—is lost or absent.  The converted address might access the wrong byte in a word.  Thecompiler issues a warning.
***The segment-number specifier—bits 2 through 14 of an extended address—is lost, so the
converted address defaults to segment 0, the current user data segment.  The compiler issuesa warning.
Parameter Pairs You can include formal parameter pairs when you declare a procedure or
subprocedure.  A parameter pair consists of two formal parameters connected by acolon that together describe a single data type to some programming languages.  Forinformation on using parameter pairs, see Section 17, “Mixed-LanguageProgramming.”

Using ParametersUsing Procedures
control passes to the called procedure, the system stores any actual parameter valuesin the private parameter area.
For each activation of a procedure, the parameter area provides storage for:
Up to 32 named parameters with no limit on the number of words of parameters.
(The compiler generates code for accessing parameter words beyond L-31.)
One of the following parameter masks, if present:
A one-word or doubleword VARIABLE parameter mask
A one-word to eight-word EXTENSIBLE parameter mask, plus a word valuethat represents the number of parameter words passed, stored in its negativeform
Subprocedure
Parameter AreaThe system creates a private parameter area for each activation of a subprocedure.
Before control passes to the called subprocedure, the system stores any actualparameter values in the private parameter area.
For each activation of a subprocedure, the parameter area provides storage for up to 30
words of parameters, less storage required for sublocal variables and for a word ordoubleword parameter mask, if present.
Scope of Formal
ParametersThe scope of an identifier is its visibility in the program; that is, the part of the
program from which the identifier is accessible.  Formal parameters have either:
Local scope if declared in a procedure
Sublocal scope if declared in a subprocedure
Normally, local statements can access global identifiers, and sublocal statements can
access local identifiers in the encompassing procedure and global identifiers.

Using ParametersUsing Procedures
statements cannot access the global identifier, and sublocal statements cannot accessthe local or global identifier:
INT a := 4;             !Declare global variables A and B
INT b := 1;
PROC p (a, b);
```
    INT a;              !Declare local formal parameters    INT b;              !  A and B  BEGIN  INT c;                !Declare local variable C
```
SUBPROC sub2 (b);
```
      INT b;            !Declare sublocal formal parameter B    BEGIN    c := b + 5;         !Access local C and sublocal B    END;                ! (not global or local B)
```
a := a + b;           !Access local A and B (not global
```
                        ! A and B)  CALL sub2 (a);        !Call subprocedure; pass local A  END;                  ! (not global A)
```

Parameter MasksUsing Procedures
provides a parameter mask and keeps track of which actual parameters are passed tothe procedure.
When a procedure calls a VARIABLE or EXTENSIBLE procedure that is declared as a
formal parameter, however, the compiler does not provide a parameter mask.  Thecaller must provide the parameter mask as part of the CALL statement.  For anexample, see “Procedures as Value Parameters” earlier in this section.
The following subsections describe how the compiler formats and allocates
VARIABLE and EXTENSIBLE parameter masks for the TNS system.  (The format ofVARIABLE masks differ from that of EXTENSIBLE masks.)
VARIABLE
Parameter MasksWhen a VARIABLE procedure is called, the compiler:
1. Allocates storage for each formal parameter in the called procedure’s parameter
area
2. Generates one of the following parameter masks:
A one-word mask for 16 or fewer formal parameters
A doubleword mask for 17 or more parameters
3. Initializes the mask bits to 04. Allocates storage for the parameter mask in the called procedure’s parameter area
as follows:
One-word mask—at location L[–3]
Doubleword mask—at location L[–3] for the low-order word and L[–4] for thehigh-order word
5. Associates each formal parameter with a bit in the parameter mask, right justifying
the layout in the mask, so the last parameter corresponds to bit <15> of the low-order word
6. Sets the bit for each passed parameter to 1

Parameter MasksUsing Procedures
If a VARIABLE procedure has 16 or fewer formal parameters, the compiler generates a
one-word mask.  It associates each formal parameter with a bit in the mask, rightjustifying the layout so the last parameter corresponds to bit <15>.
In the following example, PROC_A has six formal parameters.  Procedure A_CALLER
calls PROC_A and passes three actual parameters to it.  Each empty comma in theactual parameter list denotes an omitted parameter, regardless of size:
PROC proc_a (p1,p2,p3,p4,p5,p6) VARIABLE;
```
    INT p1,p2,p3,p4,p5,p6;  BEGIN  !Process the parameter values  END;
```
PROC a_caller MAIN;
BEGIN  INT x, y, z;  !Process the variables  CALL proc_a (,x,y,,z);    !Call PROC_A; pass three                            ! parameters (each empty comma  END;                      ! denotes an omitted parameter)
Figure 11-3  shows the parameter mask for the preceding example.  In this case, bits
<0:9> are not used and contain zeros.  Bits corresponding to passed parameters eachshow a 1, while bits corresponding to omitted parameters each show a 0.
Figure 11-3.  VARIABLE Word Parameter Mask
L [-3]:
Actual parameters:
Formal parameters:00000000000110100123456789 1 0 1 1 1 2 1 3 1 4 1 5
P1X
P2Y
P3 P4Z
P5 P6

Parameter MasksUsing Procedures
Figure 11-4 shows the parameter area of PROC_A when called by A_CALLER in the
preceding example.  The figure shows:
Storage allocation for the formal parameters P1 through P6 of PROC_A
Storage of actual parameters X, Y, and Z  passed by A_CALLER
Storage of the parameter mask of PROC_A.
The value of the parameter mask (%000032) represents the bit settings for the actual
parameters (shown in Figure 11-3 earlier in this section).
Figure 11-4.  Parameter Area of a VARIABLE Procedure
Word parameter maskLocal data for
A_CALLER
Omitted
X
Y
ZOmitted
Omitted
%000032
Stack marker
Local data
for PROC_A Formal
parameter
allocation Actual parameter storage
P1
P2P3P4P5P6
L[n]L[1]L[-3]L[-9]
L[0]
Procedure parameter area

Parameter MasksUsing Procedures
If a VARIABLE procedure has more than 16 parameters, the compiler generates a
doubleword mask.  It allocates the high-order word of the mask in location L[–4] andthe low-order word of the mask in location L[–3].
The compiler associates each formal parameter with a bit in the mask, right-justifying
the layout so the last formal parameter corresponds to bit <15> of the low-order word.
In the following example, PROC_B has 18 formal parameters.  Procedure B_CALLER
calls PROC_B and passes five parameters to it:
PROC proc_b (a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r) VARIABLE;
```
    INT a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r;  BEGIN  !Process the parameter values  END;
```
PROC b_caller;
BEGIN  INT aa, dd, ee, ff, jj;  !Lots of code  CALL proc_b (aa,!bb!,!cc!,dd,ee,ff,!gg!,!hh!,!ii!,jj);                           !Pass AA, DD, EE, FF, and JJ                           ! (comments denote omitted  END;                     ! parameters)
Figure 11-5  shows the doubleword parameter mask for the preceding example.  In this
case, bits <0:13> in the high-order word are not used and contain zeros.  Bitscorresponding to passed parameters each show a 1, while bits corresponding toomitted parameters each show a 0.
Figure 11-5.  VARIABLE Doubleword Parameter Mask
L [-4]:
Actual parameters:
Formal parameters:00000000000000100123456789 1 0 1 1 1 2 1 3 1 4 1 5
AA
AB
L [-3]:
Actual parameters:
Formal parameters:0111000100000000
CDD
DEE
EFF
FGHIJJ
JKLMNOPQR

Parameter MasksUsing Procedures
Parameter MasksWhen a procedure calls an EXTENSIBLE procedure, the compiler provides a
parameter mask and keeps track of which actual parameters are passed to theprocedure.
The format of the EXTENSIBLE parameter mask differs from the format of the
VARIABLE parameter mask.
When an EXTENSIBLE procedure is called, the compiler:1. Allocates storage for each formal parameter in the called procedure’s parameter
area
2. Generates a one-word to eight-word parameter mask, depending on how many
words must be allocated to hold the formal parameters
3. Initializes the mask bits to 04. Allocates storage for the mask in the called procedure’s parameter area as follows:
Location L[–4] for the lowest order word of the mask, location L[–5] for the
second lowest order word if needed, and so on
Location L[–3] for the number of words of parameters in its negative form
6. Associates each word of the formal parameters with a bit in the mask, left justified,
so that the highest order word of the first parameter corresponds to bit <0> of thelowest order word of the mask
7. Sets the bits associated with each passed parameter word to 1

Parameter MasksUsing Procedures
If an EXTENSIBLE procedure has 16 or fewer parameter words, the compiler generates
a one-word mask.  The compiler associates each word in each formal parameter with abit in the parameter mask, left justifying the layout so the first parameter wordcorresponds to bit <0>.
In the following example, PROC_C has seven formal parameters of varying lengths.
Procedure C_CALLER calls PROC_C and passes four actual parameters, totaling sevenparameter words:
PROC proc_c (a,b,c,d,e,f,g) EXTENSIBLE;
```
    INT     a,d,f,g;    INT(32) b,e;    FIXED   c;  BEGIN  !Code for processing  END;
```
PROC c_caller;
BEGIN  INT aa, ff, gg;  FIXED cc;  !Code for processing  CALL proc_c (aa,,cc,,,ff,gg);  END;
Figure 11-6 shows the parameter mask for the preceding example.  In this case, bits
<12:15> are not used and contain zeros.  Bits corresponding to passed parameters eachshow a 1, while bits corresponding to omitted parameters each show a 0.
Figure 11-6.  EXTENSIBLE Word Parameter Mask
L [-4]:
Actual parameters:
Formal parameters:
AA
ABCC
CD EFF
FGG
G0123456789 1 0 1 1 1 2 1 3 1 4 1 5
The compiler stores the number of parameter words passed (in its negative form) at
location L[–3].  For the preceding example, the value stored is –7.

Parameter MasksUsing Procedures
If an EXTENSIBLE procedure has more than 16 (but less than 33) parameter words, the
compiler generates a doubleword mask.  It associates each word of each formalparameter with a bit in the mask, left justifying the layout so the first parameter wordcorresponds to bit <0> of the low-order word.
In the following example, PROC_D has 12 formal parameters of varying lengths.
Procedure D_CALLER calls PROC_D and passes five actual parameters, totaling nineparameter words.
PROC proc_d (a,b,c,d,e,f,g,h,i,j,k,l) EXTENSIBLE;
```
    INT     a,d,f,g,k,l;    INT(32) b,e,h,i,j;    FIXED   c;  BEGIN  !Do more work  END;
```
PROC d_caller;
BEGIN  INT aa, ff, gg;  FIXED cc;  INT(32) jj;  !Do some work  CALL proc_d (aa,,cc,,,ff,gg,,,jj);  END;
Figure 11-7 shows the parameter mask settings for the preceding example.  In this
case, bits <4:15> of the high-order word (L[–5]) are not used and contain zeros.  Bitscorresponding to passed parameters each show a 1, while bits corresponding toomitted parameters each show a 0.
Figure 11-7.  EXTENSIBLE Doubleword Parameter Mask
L [-5]:
Actual parameters:
Formal parameters:
L [-4]:
Actual parameters:
Formal parameters:
342110000000000000001234567891 0 1 1 1 2 1 3 1 4 1 5
JJ
JK L
AA
ABCC
CD EFF
FGG
GH I
The compiler stores the number of passed parameter words (in its negative form) at
location L[–3].  For the preceding example, the value stored is –9.

Parameter MasksUsing Procedures
Figure 11-8 shows the parameter area of PROC_D when PROC_D is called by
D_CALLER in the preceding example.  The figure shows:
Storage allocation for the formal parameters of PROC_D
Storage of actual parameters passed by D_CALLER
Storage of the parameter mask of PROC_D
Storage of the number of parameter words passed

Parameter MasksUsing Procedures
344Local data for
D_CALLERActual parameter storage
Omitted
Formal
parameter
allocation A
B
Stack marker
Local data
for PROC_DDoubleword parameter mask
L[n]L[-3]
L[1]L[0]
Procedure parameter areaOmitted
OmittedOmitted
GGOmitted
OmittedC
D
E
F
G
H
I
J
KAA
CC
FF
-9Number of parameter words
passed (in negative form)L[-4]L[-5]OmittedJJL[-25]
L
%140000
%117060

Parameter MasksUsing Procedures
When an EXTENSIBLE procedure is activated, the procedure’s entry code loads
certain values onto the register stack.  Table 11-7 shows:
The values that the entry code loads onto the register stack
The RP setting that results
Table 11-7.  Entry Values Loaded Onto Register Stack
Kind of ProcedureRegister
Stack Value LoadedRP
Setting
EXTENSIBLE R[0] Number of parameter words expected 0
EXTENSIBLE, converted R[0] Number of parameters when procedure was
VARIABLE
R[1] Number of parameter words when procedure
was VARIABLE
R[2] Number of parameter words now expected 2
The procedure’s entry code then executes an ESE instruction, which uses the RP
setting to tell the cases apart.  ESE sets RP to 7 but does not save the values in R0through R7.
For a converted VARIABLE procedure, ESE converts the mask format to the
EXTENSIBLE format.  ESE adds the needed bits and words and initializes them to 0.  Itdoes not initialize any extra words on the register stack caused by the stack movement.
For information on the RP setting and ESE instruction, see the System Description
Manual  for your system.

Using LabelsUsing Procedures
have local or sublocal scope only.
Labels are the only declarable objects that you need not declare before using them.  For
best program management, however, declare all labels.
Using Local Labels To declare and use local labels:
1. Declare the label identifier  inside a procedure (in the local declarations) by
specifying the keyword LABEL and the label identifier; for example:
LABEL loc_label;          !Declare LOC_LABEL
2. Place the label identifier and a colon (:) preceding a statement in the same
procedure (but not in a subprocedure); for example:
loc_label:                 !Use the label for
a := 5;                    ! this statement
3. Reference the label in a GOTO statement located in the same procedure or in any
subprocedure contained in that procedure.
You can branch to local labels by using local or sublocal GOTO statements in the same
procedure.  In the following example, a local GOTO statement references a local label:
INT op1, op2, result;         !Declare global data
PROC p;  BEGIN  LABEL addr;                 !Declare label ADDR  op1 := 5;  op2 := 28;addr:                         !Use label ADDR for  result := op1 + op2;        ! this statement  op1 := op2 * 299;  !More code  IF result < 100 THEN    GOTO addr;                !Branch to label ADDR  END;

Using LabelsUsing Procedures
encompassing procedure.  Future software platforms require that you declare locallabels to which sublocal GOTO statements refer:
PROC p;
BEGIN  LABEL a;      !Declare label A  INT i;
SUBPROC s;
```
    BEGIN    !Lots of code    GOTO a;     !This branch is portable to future                ! software platforms; label A is declared    GOTO b;     !This branch is not portable; label B is                ! not declared    END;
```
!Lots of code
a : i := 0;  !More codeb : i := 1;  !Still more code  END;
When a local label and a sublocal variable in a procedure have the same identifier and
that identifier is referenced within the subprocedure, the sublocal variable is accessedinstead of the label:
INT data;PROC a;                        !Declare procedure A,
BEGIN                        ! which has global scope.  LABEL a;                     !Declare local label A.
SUBPROC sp;
```
    BEGIN    INT a;                     !Declare sublocal variable A.    data := @a;                !Assign address of sublocal A,                               ! not of procedure A or    END;                       ! local label A.a:  CALL sp;  END;
```

Using LabelsUsing Procedures
1. Declare the label identifier  inside a subprocedure in the sublocal declarations; for
example:
LABEL sub_label;            !Declare SUB_LABEL
2. Place the label identifier and a colon (:) preceding a statement in the same
subprocedure:
sub_label:                  !Use the label for
a := 5;                     ! this statement
3. Reference the label in a GOTO statement located in the same subprocedure.You can branch to sublocal labels by using GOTO statements in the same
subprocedure:
INT op1, op2, result;          !Declare global declarations
PROC p;  BEGIN  !Declare local variables  LABEL exit;                  !Declare local label EXIT
SUBPROC s;                   !Declare subprocedure
```
    BEGIN    LABEL addr;                !Declare sublocal label ADDR    op1 := 5;    op2 := 28;addr:                          !Use label ADDR for    result := op1 + op2;       ! this statement    IF result < 0 THEN         !If overflow, exit the      GOTO exit;               ! subprocedure to label EXIT    result := op2 * 2;    !Lots of code    IF result < 100 THEN       !If result < 100, go to      GOTO addr;               ! label ADDR    END;                       !End subprocedure  !Lots of codeexit:                          !Use label EXIT for  CALL s;                      ! this statement  !More code  END;                         !End procedure
```

Using LabelsUsing Procedures
undeclared label in the same scope have the same identifier and if you use the labelbefore you access the variable, the compiler issues an error message.
No error results from the following example because the assignment to the variable
occurs before the label is used:
INT data;PROC p;
BEGIN  INT a;             !Declare local variable A
SUBPROC sp;
```
    BEGIN    data := @a;      !Assign address of local variable A                     ! because sublocal label A is not                     ! declared and not used yet  a:                 !Use sublocal label A    data := @a;      !Assign address of sublocal label A    END;  CALL sp;  END;
```
Applying @ to a label name is not portable to future software platforms.

Getting Addresses of Procedures and SubproceduresUsing Procedures
Procedures and
SubproceduresTo get the address of a procedure or subprocedure, prefix its identifier with @.  For
example, to assign the address of MY_PROC to MY_VAR, specify:
my_var := @my_proc;
When prefixed to procedure or subprocedure identifiers, @ yields 16-bit addresses as
follows:
Item Address Yielded by @ Operator
Procedure Procedure entry point (PEP) number of the procedure
LORed with code segment information
Subprocedure Word address of the subprocedure’s entry point in the
current code segment
The LOR operator performs a bit-wise logical OR operation on INT or STRING values
and returns a 16-bit result, as described in Section 5, “Using Expressions.”
You can get the PEP number, which is contained in bits <7:15> of the procedure’s
address, as follows:
PROC my_proc MAIN;             !Declare MY_PROC
BEGIN  INT pepnum;  !Some code  pepnum := @my_proc.<7:15>;   !Assign PEP number of MY_PROC  !More code  END;
You can get the code location of a subprocedure as follows:
PROC my_proc;
BEGIN  INT sub_loc;
SUBPROC my_subproc;          !Declare MY_SUBPROC
```
    BEGIN    !Some code    sub_loc := @my_subproc;   !Assign address of MY_SUBPROC    !More code    END;
```
END;
Applying @ to a procedure name and using PEP or XEP table entries are not portable
to future software platforms.