# Section 15: Compiler Listing

TAL listing can consist of:
Page header
Banner
Compiler messages
Source listing
Local or sublocal map
INNERLIST listing
CODE listing
ICODE listing
File map
Global map
Cross-reference listings
LMAP listings
Compilation statistics
Page Header The header for each page consists of:
The page number of the listing
The sequence number for the current source file
The name of the current source file
The date and time of compilation in the form yy-mm-dd hh:mm:ss  (not shown)
An optional page heading caused by the PAGE directive or by the compiler
In a listing for multiple source files, the header for pages that contain load maps, cross-
references, and statistics shows the name and number of the first file.  Figure 15-1shows the format of the header:
Figure 15-1.  Page Headers
Page No.  Source File   Source File Name      Optional Heading
Page 1       [1]        $VOL.PROG1.SOURCE1S
Page 2       [2]        $VOL.PROG1.SOURCE2S   MY ROOT SOURCE FILEPage 3       [2]        $VOL.PROG1.SOURCE2S   MY ROOT SOURCE FILEPage 4       [3]        $SHR.MSGXX.IMSGSHRS   INTERPROCESS MESSAGESPage 59      [1]        $VOL.PROG1.SOURCE1S   GLOBAL MAPPage 66      [1]        $VOL.PROG1.SOURCE1S   LOAD MAPSPage 70      [1]        $VOL.PROG1.SOURCE1    BINDER AND COMPILER                                              STATISTICS

BannerCompiler Listing
compiler version and the copyright notice.  Figure 15-2 shows a sample  banner.
Figure 15-2.  Sample Banner
TAL - T9250D20 - (01JUN93)
Directives in
Compilation
CommandsThe line following the banner shows the directives you specified in the compilation
command to run the compiler.  For example, if you issue the following compilationcommand:
TAL /in mysrc, out mylst/ myobj; FMAP, ICODE
the line following the banner is:
? FMAP, ICODE
The compiler must process the EXTENDTALHEAP, SQL, and SYMBOLPAGES
directives before it processes any other directives.  On a D-series system, if you specifyany of these three directives in the compilation command along with other directives,the compiler splits the command into two lines in the listing.  The first line listsEXTENDTALHEAP, SQL, and SYMBOLPAGES, if present.  The second line lists theremaining directives specified in the command.
For example, suppose you issue the following compilation command:
TAL /in .../ myobj; FMAP, SQL, ICODE, SYMBOLPAGES 4096
In a D-series listing, the directives listed in the preceding compilation command
appear on two lines as follows:
?       SQL,        SYMBOLPAGES 4096
? FMAP,      ICODE
In a C-series listing, the directives listed in the preceding compilation command
appear on the same line:
? FMAP, SQL, ICODE, SYMBOLPAGES 4096
After the list of directives specified in the compilation command, the compiler lists the
source text if the LIST directive is in effect.
Compiler Messages When the compiler detects unusual conditions, it issues diagnostic messagesinterleaved with source statements.  BINSERV diagnostic messages appear during andafter the source listing.

Source ListingCompiler Listing
line consists of:
The edit-file line number
The code-address field
The lexical (nesting) level of the source text
The BEGIN-END pair counter
A text line from the source file
For example, here are two lines from a source listing:
31.  000021  1  1    IF length THEN BEGIN
32.  000023  1  2      CALL FILE_OPEN_ (array1, out_file);
413Edit-file line numberLexical levelSource text line
Code-address fieldBEGIN-END counter
Edit-File Line Number An edit-file line number precedes each line of source text.  For text that is included in
response to a SOURCE directive, the edit-file line numbers correspond to the filenamed in the SOURCE directive.
Code-Address Field The code address is a six-digit octal number.  Depending on the line of source text, it
represents an instruction offset or a secondary global count.
For a line of data declarations, the code-address value is a cumulative count of the
amount of secondary global storage allocated for the program.  The count is relative tothe beginning of the secondary global storage.  The beginning address is one greaterthan the last address assigned to primary global storage.
For a line of instructions, the code-address value is the address of the first instruction
generated from the TAL source statement on the line.  Normally, the octal value is theoffset from the base of the current procedure; the instruction at the base has an offsetof zero.  Adding the offset to the procedure base address yields the code-relativeaddress of the instruction.  The procedure base address is listed in the entry-point loadmap (described later in this section).
If a procedure or subprocedure has initialized data declarations, the compiler emits
code to initialize the data at the start of the procedure or subprocedure.  The offset orcode address listed for the first instruction is greater than one to allow for theinitialization code.

Source ListingCompiler Listing
line relative to location C[0].  The limitations on the use of ABSLIST are given in thedirective description in the TAL Reference Manual .
Lexical-Level Counter The lexical-level counter is a single-digit value that represents the compiler’s
interpretation of the current source line.  The values have the following meaning:
Value Lexical Level0 Global level
1 Procedure level
2 Subprocedure level
BEGIN-END Pair Counter The BEGIN-END pair counter indicates approximately the nesting of data elements
(such as structures and substructures) and compound statements (such as IFstatements, CASE statements, and CASE expressions).  For unlabeled CASEstatements, the counter also indicates the case selector.
To count BEGIN keywords and to match each with an END keyword in structure
declarations and in instructions that generate code, the compiler increments thecounter for each BEGIN and decrements it for each END.  The compiler displays thevalue of the counter for each line of source text, except when it reports CASE selectorvalues.
When listing a CASE statement body, the compiler reports the case selector in the form
CEn, where n represents the case selector number.  The compiler prints this string in
the BEGIN-END pair counter column of the next line it displays when it hasrecognized the corresponding CASE branch.  Because the compiler uses only one pass,however, by the time the compiler can distinguish an unlabeled CASE statement froma labeled one, it is usually too late to print the CE0 tag on the first line of casealternative zero.  If case alternative zero constitutes only one line, the CE0 tag does notappear at all.
Figure 15-3 shows part of a sample listing page that illustrates the BEGIN-END pair
counter.

Source ListingCompiler Listing
```
                     ?ICODE, SYMBOLS, SAVEABEND, INSPECT
```
2.  000000  0  0  NAME mymodule;   3.  000000  0  0   4.  000000  0  0  ?SOURCE outdSource file:  [2]  $VOL.PROG1.OUTD      1993-04-22  09:22:45   1.  000000  0  0  !Size declarations   2.  000000  0  0   3.  000000  0  0  BLOCK out_data;   4.  000000  0  0  LITERAL   5.  000000  0  0    outblklen = 1024,   6.  000000  0  0    out_rec_len = 256;   7.  000000  0  0  END BLOCK;   5.  000000  0  0Source file:  [1]  $VOL.PROG1.SOURCE1S  1993-05-13  19:18:07         .         .  24.  000000  0  0  PROC myproc;  25.  000000  1  0    BEGIN  26.  000000  1  1    STRING array1[0:7] := [" TPR   "];  27.  000004  1  1    INT array2[0:11];  28.  000004  1  1    INT length, error;         .         .  31.  000021  1  1    IF length THEN BEGIN  32.  000023  1  2      CALL FILE_OPEN_ (array1, out_file);  33.  000032  1  2      IF < THEN BEGIN  34.  000033  1  3        CALL file_hndle (out_file, error);         .         .  37.  000051  1  3        END;  38.  000051  1  2      END  39.  000051  1  1    ELSE BEGIN
Conditional
Compilation ListingAn asterisk ( *) in column 10 marks statements not compiled because of a conditional
compilation directive (IF or IFNOT).

Local or Sublocal MapCompiler Listing
identifiers follows the corresponding source listing and gives information on theidentifier class of an object, its variable type, and addressing.  Table 15-1 lists thecolumn headings and possible values.  Only one of the columns named AddressingMode, Offset, or Value appears in the map.
Table 15-1.  Local/Sublocal Map Information
Column
HeadingMeaning Possible Value
Class The Identifier class of the item.
Variable (bytes-in-octal) denotes astructure.Variable
Variable  ( bytes-in-octa l)
SubprocEntryLabelDefineLiteral
Type For a VARIABLE class item, the
data type or kind of structure.STRUCT-I denotes an INT structurepointer.STRING
INTINT(32)REALREAL(64)FIXEDSTRUCTSTRUCT-ISUBSTRUCTTEMPLATE  ( bytes-in-octal )
Addressing
ModeThe direct or indirect addressing
mode of the item.Direct
Indirect
Offset The offset of a SUBPROC, ENTRY,
or LABEL, relative to the base ofthe mapped PROC or SUBPROC.For a nested SUBPROC, the basecorresponds to the current map.%nnnnnn
Value The value of a LITERAL or the text
of a DEFINE truncated at the end ofthe listing line.LITERAL value
DEFINE text
Relative
AddressFor data, the base (L+, L-, P+, S-,
or X) and the offset from the base inoctalL+nnn  (local variable)
L–nnn   (local parameter)
P+nnn  (read-only array)
S–nnn  (sublocal parameter or variable)
X00n    (index register)

INNERLIST ListingCompiler Listing
INT PROC compute_hash (name, table_len);
```
    INT .name;    INT(32) table_len;  BEGIN  INT int_table_len := $INT (table_len);  INT hash_val := 0;  USE name_index;  USE name_limit;
```
name_limit := name.<8:14>;
FOR name_index := 0 TO name_limit DO    hash_val := ((hash_val '<<' 3) LOR    hash_val.<0:2>) XOR name[name_index];  DROP name_index;  DROP name_limit;  RETURN $UDBL($INT (hash_val '*' 23971)) '\'    int_table_len;  END; !compute_hash
Figure 15-4.  Local Map
```
                                          Addressing        Relative
```
Identifier        Class        Type       Mode              Address
HASH_VAL          Variable     INT        Direct            L+002
INT_TABLE_LEN     Variable     INT        Direct            L+001NAME              Variable     INT        Indirect          L-005TABLE_LEN         Variable     INT(32)    Direct            L-004
INNERLIST Listing If the INNERLIST and LIST directives are in effect, the compiler lists the instruction
mnemonics generated for each statement after that statement.  If optimization isperformed, the compiler first lists the original code and then reports “Optimizerreplacing the last n instructions” and lists the optimized code.
Figure 15-5 shows a sample INNERLIST listing that corresponds to the previous hash
procedure.

INNERLIST ListingCompiler Listing
```
                        ?INNERLIST
     1     000000  0  0 INT PROC compute_hash (name, table_len);     2     000000  1  0     INT .name;     3     000000  1  0     INT(32) table_len;     4     000000  1  0   BEGIN     5     000000  1  1   INT int_table_len := $INT (table_len);     6     000000  1  1   INT hash_val := 0;     7     000000  1  1   USE name_index;000000  1  LDD    L-004000001  0  STAR       0000002  1  LDI     +000000003  7  PUSH     711     8     000004  1  1   USE name_limit;     9     000004  1  1    10     000004  1  1   name_limit := name.<8:14>;000004  0  LOAD L-005,I000005  0  LRS       01000006  0  ANRI    +177000007  7  STAR       6    11     000010  1  1   FOR name_index := 0 TO name_limit DO000010  0  LDI     -001000011  0  STAR       7Optimizer replacing the last 2 instructions.with next 1000010  7  LDXI  -001,7000011  0  LDRA       6000012  0  BUN     +000    12     000013  1  1     hash_val := ((hash_val '<<' 3) LOR    13                      hash_val.<0:2>) XOR name[name_index];000013  1  LOAD   L+002000014  1  LLS       03000015  2  LOAD   L+002000016  2  LRS       15000017  1  LOR000020  2  LOAD L-005,I,7000021  1  XOR000022  0  STOR   L+002000023  7  BOX   -011,7    14     000024  1  1   DROP name_index;    15     000024  1  1   DROP name_limit;    16     000024  1  1   RETURN $UDBL ($INT (hash_val '*' 23971)) '\'    17                      int_table_len;000024  0  LDI     +000000025  1  LOAD   L+002000026  2  LDLI    +135000027  2  ORRI     243000030  2  LMPY000031  1  STAR       1000032  2  LOAD   L+001000033  1  LDIV000034  0  STRP       0000035  0  EXIT     006    18     000036  1  1   END; !compute_hash
```

Global MapCompiler Listing
octal code listing following the local map if one exists.
Figure 15-6 shows a sample CODE listing that corresponds to the previous hash
procedure.  The octal address in the leftmost column is the offset from the procedurebase.  (If ABSLIST is in effect, the compiler attempts to list addresses relative to thecode segment.)  Each octal address is followed by eight words of instructions to theend of the procedure.
Figure 15-6.  CODE Listing
Address  Octal Instruction Words
000000   060704  000110  100000  024711  140705  030101  006177  000116
000010   103777  000136  010410  040402  030003  040402  030115  000011000020   143705  000012  044402  013767  100000  040402  005135  004243000030   000202  000111  040401  000203  000100  125006
ICODE Listing If the ICODE and LIST directives are in effect, the compiler produces an instruction
code mnemonic listing.  Figure 15-7 shows a sample ICODE listing that is equivalent tothe CODE sample.
Figure 15-7.  ICODE Listing
Line  Address  Instruction Mnemonics
9.    000000   1 LDD   L-004    0 STAR      0  1 LDI    +000  7 PUSH  711
10.   000004   0 LOAD  L-005,I  0 LRS      01  0 ANRI   +177  7 STAR  611.   000010   7 LDXI   -001,7  0 LDRA      6  0 BUN    +01013.   000013   1 LOAD  L+002    1 LLS      03  2 LOAD  L+002  2 LRS   15   1 LOR   2 LOAD                                                                                    L-005,I,7      000021   1 XOR            0 STOR  L+002  7 BOX    -011,715.   000024   0 LDI    +000    1 LOAD  L+002  2 LDLI   +135  2 ORRI  243  1 LMPY  2 STAR  1      000032   2 LOAD  L+001    1 LDIV         0 STRP      0  0 EXIT  006
Global Map If the GMAP, MAP, and LIST directives are in effect, the global map lists all identifiers
in the compilation unit.  If  the NOMAP directive appears at the end of the source file,the compiler suppresses the global map but not the local maps. Figure 15-8 showssample entries of a global map.

File Name MapCompiler Listing
Identifier     Class        Type        Class-Specific Information
PROCESS_STOP_  PROC                     EXTERNAL
ABENDPARAM     DEFINE                   OPTIONS.<10:10>AB_OPENERR     DEFINE                   %B00000000001DACCESS_JNK     DEFINE                   ASSIGN.OPTION1.<05:05>ACCESS_INFO    VARIABLE     TEMPLATE,402 1  INCL_LEN          0,2   INT 1  AC                2,2   INTAC_INFO_DEF    DEFINE                   BEGIN  INT INCL_LEN; INT AC[0:ADD_           LITERAL      INT         %000021ALL_FCB        DEFINE                   INT.$1[0:FSIZE-1]:=[FSIZE,%000AP_BLOCK       BLOCKAP_FILE_OK     PROC         INT         EXTERNALBLIST_CTL      VARIABLE,4   STRUCT      INDIRECT   BLST_P=001COD_PTR        VARIABLE     INT(32)     DIRECT     AP_BLOCK+002COMPRS         VARIABLE     INT         DIRECT     AP_BLOCK+011DIMEN_INFO     VARIABLE     TEMPLATE,16 1  NUM               0,2   INT 1  DOUCE             2,2   INT 1  DIM_T             4,12  SUBSTRUCT     2 LOW_C          4,1   STRING     2 UP_C           5,1   STRING     2 LOW_B          6,4   INT(32)     2 UP_B          12,4   INT(32)FILE_GETINFO_  PROC                     EXTERNALFNAMECOLLAPSE  PROC                     EXTERNAL
In the preceding example, the C-series equivalent for the D-series PROCESS_STOP_
procedure is ABEND; for FILE_GETINFO_, it is FILEINFO.
File Name Map When the FMAP directive is in effect, the compiler prints the file map, starting withthe first file it encounters and reporting each file introduced by SOURCE directivesand TACL ASSIGN and DEFINE commands.  The file map shows the complete nameof each file and the date and time when the file was last modified.  Figure 15-9 showsthe file map format for a multisource file listing.
Figure 15-9.  File Name Map
FILE MAP BY ORDINAL
File No.    Date           Time           Source File[1]         1992-12-31     15:30:14       $VOL.PROG1.SOURCE1S
[2]         1993-02-27     12:42:19       $VOL.PROG1.SOURCE2S[3]         1993-02-29      2:32:34       $SHR.MSGXX.IMSGSHRS

Cross-Reference ListingsCompiler Listing
ListingsTo collect cross-reference information, specify the CROSSREF directive without
parameters.  If LIST and NOSUPPRESS (the defaults) are in effect at the end of thesource file, the cross-reference listings follow the global map.  These listings are:
Source-file cross-reference listing (the first page)
Identifier cross-reference listing (subsequent pages)
Source-File
Cross-ReferencesFigure 15-10 shows the format of a source-file cross-reference listing.  It gives the
following information for each source file in the compilation:
File sequence number in the compilation
File name from a TAL RUN command or a SOURCE directive
Name of the source file that contained the SOURCE directive if any
Edit-file line number of the SOURCE directive if any
Figure 15-10.  Source-File Cross-Reference Listing
CROSSREF CROSS-REFERENCE PROGRAM-T9622D20 (01JUN93)           SYSTEM \X
File No.        Filename [1]            $VOL.PROG1.SOURCE1S
[2]            $VOL.PROG1.SOURCE2S              SOURCE1S[1]      0.1 [3]            $SYSTEM.SYSTEM.GPLDEFS           SOURCE2S[2]      2 [4]            $VOL.PROG1.SOURCE4S              SOURCE1S[1]      7 [5]            $SYSTEM.SYSTEM.EXTDECS           SOURCE1S[1]      8
Identifier Cross-References The identifier cross-reference listing gives the following information about each
specified identifier class:
Identifier qualifiers—structure, subprocedure, and procedure identifiers
Compiler attributes—identifier class and type
Host source file
Reference lines—type of references (read, write, declaration, or other)
Identifier Qualifiers
An item declared within a structure, subprocedure, or procedure can have from zero
to three levels of qualifiers (listed immediately following the identifier name).  Here isan example that shows the ordering of qualifier levels:
OF mystruct   OF mysubproc   OF myproc

Cross-Reference ListingsCompiler Listing
If an identifier has no qualifier, it is a global item.
GLOBAL_X
If an identifier has one qualifier, it is declared in a global structure or in a
procedure.
ITEM_A   OF GLOB_STRUCT_OR_PROC
If an identifier has two qualifiers, it is declared in either a structure or
subprocedure within a procedure.
ITEM_B   OF LOC_STRUCT_OR_SUBPROC   OF PROC_P
If an identifier has three qualifiers, it is declared in a structure within a
subprocedure within a procedure.
ITEM_C   OF SUBLOC_STRUCT   OF SUBPROC_Q   OF PROC_P
Compiler Attributes
Compiler attributes are class (as specified in the CROSSREF directive) and type
modifiers as listed in Table 15-2.
Table 15-2.  Compiler Attributes
Class ModifiersBLOCK None
DEFINE None
ENTRY TypeLABEL NoneLITERAL TypePROC Type, EXTERNALSUBPROC TypeTEMPLATE NoneVARIABLE Type, DIRECT or INDIRECTUNDEFINED None
Types that apply to the ENTRY, PROC, SUBPROC, and LITERAL classes are STRING,
INT, INT(32), REAL, REAL(64), and FIXED.  Type FIXED includes the scale  if it is
nonzero.
Types that apply to the VARIABLE class are those listed in Table 15-2 plus STRUCT,
SUBSTRUCT, STRUCT-I, STRUCT-S and UNSIGNED.

LMAP ListingsCompiler Listing
The abbreviated edit-file name of the host source file appears on the same line as the
identifier name.  The sequence number assigned to the source file appears in brackets.The line number where the declaration starts accompanies the file name.  An exampleis:
SOURCE1S[23]  137
Reference Lines
Reference lines include an entry for each reference in the compilation.  For each
reference line except read references, an alphabetic code indicates the type ofreference.  Codes are D (definition), I (invocation), P (parameter), W (write), and M(other).  Refer to the Crossref Manual  for additional information.
Identifier Cross-Reference Example
The identifier cross-reference pages begin with the format shown in Figure 15-11.  The
header line (only on the first page of references) lists the total number of symbolsreferenced and the total number of references.
Figure 15-11.  Identifier Cross-Reference Listing
152 TOTAL SYMBOLS COLLECTED WITH 61 TOTAL REFERENCES COLLECTED
ALLOCATE_CBS          DEFINE                   GPLDEFS[3]     15     GPLDEFS[3]  198
ALLOCATE_FCB          DEFINE                   GPLDEFS[3]     27     SOURCE2S[2]   5ASSIGN_BLOCKLENGTH    INT LITERAL              GPLDEFS[3]     81     GPLDEFS[3]   81.1   135DEFAULT_VOL           INT DIRECT VARIABLE      SOURCE4S[4]     2     SOURCE1S[1]  14 WMESSAGE OF STARTUP    INT INDIRECT VARIABLE    SOURCE1S[1]    12     SOURCE1S[1]   11 D    14MSG_CLOSE             EXTERNAL PROC            SOURCE4S[4]    10     SOURCE1S[1]  28 IRUCB                  INT INDIRECT VARIABLE    SOURCE2S[2]     5     SOURCE1S[1]  18 P
LMAP Listings Depending on the LMAP directive option in effect, BINSERV produces one of the
following maps:
Directive Kind of Load MapLMAP Same as LMAP ALPHA, the default
LMAP ALPHA Procedures and data blocks, ordered by name (the default)
LMAP LOC Procedures and data blocks, ordered by starting addressLMAP XREF Procedure and data-block cross-references for the object fileLMAP * Procedures and data blocks, ordered by name and by starting address, plus
cross-references for the object file

LMAP ListingsCompiler Listing
15-3 describes the information in each column of the map.
Table 15-3.  Entry-Point Load Map Information
Column MeaningSP Code segment number specifier for the entry point
PEP Sequence number of the entry point in the Procedure Entry Point (PEP) table
BASE Base address of the procedure defining the entry pointLIMIT End address of the procedure defining the entry pointENTRY Address of executable code for the entry pointATTRS Attributes of the entry point:  C (CALLABLE), E (ENTRY), I (INTERRUPT), M
(MAIN), P (PRIVILEGED), R (RESIDENT), V (VARIABLE), X (EXTENSIBLE)
NAME Entry-point nameDATE Date of compilationTIME Timestamp of the compilationLANGUAGE Source language of the procedureSOURCE FILE File name of the source code for the procedure
Figure 15-12 shows the format of a sample entry-point load map by name.
Figure 15-12.  Entry-Point Load Map by Name
ENTRY POINT MAP BY NAME
SP  PEP  Base    Limit   Entry   Attrs  Name       Date     Time   Language  Source File00  031  010345  043630  0010420        MY_PROC    11FEB93  18:13  TAL       $JNK.PRG1.SRCE1S
00  073  032224  032636  032224   V     ANY_PROC   11FEB93  10:29  TAL       $JNK.PRG1.SRCE2S00  020  000736  001072  000736   M     MAIN_PROC  11FEB93  13:38  TAL       $JNK.PRG1.MAINS00  367  131432  131441  131432   E     SORT_PROC  11FEB93  18:14  TAL       $JNK.PRG1.SORTS
Data-Block Load Maps BINSERV produces a data-block map and a read-only data-block map for primary and
secondary global blocks.  The data-block map lists the following kinds of data blocks:
Named blocks, listed by BLOCK declaration name
Private blocks, listed by NAME declaration name
#GLOBAL, .#GLOBAL, and $#GLOBAL implicit global data blocks
&template-name  implicit global data blocks
The read-only data-block map lists global read-only arrays, listed by name.

LMAP ListingsCompiler Listing
data-block load map give for each data block.
Table 15-4.  Data-Block Load Map Information
Column MeaningBASE Base address of the block
LIMIT End address of the block (blank if block is empty)
TYPE Binder data-block type; for TAL code, only the common blocks and the two special
blocks, $EXTENDED#STACK and EXTENDED#STACK#POINTERS, can occur
MODE Word or byte addressingNAME Data-block nameDATE Date of compilation in the form ddmmmyyTIME Timestamp for the compilation in the form hh:mmLANGUAGE Source language of the blockSOURCE FILE Edit-file name of the source file containing the block declaration
Figure 15-13 shows the format of a data-block load map by location.
Figure 15-13.  Data-Block Load Map by Location
DATA BLOCK MAP BY LOCATION
Base      Limit     Type      Mode    Name       Date       Time     Language   Source File000000    000014    COMMON    WORD    GLOBAL_    11FEB93    13:38    TAL        $VOL.PRG.GLBS
000015    000015    COMMON    WORD    LIB_PUB
Figure 15-14 shows the read-only data-block map.  The leftmost column in this map
gives the code segment number specifier for each read-only array.
Figure 15-14.  Read-Only Data-Block Load Map by Location
READ-ONLY DATA BLOCK MAP BY LOCATION
CODE SPACE 00
SP    Base      Limit     Type      Mode   Name   Date      Time    Language   Source File00    000025    000417    COMMON    WORD   HASH   11FEB93   10:48   TAL        $VOL.PRG.SRC1S
00    000055    000442    COMMON    WORD   TAB    11FEB93   10:48   TAL        $VOL.PRG.SRC1S

Compilation StatisticsCompiler Listing
SYNTAX directive is in effect or if source errors occur, the compiler does not print anyother statistics.  Figure 15-15 shows the statistics emitted when source errors stop thecompilation.
Figure 15-15.  Compiler Statistics
PAGE 3   $TRMNL [0]                     BINDER AND COMPILER STATISTICS
TAL - Transaction Application Language-T9250D20 - (01JUN93)
Number of compiler errors =  5  Last compiler error on page # 2 IN PROC C  Number of unsuppressed compiler warnings = 1  Number of warnings suppressed by NOWARN = 0  Last compiler warning on page # 1  Maximum symbol table space used was =       562 bytes  Number of source lines= 22  Compile cpu time = 00:00:45  Total Elapsed time = 00:02:58
Object-File Statistics If an object file results from the compilation, the compiler prints the following
BINSERV statistics preceding the compiler statistics:
Name of the constructed object file
Timestamp of the constructed object file
Number of words of primary data area
Number of words of secondary data area
Number of code pages
Minimum number of data pages required for data space allocation
Number of resident pages required for total code space allocation
Number of extended data pages allocated
Top of stack location
Number of code segments
Number of binder warnings
Number of binder errors

Compilation StatisticsCompiler Listing
Figure 15-16.  Object-File Statistics
PAGE 91   \SYS.$VOL.SUBV.SRC [1]        BINDER AND COMPILER STATISTICS
BINDER - OBJECT FILE BINDER - T9621D20 - (01JUN93)           SYSTEM \X
Object file name is $XVOL.XSUBVOL.OFILE
TIMESTAMP 1993-2-11 16:48:21
```
        45  Code pages        64  Data page
         0  Resident code pages         0  Resident data pages
       144  Top of stack location in words         1  Binder Warnings
         0  Binder Errors
```
TAL - Transaction Application Language - T9250D20 - (01JUN93)
Number of compiler errors = 0Number of unsuppressed compiler warnings = 0Number of warnings suppressed by NOWARN = 0Maximum symbol table space used was = 128338 bytesNumber of source lines = 6467Compile cpu time = 00:01:32Total Elapsed time - 00:07:47
Because the compilation unit includes SEARCH directives that cause previously
compiled object code to be bound with the source code, the number of source lines issmall compared to the generated code.
If a compilation ends due to a BINSERV error, the compiler prints statistics including
the BINSERV banner, the message “No object file created,” and the number ofBINSERV errors and warnings.