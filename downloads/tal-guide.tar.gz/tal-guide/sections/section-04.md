# Section 4: Introducing the Environment

The process environment in which your program runs
Addressing modes you can use in this environment
Allocation of data storage by the compiler
System dependencies
Process Environment Your object programs execute as individual processes on a Tandem system.  A
program is a static group of machine instructions and initialized data that reside in afile.  The same program can execute concurrently many times, and each executioncomprises a separate process.
A process is a dynamically running program.  Each process has its own user data
space in memory and process information maintained by the operating system.  Theinstruction codes of a process reside in the code space; they manipulate variable datathat reside in the data space.
The environment for your process includes:
Code space (user and library)
Data space (user and extended)
System code space
System library space
Registers
Code Space The code space of your process consists of:
An optional library code space
A user code space
If your process does not include library space, the user code space can contain 1 to 32
code segments.  If your process includes library space, the user code space can contain1 to 16 user code segments and 1 to 16 library code segments.
During program execution, the operating system automatically allocates memory for
code segments as needed, keeps track of which code segment is current, and performssegment switching when necessary.
A code segment contains instruction codes and some program constants.  During
execution, processes can read, but not modify, the content of a code segment.
A code segment consists of up to 65,536 words, which have consecutive addresses
from C[0] through C[65535].  ( C represents the code space.)

Process EnvironmentIntroducing the Environment
A user data segment
An automatic extended data segment if needed
Any user-defined (explicit) extended data segments
(The term segment  refers a nonextended segment except where the word extended  is
specifically used.)
User Data Segment
The user data segment provides a private storage area for the variables of your
process.  Your process can modify the content of the user data segment.
The system provides the user data segment automatically.  This segment contains up
to 65,536 words, addressed consecutively from G[0] through G[65535].  ( G represents
the global storage area.)
The lower half of the user data segment contains the global storage area and the data
stack.  During the execution of your process, the system stores the process’ global datain the global area.  During activation of a procedure, the system stores the procedure’sdata in the local area of the data stack.  During activation of a subprocedure, thesystem stores the subprocedure’s data in the sublocal area of the data stack.
The upper half of the user data segment provides memory that you can allocate for
your data if you do not use the CRE.  Appendix B, “Managing Addressing,” givesinformation on using the upper half of the user data segment without the CRE.

Process EnvironmentIntroducing the Environment
Figure 4-1.  User Data Segment
Global storage area
Local storage for
main procedure
Local storage  for  called procedures
Parameter storage for
current procedure
Local storage for
current procedure
Sublocal data and
parameter storage for
current subprocedure
Available for dynamic
allocation by  the
TAL compilerG[0]
L[0]
L[1]
S[0]
G[32767]
G[32768]Global  area
Local area
Sublocal area
Available for
allocation by the user or reserved
by the CREStack marker for
current procedureDummy stack marker
for main procedure
Limit of data stack Current top of data stack
Lower 32K-word area
Upper 32K-word areaG[65535]
Word address

Process EnvironmentIntroducing the Environment
Extended data segments provide indirect data storage in addition to storage in the
user data segment.  References to extended data segments are not as fast as those tothe user data segment.  An extended data segment can be as large as 127.5 megabytes.
When you declare arrays and structures by specifying the extended indirection symbol
(.EXT), the compiler automatically allocates and deallocates an appropriately sizedextended segment.  The segment size is fixed during compilation, and the full segmentis allocated in one step.  If you need a larger extended segment, use the LARGESTACKdirective (described in the TAL Reference Manual ).
As shown in Figure 4-2, the automatic extended segment contains:
A global area—for global extended indirect arrays and structures
An extended stack—for local extended indirect arrays and structures
Figure 4-2.  Automatic Extended Data Segment
Global extended indirect
arrays and structures
Local extended indirect
arrays and structures of
main procedure
Local extended indirect
arrays and structures of
current procedure
Available for dynamic
allocation by the TAL
compilerDummy stack marker for main procedure
347Global
area
Extended
stack
It is recommended that you use only the automatic extended data segment if possible.
If you must also allocate explicit extended data segments, follow the instructions inAppendix B, “Managing Addressing.”

Addressing ModesIntroducing the Environment
system code.
System Library Space The current system library space contains up to 31 segments of system library code,
available to your process one at a time.
Registers Table 4-1 lists the registers that describe your process in the current process
environment:
Table 4-1.   Registers in Current Process Environment
Register ContentProgram (P) register Contains the address of the next instruction to execute in the current
code segment
Instruction (I) register Contains the instruction currently executing in the current code segment
Local (L) register Contains the address of the beginning of the local data area for the
current procedure
Stack (S) register Contains the address of the last allocated word in the data stack for the
current procedure or subprocedure
Register stack Contains registers (R0 through R7) that the compiler uses for arithmetic
and other operations.  The compiler also uses R5, R6, and R7 as indexregisters.
Environment (E) register Contains information about the current process, such as the current RP
value and whether traps are enabled
Register pointer (RP) A field of the environment register that points to the current top of the
register stack
Addressing Modes When you declare a variable, you specify its addressing mode and an identifier and a
data type.  You can specify these addressing modes:
Direct addressing
Standard indirect addressing
Extended indirect addressing
The addressing mode and scope of a variable determines:
The storage area in which the compiler allocates space for the variable
The kind of instructions the compiler generates to access the variable
The data type of a variable determines the byte or word addressing mode of the
variable.  Figure 4-3 shows byte and word addresses in the user data segment.(Extended segments are always byte addressed.)

Addressing ModesIntroducing the Environment
Lower 32K-word area
Upper 32K-word area[65534] [65535][3]
[5][7][6][4][2]
.
..
[32767][0] [1] [0]
[1]
[3][2]
.
..
Upper limit for 16-bit
byte addresses
......
[65535]Word addresses Byte addresses
Direct Addressing Direct addressing uses 16-bit addresses and requires only one memory reference.
Direct addressing is not absolute; it is relative to the base of the global, local, orsublocal area of the user data segment.
You can use direct addressing only in the lower 32K-word area of the user data
segment.  To access data in any other area, use standard indirect addressing orextended indirect addressing, described next.
Indirect Addressing Indirect addressing requires two memory references, first to a location that contains an
address and then to the data located at the address.  You can use indirect addressing tosave space in limited storage areas, as described in “Storage Allocation” later in thissection.
You specify indirect addressing by using an indirection symbol when you declare
indirect arrays, indirect structures, or pointers (including simple pointers andstructure pointers).  Simple variables are always direct.
When you declare an indirect array or structure, the compiler automaticallyprovides an implicit pointer, stores a memory address in it, and then allocates thedata at that address.
When you declare a pointer, you must store the memory address of data in thepointer and must manage allocation of the data itself.
You can specify standard indirect addressing or extended indirect addressing.

Addressing ModesIntroducing the Environment
Standard indirect addressing is 16-bit indirect addressing in the user data segment,
including:
Byte or word addresses in the lower 32K-word area
Word addresses in the upper 32K-word area
If you use the CRE, however, the upper 32K-word area is not available for your data.
Extended Indirect Addressing
Extended indirect addressing is relocatable 32-bit indirect addressing anywhere in
virtual memory, usually in an extended data segment.
(Absolute extended indirect addressing is described in the System Description Manual
for your system.)
Indexing Indexing can be thought of as being an addressing mode.  You can access variables by
appending an index to a variable identifier.  The index represents an offset, forexample, as follows:
For an array, the index is an element offset from the location of the zeroth elementof the array.  The element size—byte, word, doubleword, or quadrupleword—depends on the data type of the array.
For a simple pointer, the index is an element offset from the address contained inthe pointer.  The element size depends on the data type of the simple pointer.
For a structure or substructure, the index is an occurrence offset from the locationof the zeroth occurrence of the structure or substructure.  The occurrence size isthe total number of bytes in one occurrence of the structure or substructure,including pad bytes.
In the following example, the index [1] lets you access the second element of
MY_ARRAY:
INT my_array[0:2];   !Declare MY_ARRAY, a three-element arraymy_array[1] := 5;    !Assign 5 to second element of MY_ARRAY
The specifics of indexing arrays, structures, pointers, and equivalenced variables are
discussed in Sections 7 through 10, respectively.

Storage AllocationIntroducing the Environment
compiler allocates storage as follows:
For global variables—when compilation begins
For local or sublocal variables—when the encompassing procedure orsubprocedure is invoked
The compiler allocates each variable either in the user data segment or in the
automatic extended segment, depending on how you declared the variable.
Allocation in the
User Data SegmentIn general, the compiler allocates storage for pointers and other variables in the lower
32K-word area of the user data segment.  Figure 4-4 shows the primary and secondaryareas of the lower 32K-word area and the variables each of these areas can contain.
Figure 4-4.  Primary and Secondary Storage in the User Data Segment
Global pointers and
direct variables
Data for global indirect
arrays and structures
Local pointers and
direct variables Bottom of data stack
Data for local indirect
arrays and structuresDummy stack marker for main procedure
Sublocal pointers and
direct variablesS[0]Current top of
data stack
Primary storage areas
Secondary storage areasGlobal  primary area
(256 words)
Global secondary area
Sublocal  primary area
(32 words)Local primary area
(127 words)
Local secondary area
349G[0]

Storage AllocationIntroducing the Environment
The global primary area can store up to 256 words of the following kinds of global
variables:
Direct variables—simple variables (which are always direct), direct arrays, anddirect structures
Pointers—simple pointers and structure pointers—that you declare
Implicit pointers—pointers that the compiler provides when you declare indirectarrays or indirect structures
Two implicit extended-stack pointers (described in “Extended Stack” later in thissection)
The compiler allocates storage for each global pointer and each direct global variable
at an increasingly higher offset from the beginning of the encompassing global datablock.  Global data blocks are relocatable during binding.
Local Primary Area
The local primary area for each procedure can store up to 127 words of the following
kinds of local variables:
Direct variables—simple variables (which are always direct), direct arrays, anddirect structures
Pointers—simple pointers and structure pointers—that you declare
Implicit pointers—pointers that the compiler provides when you declare indirectarrays and indirect structures
When a call to the encompassing procedure occurs, the compiler allocates storage at
the current top of the data stack for each local pointer and each direct local variable.The addresses of the variables are pushed to an increasingly higher offset from L[1].(L represents the local storage area.)
Sublocal Primary Area
The sublocal primary area for each subprocedure can store up to 32 words of the
following kinds of sublocal variables:
Direct variables—simple variables (which are always direct), direct arrays, anddirect structures
Pointers—simple pointers and structure pointers—that you declare
When a call to the encompassing subprocedure occurs, the compiler allocates storage
at the current top of the data stack for each sublocal pointer and each direct sublocalvariable.  The addresses of previously allocated variables are pushed to increasinglynegative offsets from S[0].  ( S represents the sublocal storage area.)
When all sublocal variables are allocated, the compiler adjusts the top-of-data-stack
pointer to point immediately below the last variable allocated.  The top of the datastack is illustrated in Figure 4-4 earlier in this section.

Storage AllocationIntroducing the Environment
The secondary storage areas are:
A global secondary area, which begins following the location of the last global
variable allocated in the global primary area
A local secondary area, which begins following the location of the last localvariable allocated in the local primary area
The secondary areas have no explicit size, but the total of all primary and secondary
areas cannot exceed the lower 32K-word area of the user data segment.
For each standard indirect array or structure that you declare:1. The compiler provides an implicit standard pointer and allocates a word of
storage for the pointer in the global or local primary area.
2. The compiler allocates storage for the array or structure in the global or local
secondary area, which begins immediately following the last direct item.
If you declare indirect arrays and structures within BLOCK declarations, however,
the compiler allocates such data blocks as described in Section 14, “CompilingPrograms.”
3. The compiler initializes the implicit pointer (provided in step 1) with the allocated
address of the array or structure in the secondary area, as follows:
For a STRING array, the pointer contains the byte address of the array.
For any other array, the pointer contains the word address of the array.
For a structure, the pointer contains the word address of the structure.
Allocation in the Automatic
Extended SegmentExtended indirect allocation is limited to the size of an extended segment, which can
be as large as 127.5 megabytes.
If you declare any extended indirect array or structure, the compiler automatically
allocates and manages an extended data segment.  (You can also allocate and manageexplicit extended segments as described in Appendix B, “Managing Addressing.”)
For each extended indirect array or structure that you declare:1. The compiler provides an implicit extended pointer and allocates a doubleword of
storage for the pointer in the global or local primary area of the user data segment.(Because the local primary area is limited to 127 words, you can declare at most 63extended local variables in any procedure.)
2. The compiler allocates storage for the array or structure in the automatic extended
data segment.
3. The compiler initializes the implicit pointer (provided in step 1)  with the byte
address of the array or structure in the extended data segment.
The compiler also allocates and manages:
An extended stack
Two extended stack pointers

Storage AllocationIntroducing the Environment
The compiler allocates the extended stack in the automatic extended data segment in a
data block named $EXTENDED#STACK.  The default size of the extended stack is 64Kbytes or the maximum space required by a procedure, whichever is greater.
When you use recursion or compile compilation units separately, the compiler cannot
calculate the size requirements of the extended stack precisely.  You can increase itssize by using the LARGESTACK directive, described in the TAL Reference Manual .
Extended Stack Pointers
The compiler allocates two implicit extended stack pointers in a data block named
EXTENDED#STACK#POINTERS in the global primary area of the user data segment.These pointers are as follows:
Extended
Stack Pointer Content
#SX Contains the address of the first free location in the current activation record in the
extended stack.  The current activation record contains all the information neededto execute the current procedure.
#MX Contains the maximum value allowed for #SX, less eight bytes.
When the value of #SX is greater than or equal to the value of #MX, the extended stack
overflows.  The end of the compilation listing reports the memory position of the twostack pointers.