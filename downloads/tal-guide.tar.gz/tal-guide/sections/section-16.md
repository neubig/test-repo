# Section 16: Running and Debugging

Programs
the program by using the TACL RUN command.  This command is summarized hereand described fully in the TACL Reference Manual .
In the RUN command, specify the name of an executable object file and run options if
any.  The following example runs an object file named MYPROG with no run options:
RUN myprog
Specifying Run Options When you run a program, you can include any of the TACL RUN command options.
Specify the run options in a comma-separated list, enclosed in slashes (/):
RUN myprog /IN myfile, LIB mylib/
Following are some commonly used options.IN File Option
The IN file can, for example, be a terminal, a disk file, or a process.  Your program is
given the IN file name and can use the file as it wishes.  If you omit an IN file, yourprogram uses the default input file (normally the home terminal).  For example, youcan specify MYFILE as the IN file in the RUN command:
RUN myprog /IN myfile/
OUT File Option
The OUT file can, for example, be a terminal, a disk file, a printer, a spooler location, or
a process.  Your program is given the OUT file name and can use the file as it wishes.If you omit an OUT file, the output goes to the default output device (normally thehome terminal).  For example, you can specify a spooler location as the OUT file in theRUN command:
RUN myprog /OUT $s.#host/
LIB File Option
You can specify the name of a user library file to satisfy external references in the
program.  A library file is an object file that contains user-written procedures.  If youspecify a user library file in the RUN command, the system searches that library filebefore searching the system library file.  For example, you can specify MYLIB as theLIB file in the RUN command:
RUN myprog /LIB mylib/
Once you specify a user library file, the program uses it for all subsequent runs of the
program until you specify another library or LIB with no file name .  The latter means
that no user library file is used.

Running ProgramsRunning and Debugging Programs
You can use the MEM (memory) option in the RUN command to increase the number
of memory pages for your program’s data.  For the MEM value, specify an integer inthe range 1 through 64.  For example, you can specify 40 memory pages in the RUNcommand:
RUN myprog /MEM 40/
If you omit the MEM option or if the MEM value is less than the compile-time or bind-
time memory-pages value (described next), the system uses the larger value.
Compile-Time Memory-Pages Value.  In your source file or in the compilation command,
you can use the DATAPAGES directive to increase the number of memory pages.  Forexample, you can specify 33 memory pages in your source file:
?DATAPAGES 33
In your source file, you can also increase the number of memory pages by calling the
C-series NEWPROCESS procedure or the D-series CREATE_PROCESS_  procedureand passing a memory-pages parameter.
If you do not specify the number of memory pages or if you specify an insufficient
value, BINSERV allocates sufficient pages for global data and two times the spaceneeded for local data.
Bind-Time Memory-Pages Value.  In Binder, you can use SET command options to set the
memory-pages value as described in the Binder Manual .
NOWAIT Option
If you use the NOWAIT option, the program runs in NOWAIT mode, and the TACL
product does not pause while your program runs.  Instead, TACL displays acommand input prompt after sending the startup message to the new process.  Youcan specify the NOWAIT option in the RUN command as follows:
RUN myprog /LIB mylib, NOWAIT/
If you omit the NOWAIT option, the program runs in WAIT mode, and the TACL
product pauses while the program runs.

Running ProgramsRunning and Debugging Programs
ParametersYou can pass parameters to a program at run time in the RUN command.  The syntax
and meaning of the parameters are dictated by the program.  For example, you can runthe program AVERAGE and pass five parameters to the program as follows:
RUN average 8 99 571 28 5
You can group several words into a single parameter by enclosing them in quotation
marks; for example:
RUN mystery "The butler did it."
You can include a quotation mark as part of a parameter by using two quotation
marks; for example:
RUN books """Raw Deal"" by I. M. Poor"
Stopping Programs You can let a program execute until completion or until a run-time error stops the
program.  You can also stop a program before it completes execution in any of thefollowing ways:
If the program runs in NOWAIT mode, enter the STOP command at the TACLprompt.
If the program runs in WAIT mode, press the BREAK key and enter the STOPcommand at the TACL prompt.
In a C-series source file, call the STOP system procedure.  (STOP ends a processnormally and ABEND ends a process abnormally.)  Declarations for systemprocedures are located in the EXTDECS file.
In a D-series source file written for a language-specific run-time environmentoutside the CRE, call the PROCESS_STOP_ system procedure.
PROCESS_STOP_  replaces STOP and ABEND;  it ends a process normally or
abnormally depending on the parameter you specify, as described in the Guardian
Procedure Calls Reference Manual .
In a D-series source file written for the CRE, call the CRE_TERMINATOR_ routine,
described in the CRE Programmer’s Guide  .
When a program stops, it can return a status message, a completion code value, and
additional information to the process that started it (usually a TACL product).
Run-Time Errors Some programming errors or program-usage errors are detected at run time rather
than at compile time (for example, arithmetic overflow TRAP#2).  The Guardian
Procedure Errors and Messages Manual lists system run-time diagnostic messages.  The
Guardian Programmer’s Guide  provides information on error processing and error
recovery.

Debugging ProgramsRunning and Debugging Programs
default debugger on the system; however, it displays values only by machine addressand only in octal or ASCII base.  For symbolic debugging, you can use the Inspectproduct.
Using the Inspect Product In high-level Inspect mode, you can display values by variable name or statement
number.  In low-level Inspect mode, you can display values by machine address.  Bydefault, values display in decimal base.
You can step through your program a statement at a time or you can set breakpoints at
points in your program at which you want to suspend execution.  Each time yourprogram pauses, you can display values to determine what is happening duringexecution.
Requesting the
Inspect ProductTo request the Inspect product, use the INSPECT directive in the compilation.  To
request the high-level Inspect mode, use the SYMBOLS directive in the compilation.SYMBOLS saves your program symbols in the object file for use in Inspect sessions.
You can specify the INSPECT and SYMBOLS directives in the compilation command
or in your source file.  The following example shows a directive line in a source file.
?INSPECT, SYMBOLS
Compiling the Source File When your source file is completed, you can compile the source file by issuing a
compilation command at the TACL prompt:
TAL /IN mysrc/ myprog
Starting the
Inspect SessionYou can start the Inspect session and the object file by issuing the RUND (debugger)
command at the TACL prompt:
RUND myprog
Your program drops into high-level Inspect mode and suspends program execution
before the first instruction in your program executes.  While the program issuspended, you can use Inspect commands to request breakpoints, step through theprogram, display program results, and so on.

Debugging ProgramsRunning and Debugging Programs
can use Inspect commands to check results at that point.  Usually, you request at leastone breakpoint at the Inspect prompt before the first instruction in your programexecutes.  For example, you can set an unconditional breakpoint at a statement or at anedit line number.
If you set an unconditional breakpoint at a statement, the program suspends execution
before the first machine instruction generated for that statement executes.  Thefollowing example sets a breakpoint at the eighth statement from the beginning ofMYPROC:
BREAK #myproc + 8 STATEMENTS
If you set an unconditional breakpoint at an edit line number, the program suspends
execution immediately before that line executes.  The following example sets abreakpoint at edit line 21:
BREAK #21
You can also set conditional and other breakpoints as described in the Inspect Manual.
Stepping Through
a ProgramAt the Inspect prompt, before the first statement executes or when the program pauses
at a breakpoint, you can step through the program and execute a single statement at atime.
1. To execute the first statement, enter:
STEP
2. To repeat the STEP command, press the Return key.3. To set a temporary breakpoint two statements hence and resume execution, enter:
STEP 2 STATEMENTS
Displaying Values When the program suspends execution at a breakpoint, you can use the DISPLAY
command to display the values of variables.  You can shorten the command to its firstletter.  For example, to display the values of variables LENGTH, WIDTH, and DEPTH,use either of the following commands:
DISPLAY length, width, depthD length, width, depth
Stopping the
Inspect SessionTo stop the Inspect session and your program, use the STOP command at the Inspect
prompt.  In high-level mode, enter STOP exactly as shown here:
STOP

Debugging ProgramsRunning and Debugging Programs
an Inspect session.
Sample Source File
The sample source file is named MYSRC.  Figure 16-1 shows the source code in the
sample source file.
Figure 16-1.  Sample Source File
!This is a source file named MYSRC.
?INSPECT                      !Request symbolic debugger
?SYMBOLS                      !Save symbols in object file                              ! for symbolic debugger?NOLIST, SOURCE $system.system.extdecs (initializer)                              !Include system procedure                              ! without its listing?LIST
PROC myproc MAIN;             !Declare procedure MYPROC
BEGIN  INT var1;                   !Declare variables  INT var2;  INT total;
CALL initializer;           !Read the start-up message
var1 := 5;                  !Assign value to VAR1  var2 := 10;                 !Assign value to VAR2  total := var1 + var2;       !Assign sum to TOTAL  END;                        !End MYPROC

Debugging ProgramsRunning and Debugging Programs
To compile the sample source file into an object file, specify the source file name
(MYSRC) and an object file name (MYPROG):
TAL /IN mysrc/ myprog
Figure 16-2 shows the beginning of the compiler listing for the sample object file.
Figure 16-2.  Sample Compiler Listing
PAGE 1 [1]    $MYVOL.MYSUBV.MYSRC
TAL - T9250D20 - (01JUN93)
1. 000000 0 0 !This is a source file named MYSRC.
2. 000000 0 0 3. 000000 0 0 ?INSPECT !Request symbolic debugger 4. 000000 0 0 ?SYMBOLS !Request symbols in Object file 5. 000000 0 0 ! for symbolic debugger 6. 000000 0 0 ?NOLIST, SOURCE $system.system.extdecs (initializer) 7. 000000 0 0 !Include system procedure 8. 000000 0 0 ! without its listing 9. 000000 0 0 ?LIST10. 000000 0 011. 000000 0 0 PROC myproc MAIN; !Declare procedure MYPROC12. 000000 1 0   BEGIN13. 000000 1 1   INT var1; !Declare variables14. 000000 1 1   INT var2;15. 000000 1 1   INT total;16. 000000 1 117. 000000 1 1   CALL initializer; !Read the start-up message18. 000006 1 1   var1 := 5; !Assign value to VAR119. 000010 1 1   var2 := 10; !Assign value to VAR220. 000012 1 1   total := var1 + var2; !Assign sum to TOTAL21. 000016 1 1   END; !End MYPROC

Debugging ProgramsRunning and Debugging Programs
The step numbers in the following Inspect session correspond to the interactive
operations shown in Figure 16-3.  In the figure, commands you enter are shown inboldface.
1. To run your program in an Inspect session, enter the TACL RUND command at
the TACL prompt.  Specify the name of your object file and any appropriate runoptions.  For the sample session, specify MYPROG:
RUND myprog
The Inspect product suspends program execution before the first instruction.  An
Inspect header message and prompt appears.  The prompt consists of the objectfile name enclosed in hyphens if your program has symbols (or underscores if ithas no symbols).
2. You can set breakpoints at points where you want the program to pause.  For the
sample session, set a breakpoint at edit line 21, which is the END of the program:
BREAK #21
An Inspect message indicates the number, type, and location of the breakpoint.
The breakpoint will suspend execution before edit line 21 executes.
3. To run your program until the breakpoint, enter the RESUME command at the
Inspect prompt:
RESUME
When a breakpoint occurs, the program suspends execution.  An Inspect message
identifies the breakpoint.
4. You can now display object values or clear and set breakpoints.  Normally, you
can resume execution or step through the program until it reaches anotherbreakpoint.
For the sample session, display the value of variable TOTAL:
DISPLAY total
An Inspect message shows the value of TOTAL.
5. Normally, after your program executes correctly, you clear all breakpoints (for
example, by issuing the CLEAR * command).  For the sample session, clear the
breakpoint by specifying its number:
CLEAR 1
An Inspect message tells you the breakpoint is cleared.
6. You can now stop the Inspect session and return to the TACL prompt.  (In high-
level mode, do not abbreviate the STOP command.)
STOP

Debugging ProgramsRunning and Debugging Programs
1. 25> RUND myprog
INSPECT - Symbolic Debugger - T9673D20 - (01JUN93) . . .
.-MYPROG-BREAK #21
Num Type  Subtype Location
1 Code          #MYPROC.#21(MYSRC)
3. -MYPROG-RESUME
INSPECT BREAKPOINT 1: #21
175,08,111  MYPROG  #MYPROC.#21(MYSRC)
4. -MYPROG-DISPLAY total
TOTAL = 15
5. -MYPROG-CLEAR *
Breakpoint cleared: 1  Code    #MYPROC.#21(MYSRC)6. -MYPROG-STOP
26>
If the results of the program are incorrect, correct the source file by using a text editor,
recompile the source file, and rerun the object file in an Inspect session.

17 Mixed-Language Programming
Mixed-language features provided by TAL
TAL and C guidelines
CRE guidelines for TAL programs
Mixed-Language
Features of TALYou can use the following TAL features in mixed-language programs:
NAME and BLOCK declarations
Procedure declaration LANGUAGE attribute
Procedure declaration public name
PROC and PROC(32) parameter types
Parameter pairs
ENV directive
HEAP directive
NAME and BLOCK
DeclarationsAll global data to be shared with routines written in other languages must be
relocatable.  After binding, you should not depend on the data being located at aparticular location.
In TAL, you can use BLOCK declarations to group global data declarations into named
or private data blocks.  If a BLOCK declaration is present, a NAME declaration at thebeginning of the compilation unit must name the unit.  The identifiers of NAME andBLOCK declarations must be unique among all NAME and BLOCK declarations in allthe compilation units in the program.  Here is an example of a NAME declaration:
NAME input_module;           !Name the compilation unit
A named data block is shareable among all compilation units in a program.  You can
declare any number of named data block in a compilation unit.  Here is an example ofa BLOCK declaration for a named data block (GLOBALS):
BLOCK globals;               !Declare named global data block
INT .an_array[0:7];  INT .another_array[0:34];  INT(32) total;  LITERAL msg_buf = 79;  DEFINE xaddr = INT(32)#;  END BLOCK;
A private data block is shareable only among routines within the same compilation
unit.  To declare a private data block, specify the PRIVATE keyword in place of thedata block identifier.   You can declare only one private data block in a compilationunit.  The private data block inherits the identifier you specify in the NAMEdeclaration for the compilation unit.  Here is an example of a BLOCK declaration for aprivate data block:
BLOCK PRIVATE;
INT average;  INT total;  END BLOCK;

Mixed-Language Features of TALMixed-Language Programming
see Section 14, “Compiling Programs.”
LANGUAGE Attribute Before calling an external routine, a TAL module must include an EXTERNAL
procedure declaration for the external routine.  If you are using a D-series TALcompiler, you can use the LANGUAGE attribute in the declaration to specify that theexternal routine is a C, COBOL85, FORTRAN, or Pascal routine.  For example, if theexternal routine is a C routine, you can specify LANGUAGE C following the routineidentifier in the EXTERNAL procedure declaration:
PROC c_func                 !EXTERNAL procedure declaration
LANGUAGE C;               !LANGUAGE attribute  EXTERNAL;                 !EXTERNAL option
If the C, COBOL85, FORTRAN, or Pascal routine has formal parameters, the
LANGUAGE attribute follows the formal parameter list in the EXTERNAL proceduredeclaration:
PROC c_func (a, b, c)       !Formal parameter list
LANGUAGE C;               !LANGUAGE attribute    STRING .a, .b, .c;      !Formal parameter declarations  EXTERNAL;                 !EXTERNAL option
If you are not sure of the language, you can specify LANGUAGE UNSPECIFIED in the
EXTERNAL procedure declaration:
PROC some_proc              !EXTERNAL procedure declaration
LANGUAGE UNSPECIFIED;     !LANGUAGE attribute  EXTERNAL;                 !EXTERNAL option
Here are guidelines for specifying a EXTERNAL procedure declaration:
Always include the EXTERNAL keyword if you use the LANGUAGE attribute.
Specify no more than one LANGUAGE attribute in a declaration.
Omit the LANGUAGE attribute if the external routine is written in TAL.

Mixed-Language Features of TALMixed-Language Programming
procedure declaration that specifies a public name for use in Binder.  In particular,specify an external routine identifier as a public name when the identifier does notconform to TAL rules.
In the EXTERNAL procedure declaration, specify an equal sign (=) and the public
name , enclosed in quotes, following the routine identifier:
PROC cobol_proc = "cobol-program-unit"  !Public name
LANGUAGE COBOL;                       !LANGUAGE attribute  EXTERNAL;
The public name must conform to the identifier rules of the language in which the
external routine is written.  For all languages except C, the TAL compiler upshifts allpublic names automatically.  In the preceding example, the public name conforms toCOBOL rules.
If the external routine has formal parameters, the formal parameter list follows the
public name:
PROC cobol_proc = "cobol-program-unit"  !Public name
(a, b, c)                             !Parameter list  LANGUAGE COBOL;                       !LANGUAGE attribute    STRING .a, .b, .c;                  !Parameter                                        ! declarations  EXTERNAL;

Mixed-Language Features of TALMixed-Language Programming
the following actual parameters:
A C small-memory-model routine
A FORTRAN routine compiled with the NOEXTENDEDREF directive
A TAL routine
TAL Receiving PROC Parameters
The following TAL routine declares a formal PROC parameter:
PROC tal_proc (param_proc);
```
    PROC param_proc;            !Formal PROC parameter  BEGIN  !Lots of code  END;
```
The following callers can call a TAL routine that declares a formal PROC parameter:
C small-memory-model routines
COBOL85 routines
FORTRAN routines compiled with the NOEXTENDEDREF directive
TAL routines
When a caller lists an appropriate routine in the calling sequence, the caller’s compiler
passes the routine’s 16-bit address of PEP and map information.
TAL Passing PROC Parameters
A TAL routine can pass actual PROC parameters to any of the following routines:
C small-memory-model routines
FORTRAN routines compiled with the NOEXTENDEDREF directive
TAL routines
If the actual PROC parameter is a C or FORTRAN routine, specify an EXTERNAL
procedure declaration such as:
PROC c_func (param_proc) LANGUAGE C;
```
    PROC param_proc;           !Formal PROC parameter  EXTERNAL;
```
Additional guidelines are provided later in this section in:
“TAL Routines as Parameters to C”
“C Routines as Parameters to TAL”

Mixed-Language Features of TALMixed-Language Programming
expects one of the following actual parameters:
A C large-memory-model routine
A FORTRAN routine compiled with the EXTENDEDREF directive
A Pascal routine
TAL Receiving PROC(32) Parameters
The following TAL routine declares a formal PROC(32) parameter::
PROC tal_proc (param_proc32);
```
    PROC(32) param_proc32;        !Formal PROC(32) parameter  BEGIN  !Lots of code  END;
```
The following callers can call a TAL routine that declares a formal PROC(32)
parameter:
C large-memory-model routines
COBOL85 routines
FORTRAN routines compiled with the EXTENDEDREF directive
Pascal routines
TAL routines
When a caller lists an appropriate routine in the calling sequence, the caller’s compiler
passes the routine’s 32-bit address to the TAL compiler.  The high-order word of theaddress contains PEP and map information;  the low-order word contains a zero.  Ifthe TAL compiler receives a 16-bit address instead, it converts the address to a 32-bitaddress and passes the converted address to the called routine.
TAL Passing PROC(32) Parameters
A TAL routine can pass actual PROC(32) parameters to any of the following routines:
C large-memory-model routines
FORTRAN routines compiled with the EXTENDEDREF directive
Pascal routines
TAL routines
For each actual PROC(32) parameter, specify an EXTERNAL procedure declaration
such as:
PROC c_func (param_proc32) LANGUAGE C;
```
    PROC(32) param_proc32;         !Formal PROC(32) parameter  EXTERNAL;
```
Additional guidelines and examples are provided later in this section in:
“TAL Routines as Parameters to C”
“C Routines as Parameters to TAL”

Mixed-Language Features of TALMixed-Language Programming
together describe a single data type to FORTRAN or Pascal routines.  Some D-seriessystem routines require that callers pass actual parameter pairs (as described in theGuardian Application Conversion Guide ).
Table 17-1 lists the parameter types in other languages that correspond to the TAL
parameter pair.
Table 17-1.  Parameter Pair Type Correspondence
Language TypeC Not applicable
COBOL Not applicable
FORTRAN CHARACTER *length
Pascal FSTRING( *) or FSTRING( length )
Declaring Parameter Pairs
When you declare a TAL routine, you can include a parameter pair by specifying a
string  parameter and a length  parameter separated by a colon:
PROC in_procedure (astring:length) !Parameter pair
LANGUAGE PASCAL;    STRING .EXT astring;           !Declare string parameter    INT     length;                !Declare length parameter  EXTERNAL;
The string and length parameters of a parameter pair have the following
characteristics:
Parameter Pass By Formal Parameter Actual ParameterString
parameterReference A standard or extended
STRING simple pointerA STRING array or simple pointer declared
inside or outside a structure
LengthparameterValue A directly addressed
INT simple variableAn INT expression that specifies the length,
in bytes, of the string parameter
If the called routine does not change the length of the string parameter, the length
parameter represents the maximum size, the initial size, or the current size of thestring parameter.

Mixed-Language Features of TALMixed-Language Programming
The calling routine can pass parameter pairs to the called routine in a CALL statement.
For example, the calling routine can declare and pass a parameter pair toIN_PROCEDURE (declared in the preceding example) as follows:
PROC caller;
BEGIN  LITERAL length = 5;  STRING .EXT array[0:length - 1];  !Some code here  CALL in_procedure (array:length);  END;
Modifying the String Length
If the called routine modifies the length of the string parameter, the called routine
must also provide an INT reference parameter in which it returns the new length ofthe string.  This parameter can represent the length, in bytes, of the string parameterbefore and after the routine modifies the length.  In that case, it is an input and outputparameter.  For example, you can declare the current-length parameter as follows:
PROC out_procedure (astring:max_length, current_length);
```
    STRING .EXT astring;    !Output or input/output parameter    INT max_length;         !Input parameter    INT .current_length;    !Output or input/output parameter  BEGIN  !Code to process ASTRING  END;
```
The formal current-length  parameter is a reference parameter, either a standard or
extended INT simple pointer.  It can be an input-output or output-only parameter:
Input-output parameter
Input The actual parameter is an INT simple variable that specifies the length
of the string parameter, in bytes, before the called routine processes thestring parameter.  When you list the simple variable in the callingsequence, the compiler passes the compiler-assigned address of thesimple variable.
Output The called routine can process the string parameter and return the new
length of the string parameter to the calling routine.  The called routinemust ensure that the initial length and the new length are in the range 0through the value of the maximum-length parameter.  (The compilerdoes no range checking.)
Output-only parameter—The compiler ignores any initial parameter value.

Mixed-Language Features of TALMixed-Language Programming
parameter to the procedure declared in the preceding example:
PROC out_proc_caller;
BEGIN  INT cur_len;            !Declare simple variable CUR_LEN  LITERAL max_len = 20;  STRING .name[0:max_len – 1];
name ':=' "KENNETH";
cur_len := 7;  CALL out_procedure (name:max_len, cur_len);  END;                    !Compiler passes address of CUR_LEN
Omitting Actual Parameter Pairs
If you want to omit an optional parameter-pair unconditionally in the actual
parameter list, substitute a comma for the omitted parameter pair.  You cannot omithalf of a parameter pair.
For example, suppose the called routine declares the optional parameter pair
VALUE2:VALUE3 as follows:
PROC some_procedure (value1, value2:value3, value4)
EXTENSIBLE;    INT value1;    STRING .value2;   !First half of optional parameter pair    INT value3;       !Other half of optional parameter pair    INT .value4;
The caller can omit the optional parameter pair from its CALL statement, like this:
INT val_1, val_4;CALL some_procedure (val_1, , val_4);
```
                      !Comma replaces omitted parameter pair
```
As of the D20 release, you can omit an optional parameter-pair conditionally.  Use the
$OPTIONAL standard function as described in Section 13, “Using Procedures.”
ENV Directive In TAL, you use the ENV directive to specify the run-time environment of a D-series
object file as described later in this section.  The run-time environment is either:
The CRE, which provides services for mixed-language programs
A C, COBOL, FORTRAN, Pascal, or TAL run-time environment outside the CRE
HEAP Directive In TAL, you can set the size of the user heap in the CRE, if ENV COMMON is also in
effect for the MAIN routine.  The user heap, named #HEAP, is a shared CRE resourcethat all routines in your program can access directly or indirectly as described later inthis section.

TAL and C GuidelinesMixed-Language Programming
Tandem C modules.  This discussion assumes that you have a working knowledge ofTAL and C and are familiar with the contents of the following manuals:
TAL Programmer’s Guide
TAL Reference Manual
C Reference Manual
This subsection discusses:
TAL and C identifiers
TAL and C data types
Memory models
TAL calling C
C calling TAL
Sharing data
Parameters and variables
Extended data segments
For information on calling TAL routines from another language, see the manual for
COBOL85, FORTRAN, or Pascal.
Using Identifiers TAL and C identifiers differ as follows:
TAL and C have independent sets of reserved keywords.
TAL identifiers can include circumflexes (^);  C identifiers cannot.
The C compiler is case-sensitive;  the TAL compiler is not case-sensitive.
To declare variable identifiers that satisfy both compilers:
Avoid using reserved keywords in either language as identifiers.
Specify TAL identifiers without circumflexes.
Specify C identifiers in uppercase.
You can declare TAL-only or C-only routine identifiers and satisfy both compilers by
using the public name option in:
Interface declarations in C
EXTERNAL procedure declarations in TAL
In Inspect sessions:
Use uppercase for TAL identifiers
Use the given case for C identifiers
In Binder sessions, use mode noupshift for lowercase C identifiers.

TAL and C GuidelinesMixed-Language Programming
Shared global variables
Formal or actual parameters
Function return values
Table 17-2 lists compatible TAL and C data types for each TAL addressing mode.
Table 17-2.  Compatible TAL and C Data Types
TAL Addressing Mode TAL Data Type C Data Type NotesDirect STRING char
Direct INT short TAL INT signed range only
Direct INT(32) longDirect FIXED(0) long long TAL FIXED(0) onlyDirect REAL floatDirect REAL(64) double
Standard indirect (.) STRING char *
Standard indirect (.) INT short *
Standard indirect (.) INT(32) long *
Standard indirect (.) FIXED(0) long long *
Standard indirect (.) REAL float *
Standard indirect (.) REAL(64) double *
Extended indirect (.EXT) STRING extptr char * For extptr, see Note.
Extended indirect (.EXT) INT extptr short *
Extended indirect (.EXT) INT(32) extptr long *
Extended indirect (.EXT) FIXED(0) extptr long long *
Extended indirect (.EXT) REAL extptr float *
Extended indirect (.EXT) REAL(64) extptr double *
Note: In C, use extptr only in the parameter-type-list of an interface declaration to specify a
parameter type that is defined in TAL as an extended pointer.
Incompatibilities between TAL and C data types include the following:
TAL has no numeric data type that is compatible with C unsigned long.
TAL  UNSIGNED is not compatible with C unsigned short.  TAL UNSIGNED(16)
can represent signed or unsigned values.
For more information on C and TAL data types, see “Parameters and Variables” later
in this section.

TAL and C GuidelinesMixed-Language Programming
depending on the amount of data storage required.  The large-memory model isrecommended and is the default setting.  All examples in this subsection illustrate thelarge-memory model unless otherwise noted.
A TAL program can use any of the following memory combinations, depending on the
application’s needs:
The user data segment
The user data segment and the automatic extended data segment
The user data segment and one or more explicit extended data segments
The user data segment, the automatic extended data segment, and one or moreexplicit extended data segments
The following table describes some aspects of memory usage by C and TAL programs.
The rightmost column refers to the upper 32K-word area of the user data segment.
LanguageMemory
Model Addressing Data StorageUpper 32K-Word
Area
C Small 16-bit 32K words Reserved
C Large 32-bit 127.5 megabytes Reserved
TAL Not
applicable16-bit or
32-bit64K words (without the CRE), plus
127.5 megabytes in each extendeddata segment that is allocated.Reserved only if
you use the CRE
Any TAL module that uses the upper 32K-word area of the user data segment cannot
run within a C object file that contains the MAIN routine.

TAL and C GuidelinesMixed-Language Programming
From TAL ModulesA TAL module must include an EXTERNAL procedure declaration for each C routine
to be called.  The following TAL code shows the EXTERNAL procedure declaration forC_FUNC and a routine that calls C_FUNC.  ARRAY is declared with .EXT,  becauseC_FUNC uses the large-memory model:
TAL Code                     C Code
INT status := 0;             short C_FUNC(char *str)
STRING .EXT array[0:4];      {                                *str = 'A';INT PROC c_func (a)             str[2] = 'C';  LANGUAGE C;                   return 1;    STRING .EXT a;           }EXTERNAL;
PROC example MAIN;
BEGIN  array[2] := "B";  status := c_func (array);  array[1] := "B";  END;
A C-series C module called by a TAL module has limited access to the C run-time
library.  If the C module needs full access to the C run-time library, you can either:
Modify the program to run in the CRE as described later in this section.
Specify a C MAIN routine that calls the original TAL MAIN routine as follows.
In the TAL module, remove the MAIN keyword from the TAL MAIN routine and
remove any calls to the INITIALIZER or ARMTRAP system procedure.  The TALmodule must also meet the requirements of the C run-time environment.
TAL Code                C Code
```
                         #include <stdioh> nolist
```
INT status := 0;INT .EXT array[0:4];     tal void TALMAIN ( void );
INT PROC cfunc (a)       short CFUNC (short *num)
LANGUAGE C;            {    INT .EXT a;             printf("num B4=%d\n",*num);EXTERNAL;                   num[0] = 10;                            printf("num AF=%d\n",*num);PROC talmain;               return 1;  BEGIN                  }  array[2] := 2;  status :=              main ()   /* C MAIN routine */      cfunc (array);     {  END;                     TALMAIN ();                         }

TAL and C GuidelinesMixed-Language Programming
From C ModulesA D-series C module has full access to the C run-time library even if the C module
does not contain the MAIN routine.   A C-series C module that does not contain theMAIN routine cannot fully access the C run-time library.
When you code C modules that call TAL routines:
Include an interface declaration for each TAL routine to be called.
If a called TAL routine sets the condition code, include the talh header file.
If a called routine is a system procedure, include the cextdecs header file.
In C, interface declarations are comparable to EXTERNAL procedure declarations in
TAL.  To specify an interface declaration in C, include:
The keyword _tal (D-series code) or tal (C-series code)
The variable or extensible attribute , if any, of the TAL routine
The data type  of the return value, if any, of the TAL routine
A routine identifier
A public name  if the TAL identifier is not a valid C identifier
A parameter-type-list  or, if no parameters, the keyword void
For extended pointers in the parameter-type-list, the keyword extptr before the
parameter type
The return type value can be any of the following:
Return Type Value Meaningvoid The TAL routine does not return a value.
fundamental-type The TAL routine returns a value.  Specify one of, or a pointer
to one of, the character, integer, or floating-point types.
cc_status The TAL routine sets the condition-code register to CCL, CCE,
or CCG (defined in talh).
For information on calling TAL routines that both return a value and set a condition
code (CC), see the C Reference Manual.
Here are examples of interface declarations for calling TAL routines.  For D-series
code, prefix the tal keyword with an underscore):
_tal variable short SEGMENT_ALLOCATE_ (short, long,
```
                                       short *, short);
```
_tal variable cc_status SEGMENT_DEALLOCATE_ (short, short);_tal variable cc_status READ (short, short *, short,
```
                              short *, long);
```
_tal extensible cc_status READX (short, extptr char *, short,
```
                              short *, long);
```
_tal void c_name = "tal^name" (short *);
After specifying an interface declaration, use the normal C routine call to access the
TAL routine.

TAL and C GuidelinesMixed-Language Programming
C Code
#include <stdioh> nolistshort arr[5];        /*stored in extended segment */
_tal void C_Name = "tal^name" (extptr short *);
void func1 (short *xarr)
{  C_Name (xarr);  printf ("xarr[2] after TAL = %d", xarr[2]);}
main ()
{  arr[4] = 8;  func1 (arr);}
TAL Code
PROC tal^name (a);
```
    INT .EXT a;          !32-bit pointer  BEGIN  a[2] := 10;  END;
```

TAL and C GuidelinesMixed-Language Programming
TAL and C modules:
TAL modules that declare global variables having standard indirection (.)
C small-memory-model modules
You can share global data in the automatic extended data segment between the
following kinds of TAL and C modules:
TAL modules that declare global variables having extended indirection (.EXT)
C large-memory-model modules
In a large-memory-model C module, you can use the lowmem declaration to allocate a
C array or structure that can be represented by a 16-bit address if needed in a call to aTAL routine or a system procedure.
Using pointers to share data is easier and safer than trying to match declarations in
both languages.  Using pointers also eliminates problems associated with where thedata is placed.
To share data by using pointers, first decide whether the TAL module or the C module
declares the data:
If the TAL module is to declare the data, follow the guidelines in “Sharing TALData With C Using Pointers.”
If the C module is to declare the data, follow the guidelines in“Sharing C DataWith TAL Using Pointers.”
Sharing TAL Data With C Using Pointers
To share TAL global data with C modules, follow these steps:1. In the TAL module, declare the data using C-compatible identifiers, data types,
and alignments.  (Alignments depend on byte or word addressing and variablelayouts as described in “Parameters and Variables” later in this section.)
When you declare TAL arrays and structures, use indirect addressing.
2. In the C module, declare pointers to the data, using TAL-compatible data types.3. In the C module, declare a routine to which TAL can pass the addresses of the
shared data.
4. In the C routine, initialize the pointers with the addresses sent by the TAL module.5. Use the pointers in the C module to access the TAL data.The following example shows how to share TAL data with a large-memory-model C
module.  The TAL module passes to a C routine the addresses of two TAL arrays.  TheC routine assigns the array addresses to C pointers.

TAL and C GuidelinesMixed-Language Programming
short *c_int_ptr;            /* pointer to TAL data */
char *c_char_ptr;            /* pointer to TAL data */
short INIT_C_PTRS (short *tal_intptr, char *tal_strptr)
{                            /* called from TAL */  c_int_ptr = tal_intptr;  c_char_ptr = tal_strptr;  return 1;}
/* Access the TAL arrays by using the pointers */TAL CodeSTRUCT rec ( *);
BEGIN  INT x;  STRING tal_str_array[0:9];  END;
INT .EXT tal_int_array[0:4];     !TAL data to share with C
STRUCT .EXT tal_struct (rec);    !TAL data to share with C
INT status := -1;INT PROC init_c_ptrs (tal_intptr, tal_strptr) LANGUAGE C;
```
    INT .EXT tal_intptr;    STRING .EXT tal_strptr;  EXTERNAL;
```
PROC tal_main MAIN;
BEGIN  status := init_c_ptrs                 (tal_int_array, tal_struct.tal_str_array);  !Do lots of work  END;
Sharing C Data With TAL Using Pointers
To share C global data with TAL modules, follow these steps:1. In the C module, declare the data using TAL-compatible identifiers, data types,
and alignments.  (Alignments depend on byte or word addressing and variablelayouts as described in “Parameters and Variables” later in this section.)
C arrays and structures are automatically indirect.
2. In the TAL module, declare pointers to the data, using C-compatible data types.3. In the TAL module, declare a routine to which C can pass the addresses of the
shared data.
4. In the TAL routine, initialize the pointers with the addresses sent by C.5. Use the pointers in the TAL module to access the C data.

TAL and C GuidelinesMixed-Language Programming
the addresses of two C arrays to a TAL routine.  The TAL routine assigns the arrayaddresses to TAL pointers.
C Code#include <stdioh> nolistshort arr[5];                  /* C data to share with TAL */
char charr[5];                 /* C data to share with TAL */
_tal void INIT_TAL_PTRS ( extptr short *, extptr char * )
_tal void C_Name = "tal^name" (void);
void example_func( int *x )
{  printf("x before TAL = %d\n", x[2] );  C_Name( );  printf("x after TAL = %d\n", x[2] );}
main ()
{  INIT_TAL_PTRS ( &arr[0], &charr[0] ); /* initialize ptrs */    /* test pointer values */  arr[0] = 8;  example_func( arr );  arr[2] = 18;  charr[2] = 'B';}
TAL CodeINT .EXT tal_int_ptr;                      !Pointer to C data
STRING .EXT tal_char_ptr;                  !Pointer to C data
PROC init_tal_ptrs (c_addr1, c_addr2);     !Called from C
```
    INT .EXT c_addr1;    STRING .EXT c_addr2;  BEGIN  @tal_int_ptr := @c_addr1;  @tal_char_ptr := @c_addr2;  END;
```
PROC tal^name;
BEGIN  tal_int_ptr[0] := 10;  tal_int_ptr[2] := 20;  tal_char_ptr[2] := "A";  END;

TAL and C GuidelinesMixed-Language Programming
As of the D20 release, TAL modules can share global data with C modules by
declaring each shared variable in its own BLOCK declaration and giving both thevariable and the BLOCK the same name.  The C modules must also declare eachshared variable; the layout of the variable must match in both the TAL and C modules.
In the following example, a TAL module declares a variable within a BLOCK
declaration, and the C module declares the equivalent variable:
TAL Code                      C Code
NAME TAL_module;BLOCK fred;
INT .EXT fred;              int FRED;  /*all uppercase*/  END BLOCK;
Because the preceding method requires that the layout of the corresponding TAL and
C declarations match, it is recommended that you share data by using pointers wherepossible.
Parameters and Variables This subsection gives guidelines for declaring compatible TAL and C variables and
parameters.  These guidelines supplement those given in “Sharing Data” earlier in thissection.  The following topics are discussed:
STRING and char variables
Arrays
Structures
Substructures
Multidimensional arrays
Arrays of structures
Redefinitions and unions
Pointers
Enumeration variables
Bit-field manipulation
UNSIGNED variables and compacted bit fields
TAL routines as parameters
C routines as parameters
When you declare formal reference parameters, remember to use indirection as
follows:
If the caller is a small-memory-model C routine, use standard indirection (.) for theTAL formal parameter.
If the caller is a large-memory-model C routine, use extended indirection (.EXT)for the TAL formal parameter.

TAL and C GuidelinesMixed-Language Programming
TAL STRING and C char simple variables each occupies one byte of a word.
Following are STRING and char compatibility guidelines:
Share variables of type TAL STRING and C char by using pointers.
Declare TAL STRING and C char formal parameters as reference parameters toavoid the following value parameter incompatibility:
When you pass a STRING parameter to a C routine, the actual byte valueoccupies the left byte of the word allocated for the C char formal parameter.
When you pass a char parameter to a TAL routine, the actual byte valueoccupies the right byte of the word allocated for the TAL STRING formalparameters.
For example, if you declare a TAL STRING formal parameter as a value parameter
rather than as a reference parameter, the TAL routine can access the C char actualparameter only by explicitly referring to the right byte of the word allocated for theSTRING formal parameter:
PROC sample (s);
```
    STRING s;              !Declare TAL STRING parameter as a  BEGIN                    ! value (not reference) parameter  STRING dest;  dest := s[1];            !Refer to right byte of word  END:
```
Arrays
TAL and C arrays differ as follows:
Characteristic TAL Array C ArrayLower bound Any integer Always zero
Dimensions One dimension One or more dimensions
Direct or indirect Direct or indirect Indirect onlyByte or word addressing STRING arrays and extended
indirect arrays are byteaddressed;  all other arrays areword addressedchar arrays and large-memory-
model arrays are byteaddressed; all other arrays areword addressed
TAL structures can emulate multidimensional C arrays, as discussed in
“Multidimensional Arrays” later in this section.
To declare compatible TAL and C arrays:
Use data types and alignments that satisfy both compilers.
Declare TAL arrays that have a lower bound of 0.
Declare one-dimensional C arrays.
Declare indirect TAL  arrays.

TAL and C GuidelinesMixed-Language Programming
TAL Code                      C Code
INT .EXT robin[0:9];          short robin [10];
INT(32) .EXT gull[0:14];      long gull [15];STRING .EXT grebe[0:9];       char grebe [10];
Structures
All TAL and C structures begin on a word boundary.  Following are guidelines for
sharing TAL and C structures and passing them as parameters:
Specify the same layout for corresponding TAL and C structures.
Specify compatible data types for each item of both structures.
In TAL, pass structures by reference.
In C, use the & operator.
In TAL, a routine cannot return a structure as a return value.
The following TAL and C structures have compatible layouts:
TAL Code                        C Code
STRUCT rec ( *);                 struct birdname
BEGIN                         {  INT x;                          short x;  STRING y[0:2];                  char y[3];  END;                          } robin[10];
STRUCT .EXT robin(rec)[0:9];
The following TAL and C structures have compatible layouts:
TAL Code                        C Code
STRUCT rec1 ( *);                struct rec1
BEGIN                         {  STRING a, b, c;                 char a, b, c;  END;                          };
The following TAL and C structures also have compatible layouts:
TAL Code                        C Code
STRUCT rec2 ( *);                struct rec2
BEGIN                         {  STRING e;                       char e;  INT y;                          short y;  STRING g;                       char g;  END;                          };

TAL and C GuidelinesMixed-Language Programming
The TAL compiler allocates alignment of substructures on a byte or word boundary as
follows:
Each definition substructure occurrence is byte aligned if the first item it containsbegins on a byte boundary.
Each definition substructure occurrence is word aligned if the first item it containsbegins on a word boundary.
Each referral substructure occurrence is always word aligned.
C substructures always begin and end on word boundaries.In this example, TAL referral substructure TSUB and C substructure CSUB have
compatible layouts:
TAL Code                        C Code
STRUCT rec1 ( *);                struct rec1
BEGIN                         {  STRING a, b, c;                 char a, b, c;  END;                          };
STRUCT rec3 ( *);                struct rec3
BEGIN                         {  INT x;                          short x;  STRING var;                     char var;  STRUCT tsub (rec1);             struct rec1 csub;  STRING f;                       char f;  END;                          };
In this example, TAL definition substructure TSUB1 follows a STRING variable and
begins on a byte boundary.  The layouts of TSUB1 and CSUB1 are not compatible, soyou cannot share the substructures between the two languages:
TAL Code                        C Code
STRUCT rec4 ( *);                struct rec4
BEGIN                         {  INT x;                          short x;  STRING a;                       char a;  STRUCT tsub1;                   struct    BEGIN                         {    STRING b,c,d;                   char b,c,d;    END;                          } csub1;  STRING e;                         char e;  END;                          };
If you use the Data Definition Language (DDL) to describe your files, the byte-aligned
substructure layout is the only layout DDL cannot generate.  (DDL is described in theData Definition Language (DDL)Reference Manual.)

TAL and C GuidelinesMixed-Language Programming
Declare TAL referral substructures rather than definition substructures.  Referral
substructures are always word-aligned.
If you must declare TAL definition substructures, either:
Use FILLER declarations as needed to begin and end TAL definitionsubstructures on word boundaries, as shown in TAL structure REC4  in theexample that follows.
Declare C structures that emulate the layout of a byte-aligned TALsubstructure, as shown in C structure REC5 in the second example thatfollows.
In TAL structure REC4, each FILLER declaration inserts a pad byte before and after
the definition substructure TSUB2 so it begins and ends on a word boundary.  Thus,the following TAL and C structures have compatible layouts and can be shared:
TAL Code                        C Code
STRUCT rec4 ( *);                struct rec4
BEGIN                         {  INT x;                          short x;  STRING a;                       char a;  FILLER 1;  STRUCT tsub2;                   struct    BEGIN                         {    STRING b,c,d;                   char b,c,d;    END;                          } csub2;  FILLER 1;  STRING e;                        char e;  END;                          };
In C structure REC5, three variables (not a substructure) emulate the byte-aligned
layout of TAL substructure ST.  Thus, the following TAL and C structures havecompatible layouts and can be shared:
TAL Code                        C Code
STRUCT rec5 ( *);                struct rec5
BEGIN                         {  INT x;                          short x;  STRING a;                       char a;  STRUCT st;    BEGIN    STRING b;                     char stb;    STRING c;                     char stc;    STRING d;                     char std;    END;  STRING e;                       char e;  END;                          };
STRUCT .EXT match (rec5);       struct rec5 match;

TAL and C GuidelinesMixed-Language Programming
In C, you can declare multidimensional arrays.  In TAL, you can emulate
multidimensional arrays by declaring structures that contain arrays.
Here is an example of multidimensional arrays in TAL and C (large-memory model):
TAL Code                         C Code
STRUCT rec1 ( *);
BEGIN  INT y[0:4];                    short cma[10][5];  END;
STRUCT .EXT tma(rec1)[0:9];!Sample access!                  /* sample access */
tma[8].y[3] := 100;              cma[8][3] = 100;
Arrays of Structures
If you specify bounds when you declare a TAL structure, you create an array of
structures.  The following TAL  and C arrays of structures are equivalent.  Eachdeclaration contains an array of ten structure occurrences:
TAL Code                        C Code
STRUCT cell ( *);                struct cell
BEGIN                         {  INT x;                          short x;  STRING y;                       char y;  END;                          };
STRUCT .EXT tcell(cell)[0:9];   struct cell ccell [10];PROC honey (c);                 void JOANIE
```
    INT .EXT c (cell);          (struct cell *);EXTERNAL;
```

TAL and C GuidelinesMixed-Language Programming
Variant records are approximated by TAL structure redefinitions and C unions.A TAL redefinition declares a structure item that uses the same memory location as an
existing structure item.  The existing structure item can be a simple variable, array,substructure, or pointer that:
Begins on a word boundary
Is at the same BEGIN-END level in the structure as the redefinition
Is the same size or larger than the redefinition
A C union defines a set of variables that can have different data types and whose
values alternatively share the same portion of memory.  The size of a union is the sizeof its largest variable; the largest item need not come first.   A union always begins ona word boundary.
Here is an example of TAL redefinitions and equivalent C unions:
TAL Code                      C Code
STRUCT mtns ( *);              struct Mtns
BEGIN                       { union {  INT(32) tamalpais;              long Tamalpais;  INT diablo = tamalpais;         short Diablo;  STRING hamilton = diablo;       char Hamilton;} Calif_mtns;  FIXED num;                    union {  STRUCT cascade = num;           long long Num;    BEGIN                         struct {    INT ranier;                     short Ranier;    INT sthelens;                   short StHelens;    INT adams;                      short Adams;    INT hood;                       short Hood; } Cascade;    END;                          } Northern_mtns;  END;                        };
STRUCT c_high (mtns);         struct Mtns High;
The following identifiers access equivalent structure items in the preceding example:
In TAL: c_high.diablo
In C: High.Calif_mtns.Diablo

TAL and C GuidelinesMixed-Language Programming
Pointers contain memory addresses of data.  You must store an address into a pointer
before you use it.  In TAL and C pointer declarations, you specify the data type of thedata to which the pointer points.  You must use pointers when sharing globalvariables.  You can pass pointer contents by value between TAL and C routines.
Differences between TAL and C pointers include the following:
TAL structure pointers can point to a byte or word address.
C structure pointers always point to a word address.  To pass a C structure pointer
to a TAL routine that expects a byte structure pointer, you must explicitly cast theC pointer to type char.
TAL pointers are dereferenced implicitly.
C pointers are usually dereferenced explicitly.
Small-memory-model C routines use 16-bit pointers only.
Large-memory-model C routines use 32-bit pointers only, even if the pointers referto the user data segment.  In global structure declarations, you must specifylowmem in the storage class of the declaration.
If a TAL routine expects a 16-bit pointer, the C pointer you pass must refer to anobject in user data space.
Here are examples of TAL and C pointers (large-memory model):
TAL Code                       C Code
STRUCT rec ( *);                struct rec
BEGIN                        {  INT d;                       short d;  INT .p (rec);                struct rec *p;  END;                         };
BLOCK joe;
INT .EXT joes (rec);          struct rec *JOE;  END BLOCK;
PROC tonga (p);                void CALEDONIA
```
    INT .EXT p (rec);          (struct rec *p)  BEGIN                        {  !Lots of code                /* Lots of code */  END;                         }
```
Each language can call the other, passing the address in the pointer by value:
TAL Code                        C Code
CALL caledonia (joes);           TONGA (joe);

TAL and C GuidelinesMixed-Language Programming
implement a linked list:
TAL Code                        C Code
STRUCT rec ( *);                 struct rec
BEGIN                         {  INT x;                           short x;  INT .EXT strptr (rec);           struct rec *p;END;                            };
STRUCT .EXT joe (rec);          struct rec joe;PROC callme (param1);           void f1 (struct rec *);
```
    INT .EXT param1 (rec);EXTERNAL;
```

TAL and C GuidelinesMixed-Language Programming
Using C enumeration constants, you can associate a group of named constant values
with an int variable.  A C enumeration variable occupies 16 bits of memory.  Youdefine all integer operations on them.  The C compiler provides no range checking, soan enumeration variable can hold a value not represented in the enumeration.
A C routine can share an enumeration variable with TAL routines.  A TAL routine
cannot access the enumeration constants, but can declare LITERALs for readability.For example:
TAL Code                      C Code
LITERAL no = 0,               enum choice {no = 0,
```
        yes = 3,                yes = 3,        maybe = 4;              maybe = 4 };
```
BLOCK answer;                 enum choice ANSWER;
INT answer_var;  END BLOCK;
A C routine can pass enumeration parameters to TAL routines, placing the actual
value in a TAL INT variable.  For example:
TAL Code                      C Code
LITERAL no = 0,               enum choice {no = 0,
```
        yes = 3,                yes = 3,        maybe = 4;              maybe = 4 };
                              enum choice answer;
```
PROC tal_proc (n);    INT n;                    _tal void TAL_PROC (short);  BEGIN  !Lots of code               main ()  IF n = yes THEN ... ;       {  !Lots of code                 answer = yes;  END;                          TAL_PROC (answer);                                /* lots of code */                              }

TAL and C GuidelinesMixed-Language Programming
You can manipulate bit fields in both TAL and C.In TAL, you can use either:
Built-in bit-extraction and bit-deposit operations
Bit-wise operators LAND and LOR
In C, you can use either:
Bit-wise operators & (and) and | (or)
Defines
The following TAL bit-deposit operation and C bit-wise operation are equivalent:
TAL Code                      C Code
INT x := -1;                  short a = -1;
INT y := 0;                   short b = 0;                              short temp = 0;PROC example;  BEGIN                       void example ()  y.<0:2> := x.<10:12>;       {  END;                           /* you can combine these */                                 /* with wider margins */
```
                                 temp = a & 070;
                                 temp = temp << 10;                                 b = (b & 017777)|temp;                               }
```
Bit extractions and bit deposits are not portable to future software platforms.

TAL and C GuidelinesMixed-Language Programming
In general, TAL UNSIGNED simple variables in structures are compatible with C
unsigned packed bit fields (which only appear in structures).  You cannot, however,pass C bit fields as reference parameters to TAL routines.
The following UNSIGNED variables and C unsigned bit fields are compatible:
TAL Code                     C Code
STRUCT stuffed ( *);          struct stuffed;
BEGIN                      {  INT x;                       int x;  UNSIGNED(1) a;               unsigned a : 1;  UNSIGNED(5) b;               unsigned b : 5;  UNSIGNED(3) c;               unsigned c : 3;  UNSIGNED(4) d;               unsigned d : 4;  UNSIGNED(9) e;               unsigned e : 9;  UNSIGNED(2) f;               unsigned f : 2;  END;                       };
STRUCT packed (stuffed);     struct stuffed PACKED;
When the WIDE pragma is not specified, the C compiler normally packs adjacent bit
fields in a 16-bit word.  When the WIDE pragma is specified, the C compiler normallypacks adjacent bit fields in a 32-bit word.
TAL UNSIGNED(1–16) and C bit fields of like size are compatible.  TAL
UNSIGNED(17–31) and C bit fields of like size are compatible.
The TAL compiler always packs adjacent UNSIGNED simple variables in 16-bit words
as follows:
It starts the first UNSIGNED variable on a word boundary.
It packs each successive UNSIGNED variable in the remaining bits of the sameword as the preceding UNSIGNED variable if:
The variable contains 1 to 16 bits and fits in the same word
The variable contains 17 to 31 bits and fits in the same word plus the nextword
If an UNSIGNED variable does not fit in the same word or doubleword, thecompiler starts the variable on the next word boundary.
The operator you use determines whether UNSIGNED values are signed or unsigned:
UNSIGNED(3) x;               !TAL code
UNSIGNED(3) y;
IF x + y ... ;               !Signed operation
IF x '+' y ... ;             !Unsigned operation
UNSIGNED arrays that contain 8-bit or 16-bit elements are compatible with C arrays
that contain elements of like size.  UNSIGNED arrays that contain 1-bit, 2-bit, or 4-bitelements are incompatible with C arrays.

TAL and C GuidelinesMixed-Language Programming
You can call C routines and pass TAL routines as parameters.  You can pass any TAL
routine except EXTENSIBLE or VARIABLE routines as parameters.
A passed TAL routine can access the routine’s local variables and global TAL
variables.  The passed routine can contain subprocedures, but they cannot be passed asparameters.
If you call a large-memory-module C routine, the EXTERNAL procedure declaration
for the C routine must specify the PROC(32) parameter type in the parameterdeclaration.  When you pass the PROC(32) parameter to the C routine, the compilerpasses a 32-bit address that contains PEP and map information in the high-order wordand a zero in the low-order word.
If you call a small-memory-module C routine, the EXTERNAL procedure declaration
for the C routine must specify the PROC parameter type in the parameter declaration.When you pass the PROC parameter to the C routine, the compiler passes a 16-bitaddress that contains PEP and map information.
In the following example, a large-memory-model C module contains C_FUNC, which
expects a TAL procedure as a parameter.  The TAL module contains:
An EXTERNAL procedure declaration for C_FUNC
TAL_PARAM_PROC, a routine to be passed as a parameter to C_FUNC
TAL_CALLER, a routine that calls C_FUNC and passes TAL_PARAM_PROC as aparameter

TAL and C GuidelinesMixed-Language Programming
/* C function that accepts TAL routine as a parameter */void C_FUNC (short (*F) (short n))
{  short j;  j = (*F)(2);  /* lots of code */}
TAL ModulePROC c_func (x) LANGUAGE C;  !EXTERNAL procedure declaration
```
                             ! for C routine to be called    INT PROC(32) x;          !Parameter declaration  EXTERNAL;
```
INT PROC tal_param_proc (f); !Procedure to be passed as a
```
    INT f;                   ! parameter to C_FUNC  BEGIN  RETURN f;  END;
```
PROC tal_caller;             !Procedure that calls C_FUNC
BEGIN                      ! and passes TAL_PARAM_PROC  !Lots of code  CALL c_func (tal_param_proc);  !Lots of code  END;
PROC m MAIN;
BEGIN  CALL tal_caller;  END;

TAL and C GuidelinesMixed-Language Programming
You can call TAL routines and pass C routines as parameters.  You can call a TAL
entry-point identifier as if it were the routine identifier.  C routines cannot be nested.
When a called TAL routine in turn calls a C routine received as a parameter, the TAL
routine assumes that all required parameters of the C routine are value parameters.The TAL compiler has no way of checking the number, type, or passing methodexpected by the C routine.  If the C routine requires a reference parameter, the TALroutine must explicitly pass the address by using:
The @ operator for a small-memory-model parameter
The $XADR standard function for a large-memory-model parameter
In the following example, a C large-memory-model module contains C routine
C_PARAM_FUNC, which is to be passed as a parameter.  The TAL module contains:
An EXTERNAL procedure declaration for C_PARAM_FUNC
TAL_PROC, which expects C_PARAM_FUNC as a parameter
TAL_CALLER, which calls TAL_PROC and passes C_PARAM_FUNC as aparameter
TAL ModuleINT i;
STRING .EXT s[0:9];
PROC c_param_func (i, s)   !EXTERNAL procedure declaration
LANGUAGE C;              ! for C routine expected as    INT i;                 ! a parameter    STRING .EXT s;         !Extended indirection for large-  EXTERNAL;                ! memory-model
PROC tal_proc (x);         !TAL routine that expects
```
    PROC(32) x;            ! a large-memory-model C routine  BEGIN                    ! as a parameter  CALL x (i, $XADR (s));  END;
```
PROC tal_caller;
BEGIN  CALL tal_proc (c_param_func);  END;
PROC m main;
BEGIN  CALL tal_caller;  END;
C Modulevoid C_PARAM_FUNC (short i, char * s)
{                          /* C routine to be passed as */                           /* a parameter to TAL_PROC   */}

TAL and C GuidelinesMixed-Language Programming
32-bit address that contains PEP and map information in the high-order word and azero in the low-order word.  When you pass a small-memory-model C routine as aparameter, the compiler passes a 16-bit address that contains PEP and mapinformation.
Extended Data Segments In addition to the user data segment, you can store data in:
The automatic extended data segment
One or more explicit extended data segments
You should use only the automatic extended data segment if possible.  You should not
mix the two approaches.  If you must use explicit segments and the automaticsegment, however, follow guidelines 4 and 11 in “Explicit Extended Data Segments”later in this section.
Automatic Extended Data SegmentThe TAL compiler allocates the automatic extended data segment when a TAL
program declares arrays or structures that have extended indirection.
The C compiler allocates the automatic extended data segment for all large-memory-
model modules.
Explicit Extended Data Segments
TAL modules and large-memory-model C modules can allocate and deallocate
extended data segments explicitly.  Since the advent of the automatic extended datasegment, however, programs usually need not use explicit extended data segments.The information in this subsection is provided to support existing programs.
To create and use an explicit extended segment, you call system procedures.  You can
allocate and manage as many extended segments as you need, but you can use onlyone extended segment at a time.  You can access data in an explicit extended segmentonly by using extended pointers.   The compiler allocates memory space for theextended pointers you declare.  You  must manage allocation of the data yourself.
Here are guidelines for using explicit extended segments:1. Declare an extended pointer for the base address of the explicit extended segment.2. To allocate an explicit extended segment and obtain the segment base address, call
SEGMENT_ALLOCATE_.
3. To make the explicit extended segment the current segment, call
SEGMENT_USE_.
4. If the automatic extended segment is already in place, SEGMENT_USE_ returns
the automatic extended segment's  number.  Save this number so you can lateraccess the automatic segment again.
5. C requires special treatment for SEGMENT_USE_, which returns a value and sets
the condition code.  (See the C Reference Manual. )

TAL and C GuidelinesMixed-Language Programming
addresses into subsequent pointers, you must allow space for preceding dataitems.  (See “Managing Data Allocation in Extended Segments” in Appendix B.)
7. To refer to data in the current segment, call READX or WRITEX .8. To move data between extended segments, call MOVEX.9. To manage large blocks of memory, call DEFINEPOOL, GETPOOL, and
PUTPOOL.
10. To determine the size of a segment, call SEGMENT_GETINFO_.11. To access data in the automatic extended segment, call SEGMENT_USE_ and
restore the segment number that you saved at step 4.
12. To delete an explicit segment that you no longer need, call
SEGMENT_DEALLOCATE_.
For information on using these system procedures, see the Guardian Programmer's
Guide  and the Guardian Procedure Calls Reference Manual.
If you do not restore the automatic extended data segment before you manipulate data
in it, any of the following actions can result:
An assignment statement is beyond the segment's memory limit and causes a trap.
All assignments within range occur in the hardware base and limit registers of theautomatic extended segment.  Data in the currently active extended segment isoverwritten.  The error is undetected until you discover the discrepancy at a latertime.
The C code runs until it accesses an invalid address or accesses an inaccessiblelibrary routine.
You get the wrong data from valid addresses in the explicit extended datasegment.

TAL and C GuidelinesMixed-Language Programming
manipulates data in an explicit extended segment and then restores the automaticextended segment.  When control returns to the C routine, it manipulates data in therestored automatic extended segment:
Example 17-1.  D-Series TAL and C Extended Segment Management (Page 1 of 2)
TAL Code
INT .EXT array[0:10];       !Allocated in the automatic
```
                            ! extended data segment ID 1024DINT .EXT arr_ptr;
```
?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS0 (
?     PROCESS_DEBUG_, DEFINEPOOL, GETPOOL,?     SEGMENT_ALLOCATE_, SEGMENT_USE_, SEGMENT_DEALLOCATE_)?POPLIST
PROC might_lose_seg;
BEGIN  INT status := 0;  INT old_seg := 0;  INT new_seg := 100;  INT(32) seg_len := %2000D; !1024D
array[0] := 10;         !Do work in automatic segment  status := SEGMENT_ALLOCATE_ (
```
                   new_seg, seg_len, , , , , arr_ptr);             !Allocate an explicit extended data segment;             !store segment base address in ARR_PTR  IF status <> 0 THEN CALL PROCESS_DEBUG_;
```
Status := SEGMENT_USE_ (new_seg, old_seg, arr_ptr);
```
             !Make the explicit extended data segment current  IF status <> 0 THEN CALL PROCESS_DEBUG_;
```
!Use DEFINEPOOL, GETPOOL to retrieve a block in the
! explicit extended data segment.
arr_ptr[2] := 10;        !Do some work in the segment.  !When you no longer need the explicit extended data
! segment, call SEGMENT_DEALLOCATE_.
status := SEGMENT_USE_ (old_seg);
```
             !Restore the automatic extended data segment  IF status <> 0 THEN CALL PROCESS_DEBUG_;
```
END;

TAL and C GuidelinesMixed-Language Programming
C Code
#pragma symbols, inspect, strictshort arr[10];
char sarr[10];char *s;
tal void MIGHT_LOSE_SEG (void);main ()
{   s = &sarr[0];   *s = 'A';   arr[0] = 10;   MIGHT_LOSE_SEG ();   /* Call TAL routine, which uses the*/                        /* explicit extended data segment */
/* next two statements depend on the automatic extended */
/* data segment being restored after the call to TAL */   sarr[1] = *s;   arr[1] = arr[0] + 5;}
For a TAL example program that manages an explicit extended data segment, see
Appendix B, “Managing Addressing.”

CRE Guidelines for TALMixed-Language Programming
for TALThe CRE provides routines that support mixed-language programs compiled on
D-series compilers.  A mixed-language program can consist of C, COBOL85,FORTRAN, Pascal, and TAL routines.  By using the CRE, each routine in yourprogram, regardless of language, can:
Use its run-time library without overwriting the data of another run-time library
Share data in the CRE user heap
Access the standard files (standard input, standard output, and standard log)
Without the CRE, only routines written in the language of the MAIN routine can fully
access their run-time library.  For example, if the MAIN routine is written in TAL, aroutine written in another language might not be able to use its own run-time library.
D-series C and Pascal routines run only in the CRE.  D-series COBOL85, FORTRAN,
and TAL routines can run in the CRE if you specify the ENV COMMON directive.Such programs must also meet CRE, system, and language requirements.  The CRE
Programmer’s Guide describes CRE requirements and routines.
This section gives CRE guidelines for TAL programs.  It discusses the following:
General coding guidelines
Specifying a run-time environment
Setting the user heap size
Initializing the CRE
Terminating programs
Sharing standard files
Using $RECEIVE
Handling errors in CRE math routines
General Coding Guidelines All D-series language products except TAL have run-time libraries that call CRE
routines and system routines as needed.  TAL routines that meet CRE requirementscan call CRE routines (and system procedures) directly.
The following list summarizes some general guidelines for coding D-series TAL source
code for the CRE.  The subsections that follow this list give more information aboutsome of these guidelines:
For the MAIN routine, specify the following TAL directives:
The ENV directive with the COMMON attribute to request the CRE
The HEAP directive if any routine needs the user heap in the CRE
To run in the CRE, your program needs the TALLIB and CRELIB library files.
As of the D20 release, your program can manipulate saved startup, PARAM, andASSIGN messages by using the Saved Messages Utility (SMU) functions providedby the CLULIB library file.
The first statement of the MAIN routine must call TAL_CRE_INITIALIZER_.  Thisroutine initializes the CRE and optionally saves the startup, PARAM, and ASSIGNmessages.

CRE Guidelines for TALMixed-Language Programming
Do not call the PROCESS_STOP_, STOP, or ABEND system procedures.
For services provided by the CRE, call CRE routines.  For example, call CREroutines to:
Open, manipulate, and close the standard files
Perform math or string operations
For services not provided by the CRE, call system procedures.  For example, callsystem procedures to:
Create processes
Manage extended data segments
Do not call the ABEND, ARMTRAP, PROCESS_STOP_ , or STOP systemprocedure, because of probable conflict with TAL_CRE_INITIALIZER_  andCRE_TERMINATOR_.
Do not call the INITIALIZER system procedure or read the startup message from$RECEIVE itself, because of probable conflict with TAL_CRE_INITIALIZER_  andCRE_TERMINATOR_.
If you use sequential I/O (SIO) procedures (such as WRITE^FILE, SET^FILE, andREAD^FILE), resolve how to remove any calls to the INITIALIZER procedure.The Guardian Programmer’s Guide  describes how you use the SIO and
INITIALIZER procedures.
Do not use the DATAPAGES, EXTENDSTACK, or STACK directive.  (Thecompiler automatically allocates 64K words of memory space for the user datasegment.)
Do not write data to areas in the user data segment that are reserved for use by theCRE;  that is, do not use:
Locations G[0] or G[1]
The upper 32K-word area
Your program can access $RECEIVE by calling either CRE routines only or systemprocedures only, as described in “Accessing $RECEIVE” later in this section.
When an error occurs in a CRE routine, the CRE returns control to the calling TALroutine without taking any action.  The TAL routine must explicitly handle allerrors except certain errors detected by the CRE routines.
If a CRE math routine detects an error, the calling TAL routine must manage thetrap enable bit of the environment register to control program behavior.

CRE Guidelines for TALMixed-Language Programming
EnvironmentTo specify the intended run-time environment of a D-series TAL compilation unit, use
the ENV directive.   To execute in the intended environment, the routines must alsomeet the requirements of the intended run-time environment.
The attributes of the ENV directive are:
ENV Attribute Intended Run-Time EnvironmentCOMMON The CRE.
OLD A COBOL or FORTRAN run-time environment outside the CRE.
NEUTRAL None;  the program relies primarily on system procedures.
You can include the ENV directive in the TAL compilation command or in the
compilation unit before any declarations.  The ENV directive can appear only onceduring a compilation.
For example, you can specify ENV on a directive line and include the COMMON
attribute:
?ENV COMMON
If you compile without the ENV directive, all routines in the compilation unit have the
ENV NEUTRAL attribute.
ENV COMMON  Directive
An object file can run in the CRE if the MAIN routine has the ENV COMMON
attribute and if all routines meet CRE requirements.  If ENV COMMON is in effect, allroutines in the compilation unit (except routines in object files listed in SEARCHdirectives) have the ENV COMMON attribute.
SEARCH directives can list object files compiled with any ENV attribute except OLD.
Each routine in a SEARCH file retains its original ENV attribute.
When a compilation unit contains a MAIN routine and ENV COMMON is in effect,
the compiler allocates special CRE data blocks and initializes certain fields of thosedata blocks.  These data blocks, listed in Table 17-3, are reserved for use by the CRE.
Table 17-3.  CRE Data Blocks
Data Block Name Location
Basic control block #CRE_GLOBALS At G[0] and G[1] of the user data segment.
Master control block #MCB In the upper 32K-word area of the user data
segment.
CRE heap #CRE_HEAP Last block in the upper 32K-word area of the user
data segment.   (This heap differs from the CREuser heap block named #HEAP.)
Using Binder, you can bind an object file compiled with ENV COMMON to any object
file except those compiled with ENV OLD.  Each routine in the new object file retainsits original ENV attribute.

CRE Guidelines for TALMixed-Language Programming
An object file compiled with ENV OLD can run in a COBOL85 or FORTRAN run-time
environment outside the CRE (if the object file meets the requirements of the run-timeenvironment).
When ENV OLD is in effect, all routines in the compilation unit (except routines in
object files listed in SEARCH directives) have the ENV OLD attribute.  SEARCHdirectives can list object files compiled with any ENV attribute except COMMON.Each routine in a SEARCH file retains its original ENV attribute.
Using Binder, you can bind a TAL object file compiled with ENV OLD to any object
file (regardless of language) except those compiled with ENV COMMON.  Eachroutine in the new object file retains its original ENV attribute.
A D-series TAL program compiled with ENV OLD can run on a C-series system.  To
debug the program with the Inspect product, however, your system must be a releaselevel C30.06 or later
ENV NEUTRAL Directive
An object file compiled with ENV NEUTRAL should not rely on any external services
except system procedures.
When ENV NEUTRAL is in effect, all routines in the compilation unit (except routines
in object files listed in SEARCH directives) have the ENV NEUTRAL attribute.SEARCH directives can list object files compiled with ENV NEUTRAL or with no ENVdirective.  Each routine in the new object file has the ENV NEUTRAL attribute.
Using Binder, you can bind an object file compiled with ENV NEUTRAL to any object
file.  Each routine in the new object file retains its original ENV attribute.
ENV Directive Not Specified
An object file compiled without the ENV directive probably does not rely on any
external services except system procedures.
When no ENV directive is in effect, all routines in the compilation unit (except routines
in object files listed in SEARCH directives) have the ENV NEUTRAL attribute.SEARCH directives can list object files compiled with any ENV attribute.  Each routinein a SEARCH file retains its original ENV attribute.
Using Binder, you can bind an object file compiled without the ENV directive to any
object file.  Each routine in the new object file retains its original ENV attribute.

CRE Guidelines for TALMixed-Language Programming
regardless of language.  The user heap is in the block named #HEAP, which differsfrom the CRE-reserved block named  #CRE_HEAP.
Binder allocates memory space for the user heap as follows:
If a TAL program contains a small-memory model C or Pascal module, the user
heap is the last global data block in the lower 32K-word area of the user datasegment.  (The last data block is located just below the user data stack.)
If a TAL program contains a large-memory-model C or Pascal module or containsno C or Pascal routines, the user heap is the last data block in the automaticextended data segment.
If the TAL program also uses explicit extended data segments, follow the
instructions given in “Explicit Extended Data Segments” earlier in this section.
Setting the User Heap Size
To set the size of the user heap, specify the HEAP directive in the TAL compilation
command or anywhere in the TAL module that contains the MAIN routine.  The sizespecified in the last HEAP directive encountered in the TAL compilation takes effect.The ENV COMMON directive must also be in effect.   If a TAL program invokes aroutine that needs the user heap, the HEAP directive is required.  The following TALdirective line sets a user heap of 5 memory pages:
?HEAP 5
The heap size is the number of 2048-byte memory pages.  Specify an unsigned decimal
constant in one of the following ranges:
Memory
Model Range Notes
Small 0 through 31 The heap size you can specify depends on your use of the lower
32K-word area of the user data segment.
Large 0 through 32,767 When a program runs, the CRE increases the heap size as needed
up to the maximum size of the automatic extended segment.  Donot set an arbitrarily large size because an equal amount of diskspace (for swapping) must be available.
Accessing the User Heap
Only C and Pascal routines can allocate and return user heap space.  To allocate and
return user heap space, C and Pascal routines call the following library routines:
Request C Library Routine Pascal Library RoutineObtain heap space malloc NEW
Return heap space free DISPOSE

CRE Guidelines for TALMixed-Language Programming
a C, Pascal, or TAL routine assigns the address returned from malloc or NEW to apointer and uses the pointer in an expression.  All routines that need access to suchdata must either:
Use the same data layout
Call a routine that accesses the data for you
COBOL85 and FORTRAN routines access heap data by calling C, Pascal, or TAL
routines.
In the following example, TAL routine DO_IT calls C routine GETSPACE.  GETSPACE
gets a block from the heap, stores a value in the first word of the block, and returns toDO_IT a pointer that points to the data:
C Code#include <stddef.h> nolist
#include <stdlib.h> nolistint *GETSPACE (int nbytes){ int *p;  p = (int *) malloc (nbytes);  if ( p )    *p = 100;  return p;}
TAL CodeINT(32) PROC tal_malloc = "GETSPACE" (nbytes) LANGUAGE C;
```
    INT nbytes;  EXTERNAL;
```
PROC do_it;
BEGIN  INT .EXT t_ptr;  @t_ptr := tal_malloc (1000);  IF (@t_ptr = 0d) OR (t_ptr <> 100) THEN    BEGIN    !Handle error ...    END;  END;

CRE Guidelines for TALMixed-Language Programming
also use the CRELIB and CLULIB library files.
TALLIB provides the TAL_CRE_INITIALIZER_ routine.  This routine is described in
the next subsection.
CRELIB provides routines that enable your routine to perform tasks such as the
following.  These routines are described in the CRE Programmer’s Guide :
Share files
Manipulate $RECEIVE
Terminate the CRE
Handle exceptions
Perform standard math functions
Manipulate strings
Manage memory blocks
CLULIB (as of the D20 release) contains SMU functions that enable your routine to
manipulate saved startup, ASSIGN, and PARAM message values.  These routines aredescribed in the CRE Programmer’s Guide .
The following table lists the files that your program must include depending on which
set of routines it uses.  The table also indicates the run-time environment in which youcan use the library routines.
Table 17-4.  Including Library and External Declaration Files
Library
FileIncluding Library
RoutinesRoutine
PrefixDeclaration File
to Source InRun-Time
Environment
TALLIB SEARCH directive or
Binder commandTAL_ TALDECS CRE
CRELIB No action *CRE_ CREDECS CRE
CRELIB No action *RTL_ RTLDECS CRE
CLULIB SEARCH directive or
Binder commandSMU_ CLUDECS CRE, COBOL85,
FORTRAN, or TAL
* The CRELIB file is configured into the system library.
CREDECS and RTLDECS contain blocked global data declarations (that is, data
declared inside BLOCK declarations).  If you include blocked data declarations in acompilation unit, a NAME declaration is required.  You must specify globaldeclarations in the following order:
1. NAME declaration2. Unblocked global data declarations, if any3. Blocked global data declarations from CREDECS, RTLDECS, and user code, if any4. Procedure declarations

CRE Guidelines for TALMixed-Language Programming
by SOURCE directives for TALDECS, CREDECS, and CLUDECS:
?ENV COMMON
NAME cre_example;?SEARCH $SYSTEM.SYSTEM.TALLIB?SEARCH $SYSTEM.SYSTEM.CLULIB?SOURCE $SYSTEM.SYSTEM.TALDECS (TAL_CRE_INITIALIZER_)?SOURCE $SYSTEM.SYSTEM.CREDECS (CRE_TERMINATOR_)?SOURCE $SYSTEM.SYSTEM.CLUDECS (SMU_ASSIGN_DELETE_)
You can specify the SEARCH directive in the command to start the compiler, instead
of in the source file.  Here is an example:
TAL /IN mysrc, OUT $s.#mylst, NOWAIT/ myprog;
```
        SEARCH $SYSTEM.SYSTEM.TALLIB
```
If you do not use the SEARCH directive for TALLIB and CLULIB, you can bind the
files into the object file by issuing Binder commands.  Here is an example:
ADD * FROM myprog
SELECT SEARCH $SYSTEM.SYSTEM.TALLIBSELECT SEARCH $SYSTEM.SYSTEM.CLULIBBUILD myprog
Initializing the CRE To initialize the CRE and optionally save system messages, call
TAL_CRE_INITIALIZER_ in the first statement of your MAIN routine.TAL_CRE_INITIALIZER_ does the following actions:
It calls the ARMTRAP procedure and establishes a trap handler.
It optionally saves startup, ASSIGN and PARAM messages.
It determines the name of your program’s standard log.
The TALLIB file contains TAL_CRE_INITIALIZER_.  The TALDECS file contains the
external declaration for TAL_CRE_INITIALIZER_, as follows:
PROC TAL_CRE_INITIALIZER_ (options) EXTENSIBLE;
```
    INT options;                 !Input, optional  EXTERNAL;
```
The OPTION parameter lets you save the startup, ASSIGN, and PARAM messages for
manipulation by your routine.  OPTION flags you can specify for the actual parameterare provided in the CREDECS file in the INITIALIZATION section, as follows:
CRE^Save^all^messages
CRE^Save^startup^messageCRE^Save^assign^messageCRE^Save^param^message

CRE Guidelines for TALMixed-Language Programming
?ENV COMMON
NAME initialize_CRE;?SEARCH $SYSTEM.SYSTEM.TALLIB?SOURCE $SYSTEM.SYSTEM.TALDECS (TAL_CRE_INITIALIZER_)
PROC mymain MAIN;
BEGIN  CALL TAL_CRE_INITIALIZER_;     !Initialize the CRE  !Lots of code  END;
The following example initializes the CRE and saves ASSIGN and PARAM messages
but not the startup message:
?ENV COMMON
NAME initialize_CRE;?SEARCH $SYSTEM.SYSTEM.TALLIB?SOURCE $SYSTEM.SYSTEM.TALDECS (TAL_CRE_INITIALIZER_)?SOURCE $SYSTEM.SYSTEM.CREDECS (INITIALIZATION)
PROC mymain MAIN;
BEGIN  CALL TAL_CRE_INITIALIZER_       (CRE^save^assign^message LOR CRE^save^param^message);  !Lots of code  END;
Your routine can manipulate the saved messages by calling SMU functions, as
described in the CRE Programmer’s Manual.
Terminating Programs At the end of execution:
1. A TAL module must call CRE_FILE_CLOSE_  for each file the TAL module has
opened.
2. The TAL module then must call CRE_TERMINATOR_ to clear the run-time
environment (as described in the CRE Programmer’s Guide ).
3. CRE_TERMINATOR_  calls a run-time library termination routine for each
language in your program except TAL.
4. Each termination routine releases any resources and closes files used by routines
written in that language as follows:
It closes open standard files by calling CRE_FILE_CLOSE_.
It closes all other files by calling FILE_CLOSE_.
Each termination routine then passes control to CRE_TERMINATOR_.
5. CRE_TERMINATOR_  closes any remaining standard files, releases any system
resources used by the CRE, and calls PROCESS_STOP_.
6. PROCESS_STOP_  closes any remaining files left open by your program and
returns control to the operating system.

CRE Guidelines for TALMixed-Language Programming
routines directly.  The CRE provides the following routines for accessing the standardfiles:
CRE_FILE_CLOSE_
CRE_FILE_CONTROL_CRE_FILE_INPUT_CRE_FILE_MESSAGE_CRE_FILE_OPEN_CRE_FILE_OUTPUT_CRE_FILE_RETRYCHECK_CRE_FILE_SETMODE_CRE_HOMETERM_OPEN_CRE_LOG_MESSAGE_CRE_SPOOL_START_
The preceding CRE routines are described in the CRE Programmer’s Guide.   Some
examples are given in the following subsections.
Opening a Standard File
To request an open to a standard file, a TAL routine calls CRE_FILE_OPEN_.  For
example, to request an open to standard log , specify:
CALL CRE_FILE_OPEN_ (cre^standard^log);
As another example, to request an open to the standard output file, specify:
CALL CRE_FILE_OPEN_ (cre^standard^output);
CRE_FILE_OPEN_  does the following tasks:
If the file is closed, CRE_FILE_OPEN_  calls FILE_OPEN_.
FILE_OPEN_  opens the file and returns control to CRE_FILE_OPEN_.
CRE_FILE_OPEN_  grants the TAL routine a connection to the file open.
For each subsequent open request, CRE_FILE_OPEN_  grants a connection to the
same file open.

CRE Guidelines for TALMixed-Language Programming
To write a record to standard log , a TAL routine calls CRE_LOG_MESSAGE_.  For
example, to write the content of a 15-character array named MSG to standard log, youcan specify:
CALL CRE_LOG_MESSAGE_ (msg:15);
To write a record to standard output , a TAL routine calls CRE_FILE_OUTPUT_.  For
example, to write the record "B" to standard output , you can specify:
STRING var;
var := "B";CALL CRE_FILE_OUTPUT_ (cre^standard^output, var:1);
Closing Standard Files
To close standard files, a TAL routine calls CRE_FILE_CLOSE_.  For example, to close
standard log, specify:
CALL CRE_FILE_CLOSE_ (cre^standard^log);
As another example, to close standard output, specify:
CALL CRE_FILE_CLOSE_ (cre^standard^output);
Using Spooling
You can specify a spooler collector as the device for standard output or standard log.
For standard output, the CRE uses buffered spooling unless you specify otherwise.For standard log, you cannot use buffered spooling.
To request an open to a spooler collector:1. The TAL routine calls CRE_FILE_OPEN_.2. If the spooler is closed, CRE_FILE_OPEN_  sets a flag that CRE_SPOOL_START_
has not been called.
3. If the flag in step 2 is set, other CRE standard-file routines (such as
CRE_FILE_OUTPUT_) call CRE_SPOOL_START_, which clears the flag and startsthe spooler with default settings.
To change the default settings, the TAL routine must call CRE_SPOOL_START_
directly and specify the new settings, such as the setting for multiple copies.
4. CRE_FILE_OPEN_  grants the TAL routine a connection to the spooler.5. For each subsequent request, CRE_FILE_OPEN_  grants a connection to the same
spooler open.

CRE Guidelines for TALMixed-Language Programming
operating system, from your backup process, or from another process.  Routineswritten in any language supported by the CRE can read $RECEIVE.  The routines in aprogram can access $RECEIVE by calling either CRE routines only or systemprocedures only.
CRE  Routines
A program can use CRE routines to access $RECEIVE if the program accesses
$RECEIVE from:
TAL routines only
COBOL routines only
FORTRAN routines only
Both COBOL and TAL routines
Both FORTRAN and TAL routines
CRE  Routines for accessing $RECEIVE include:
Action CRE RoutineRequest an open to $RECEIVE CRE_RECEIVE_OPEN_CLOSE_ with the open variant
Read messages from $RECEIVE CRE_RECEIVE_READ_
Reply to messages from $RECEIVE CRE_RECEIVE_WRITE_
If $RECEIVE is not open when the first request occurs, a CRE routine opens $RECEIVE
for exclusive access.  For each subsequent request, the CRE routine grants a connectionto the same file open.  For more information on the CRE routines, see the CRE
Programmer’s Guide.
System  Procedures
System procedures for accessing $RECEIVE include:
Action System ProcedureRequest an open to $RECEIVE FILE_OPEN_
Read, and reply to, messages from
$RECEIVEREADUPDATE[X] and REPLY[X]
For more information on the system procedures, see the Guardian Programmer’s Guide
and the Guardian Procedure Calls Reference Manual.

CRE Guidelines for TALMixed-Language Programming
CRE Math RoutinesThe CRE provides libraries of math routines, such as sine and cosine routines, that
your program can call.
When a CRE math routine receives an invalid parameter or produces an invalid result,
an arithmetic fault occurs when control returns to the caller.  The caller’s run-timelibrary (except TAL) determines the program’s behavior.
A TAL caller can determine the effect of the error by setting or resetting the trap-
enable bit of the environment register.  You should ensure that the trap-enable bit isappropriately set before your program calls a CRE math routine.
If traps are disabled when a CRE math routine detects an error, the system returns
control to the caller:
REAL r, s;
r := -1.0E0;
CALL disable_overflow_traps;    !A user-written routine that
s := RTL_SQRT_REAL32_(r);       ! disables overflow trapsIF $OVERFLOW THEN               !Control returns here; test  BEGIN                         ! error in RTL_SQRT_REAL32_.  CALL enable_overflow_traps;   !Enable overflow traps  !Lots of code  END;CALL enable_overflow_traps;     !Enable overflow traps
If traps are enabled when a CRE math routine detects an error, the system returns
control to the current trap handler:
REAL r, s;
r := -1.0E0;
CALL enable_overflow_traps;     !A user-written routine that
s := RTL_SQRT_REAL32_(r);       ! enables overflow trapsIF $OVERFLOW THEN               !If RTL_SQRT_REAL32_ causes  BEGIN                         ! overflow, the program does  !Lots of code!                ! not reach this statement  END;                          ! because control transfers                                ! to the current trap handler
The Extended Stack The CRE supports the extended stack, which defines the following data blocks:
$EXTENDED#STACK
EXTENDED#STACK#POINTERS
These data blocks are described in Section 4, “Introducing the Environment.”

CRE Guidelines for TALMixed-Language Programming
program contains a TAL routine that calls a C routine, each of which displays agreeting.
Example 17-2.  D-Series CRE Sample Program   (Page 1 of 2)
TAL Code
?SYMBOLS, INSPECT
?ENV COMMON
NAME talsrc;!Source in CRE run-time library routines:
?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM CREDECS (FILE)?POPLIST?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM CREDECS (?                                  TERMINATION)?POPLIST?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM CREDECS (?                                  CRE_FILE_CLOSE_,?                                  CRE_FILE_OPEN_,?                                  CRE_LOG_MESSAGE_,?                                  CRE_TERMINATOR_)?POPLIST
!Source in TAL run-time library routine:
?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM TALDECS (?                                  TAL_CRE_INITIALIZER_)?POPLIST
PROC c_routine LANGUAGE C;
EXTERNAL;                     !Declare EXTERNAL C routine
PROC talmain MAIN;
BEGIN  STRING .msg[0:13] := "Hello from TAL";
CALL TAL_CRE_INITIALIZER_;
CALL CRE_FILE_OPEN_ (cre^standard^log);  CALL CRE_LOG_MESSAGE_ (msg:14);  CALL c_routine;  CALL CRE_FILE_CLOSE_ (cre^standard^log);  CALL CRE_TERMINATOR_ (cre^completion^normal);END;

CRE Guidelines for TALMixed-Language Programming
C Code
#pragma symbols, inspect
#include <stdioh> nolist
/*file name:  csrc */void C_ROUTINE ()             /* C routine called by TAL */
{  short result;  short stderror = 2;  short error = 0;
result = fopen_std_file(stderror, error);
if ((result == 0) || (result == 1))    fprintf(stderr, "Hello from C\n");}
After you compile the TAL and C source files, you must bind the object files and the
TAL and C run-time libraries into a new object file.   The resulting object file can thenrun in the CRE, if the object file meets the requirements of the CRE.
For example, to bind object files named TALOBJ and COBJ and run-time library files
named TALLIB and CLARGE into a new object file named EXAMPLE, issue thefollowing Binder commands:
CLEAR
ADD * FROM talobjADD * FROM cobjSELECT SEARCH $SYSTEM.SYSTEM.TALLIBSELECT SEARCH $SYSTEM.SYSTEM.CLARGESELECT LIST * OFFBUILD example!