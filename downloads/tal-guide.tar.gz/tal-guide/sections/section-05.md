# Section 5: Using Expressions

information about operands (identifiers, data types, variables, constants) and aboutarithmetic and conditional operators and their effect on operands.
For information about assignment, CASE, IF, and group comparison expressions, see
Section 13, “Using Special Expressions.”
About Expressions An expression  is a sequence of operands and operators that, when evaluated,
produces a single value.  Operands in an expression include variables, constants, andfunction identifiers.  Operators in an expression perform arithmetic or conditionaloperations on the operands.
Expressions, for example, can appear in:
LITERAL declarations
Variable initializations and assignments
Array and structure bounds
Indexes to variables
Conditional program execution
Parameters to procedures or subprocedures
Complexity An expression can be:
A single operand, such as 5
A unary plus or minus operator applied to a single operand, such as –5
A binary operator applied to two operands, such as 5 * 8
A complex sequence, such as:
(((alpha + beta) / chi) * (delta — 145.9)) / zeta
Functionality The compiler at times requires arithmetic or conditional expressions.  Where indicated,
specify one of the following kinds of expressions:
Expression Description ExamplesArithmetic
expressionAn expression that computes a single numeric value
and that consists of operands and arithmeticoperators.398 + num / 84
10 LOR 12
Constant
expressionAn arithmetic expression that contains only
constants, LITERALs, and DEFINEs as operands.398 + 46 / 84
Conditional
expressionAn expression that establishes the relationship
between values and that results in a true or falsevalue.  It consists of relational or Boolean conditionsand conditional operators.Relational:   a < c
Boolean:        a OR b

OperandsUsing Expressions
function invocations.
The following subsections describe identifiers, data types, variables, constants,
LITERALs, and functions, followed by arithmetic expressions and conditionalexpressions.
Identifiers Identifiers are names you declare for objects such as variables, LITERALs, and
procedures (including functions).  You can form identifiers that:
Are up to 31 characters long
Begin with an alphabetic character, an underscore (_), or a circumflex (^)
Contain alphabetic characters, numeric characters, underscores, or circumflexes
Contain lowercase and uppercase characters (the compiler treats them all asuppercase)
Are not reserved keywords, which are listed in Table 5-1.
Can be nonreserved keywords, except as noted in Table 5-2.
To separate words in identifiers, use underscores rather than circumflexes.
International character-set standards allow the character printed for the circumflex tovary with each country.
Do not end identifiers with an underscore.  The trailing underscore is reserved for
identifiers supplied by the operating system.
The following identifiers are correct:
a2
myprog_23456789012_00name_with_exactly_31_characters
The following identifiers are incorrect:
2abc                                      !Begins with number
ab%99                                     !Illegal symbolVariable                                  !Reserved wordThis_name_is_too_long_so_it_is_invalid    !Too long
Though allowed as TAL identifiers, avoid identifiers such as:
Name^Using^Circumflexes
Name_Using_Trailing_Underscore_

OperandsUsing Expressions
Keywords have predefined meanings to the compiler when used as described in this
manual.  Table 5-1 lists reserved keywords, which you cannot use as identifiers.
Table 5-1.  Reserved Keywords
AND DO FORWARD MAIN RETURN TO
ASSERT DOWNTO GOTO NOT RSCAN UNSIGNEDBEGIN DROP IF OF SCAN UNTILBY ELSE INT OR STACK USECALL END INTERRUPT OTHERWISE STORE VARIABLECALLABLE ENTRY LABEL PRIV STRING WHILECASE EXTERNAL LAND PROC STRUCT XORCODE FIXED LITERAL REAL SUBPROCDEFINE FOR LOR RESIDENT THEN
Table 5-2 lists nonreserved keywords, which you can use as identifiers anywhere
identifiers are allowed, except as noted under Restrictions.
Table 5-2.  Nonreserved Keywords
Keyword RestrictionsAT
BELOW
BIT_FILLER Do not use as an identifier within a structure.BLOCK Do not use as an identifier in a source file that contains the NAME declaration.BYTES Do not use as an identifier of a LITERAL or DEFINE.CCOBOLELEMENTS Do not use as an identifier of a LITERAL or DEFINE.EXTEXTENSIBLEFILLER Do not use as an identifier within a structure.FORTRANLANGUAGENAMEPASCALPRIVATE Do not use as an identifier in a source file that contains the NAME declaration.UNSPECIFIEDWORDS Do not use as an identifier of a LITERAL or DEFINE.

OperandsUsing Expressions
The kind of values the variable can store
The amount of storage the compiler allocates for the variable
The operations you can perform on the variable
The byte or word addressing mode of the variable
Table 5-3 gives information about each data type.
Table 5-3.  Data Types
Data Type Storage Unit Kind of Values the Data Type Can RepresentSTRING Byte An ASCII character.
An 8-bit integer in the range 0 through 255 unsigned.
INT Word One or two ASCII characters.
A 16-bit integer in the range 0 through 65,535 (unsigned) or
–32,768 through 32,767 (signed).
A standard (16-bit) address (0 through 65,535).
INT(32) Doubleword A 32-bit integer in the range –2,147,483,648 through
+2,147,483,647.
An extended (32-bit) address (0 through 127.5K).
UNSIGNED n-bit field *UNSIGNED(1–15) and UNSIGNED(17–31) can represent a
positive unsigned integer in the range 0 through (2n – 1).
UNSIGNED(16) can represent an integer in the range 0 through
65,535 unsigned or –32,768 through 32,767 signed;  it canalso represent a standard address
FIXED Quadrupleword A 64-bit fixed-point number.  For FIXED(0) and FIXED ( *), the
range is –9,223,372,036,854,775,808 through+9,223,372,036,854,775,807.
REAL Doubleword A 32-bit floating-point number in the range
±8.6361685550944446E–78 through
±1.15792089237316189E77 precise to approximately 7
significant decimal digits.
REAL(64) Quadrupleword A 64-bit floating-point number in the same range as data type
REAL but precise to approximately 17 significant decimaldigits.
*For an UNSIGNED simple variable, the bit field can be 1 to 31 bits wide.
For an UNSIGNED array, the element bit field can be 1, 2, 4, or 8 bits wide.
As shown in Table 5-3, a data type consists of a keyword possibly followed by a value
enclosed in parentheses.  This value is the width or fpoint of the data type.

OperandsUsing Expressions
For INT, REAL, and UNSIGNED data types, the value in parentheses is a constant
expression that specifies the width , in bits, of the variable.   As of the D20 release, the
constant expression can include LITERALs and DEFINEs (previously declaredconstants and text).  The result of the constant expression must be one of the followingvalues:
Data Type Prefix width, in bits
INT 16*, 32, or 64*
REAL 32* or 64
UNSIGNED—simple variable,
parameter, or function resultA value in the range 1 through 31
UNSIGNED—array 1, 2, 4, or 8
*INT(16), INT(64), and REAL(32) are data type aliases, as described in
“Data Type Aliases” later in this section.
Here is an example of a width  that includes a LITERAL:
LITERAL dbwd_size = (4 * 8);     !INT_SIZE equals 32
INT(dbwd_size) num;              !Data type is INT(32)
LITERALs are described later in this section.  DEFINEs are described in the TAL
Reference Manual.
Specifying fpoints
For the FIXED data type, fpoint  is the implied fixed-point setting.  fpoint  is an integer in
the range –19 through 19.  If you omit fpoint , the default fpoint  is 0 (no decimal places).
A positive fpoint  specifies the number of decimal places to the right of the decimal
point:
FIXED(3)  x := 0.642F;          !Stored as 642
A negative fpoint  specifies a number of integer places to the left of the decimal point.
To store a FIXED value, a negative fpoint  truncates the value leftward from the decimal
point by the specified number of digits.  When you access the FIXED value, zerosreplace the truncated digits:
FIXED(-3) y := 642945F;         !Stored as 642; accessed
```
                                ! as 642000
```
Specifying Asterisks
As of the D20 release, FIXED( *) is a data type notation.  If you declare a FIXED( *)
variable, the value stored in the variable is not scaled.

OperandsUsing Expressions
Data Type Alias
INT INT(16)
REAL REAL(32)
FIXED(0) INT(64)
For consistency, the remainder of this manual avoids using data type aliases.  For
example, although the following declarations are equivalent, the manual usesFIXED(0):
FIXED(0) var;
INT(64) var;
Storage Units Storage units are the containers in which you can access data stored in memory.  The
system fetches and stores all data in 16-bit words, but you can access data as any of thestorage units listed in Table 5-4.
Table 5-4.  Storage Units
Storage Unit Number of Bits Data Type DescriptionByte 8 STRING One of two bytes that make up a word
Word*16 INT Two bytes, with byte 0 (most
significant) on the left and byte 1 (leastsignificant) on the right
Doubleword 32 INT(32),  REAL Two contiguous wordsQuadrupleword 64 REAL(64),  FIXED Four contiguous wordsBit field 1–16 UNSIGNED Contiguous bit fields within a wordBit field 17–31 UNSIGNED Contiguous bit fields within a
doubleword
*In TAL a word is always 16 bits regardless of the word size used by the system hardware.
Data Types of Expressions The result of an expression can be of any data type except STRING or UNSIGNED.
The compiler determines the data type of the result from the data type of the operandsin the expression.  All operands in an expression must have the same data type, withthe following exceptions:
An INT expression can include STRING, INT, and UNSIGNED(1–16) operands.The system treats STRING and UNSIGNED(1–16) operands as if they were 16-bitvalues.  That is, the system:
Puts a STRING operand in the right byte of a word and sets the left byte to 0.
Puts an UNSIGNED(1–16) operand in the right bits of a word and sets theunused left bits to 0, with no sign extension.  For example, for anUNSIGNED(2) operand, the system fills the 14 leftmost bits of the word withzeros.

OperandsUsing Expressions
The system treats UNSIGNED(17–31) operands as if they were 32-bit values.  Itplaces an UNSIGNED(17–31) operand in the right bits of a doubleword and setsthe unused left bits to 0, with no sign extension.  For example, for anUNSIGNED(29) operand, the system fills the three leftmost bits of the doublewordwith zeros.
In all other cases, if the data types do not match, use type transfer functions (described
in the TAL Reference Manual ) to make them match.
Variables A variable is a symbolic representation of an item or a group of elements.  You use
variables to store data that can change during program execution. Table 5-5 lists thekinds of variables you can declare.
Table 5-5.  Variables
Variable DescriptionSimple variable A variable that contains one element of a specified data type
Array A variable that contains multiple elements of the same data type
Structure A variable that can contain variables of different data typesSubstructure A structure nested within a structure or substructureStructure data item A simple variable, array, simple pointer, substructure, or structure pointer
declared in a structure or substructure; also known as a structure field
Simple pointer A variable that contains the memory address, usually of a simple variable
or array element, which you can access with this simple pointer
Structure pointer A variable that contains the memory address of a structure, which you
can access with this structure pointer
Constants A constant is a value you can store in a variable, declare as a LITERAL, or use as part
of an expression.  Constants can be numbers or character strings.  The kind and size ofconstants a variable can accommodate depend on the data type of the variable.Examples are:
255           !Integer number
1.02E12       !Floating-point number2.5F          !Fixed-point number"xyz"         !Character string2 * 5         !Constant expression
The following subsections describe numeric constants (integer, fixed-point, and
floating-point) and character string constants.
Integer Constants
Integer constants include STRING, INT, INT(32), and FIXED(0) numbers.Integer constants can be in binary, octal, decimal, or hexadecimal base.  Decimal is the
default number base.  Specify the base as shown in Table 5-6.

OperandsUsing Expressions
Number Base Prefix Digits Allowed ExampleDecimal None 0 through 9 46
Octal % 0 through 7 %57
Binary %B 0 or 1 %B101111Hexadecimal %H 0 through 9, A through F %H2F
STRING.   A STRING numeric constant is an unsigned 8-bit integer in the range 0
through 255.  Examples are:
59                              !Decimal base
%12                             !Octal base%B101                           !Binary base%h2A                            !Hexadecimal base
INT.  An INT numeric constant is a signed or unsigned 16-bit integer in the range 0
through 65,535 (unsigned) or –32,768 through 32,767 (signed).  Examples are:
45550                           !Decimal base (unsigned)
-8987                           !Decimal base (signed)%177                            !Octal base (unsigned)-%5                             !Octal base (signed)%B1001111000010001              !Binary base%h2f                            !Hexadecimal
INT(32).   An INT(32) numeric constant is a signed or unsigned 32-bit integer in the
range –2,147,483,648 through 2,147,483,647, suffixed by D for decimal, octal, or binary
integers, and by %D for hexadecimal integers.  Examples are:
0D                              !Decimal base
+14769D-327895066d
%1707254361d                    !Octal base
-%24700000221D
%B000100101100010001010001001d  !Binary base%h096228d%d                     !Hexadecimal base
-%H99FF29%D-%H99FF29 D                     !This form is allowed but not                                ! recommended; always include                                ! the % in the %D suffix

OperandsUsing Expressions
described next.
Fixed-Point Constants
A fixed-point constant is type FIXED and is a signed 64-bit fixed-point number.  The
range of a FIXED constant is determined by its fpoint .  For example, the ranges for
FIXED(0) and FIXED(2) are:
fpoint Range
FIXED(0) –9,223,372,036,854,775,808  through  9,223,372,036,854,775,807
FIXED(2) –92,233,720,368,547,758.08  through  92,233,720,368,547,758.07
Fixed-point numbers except FIXED(0) must be in decimal base.  A decimal fixed-point
number can include a fractional part preceded by a decimal point.  Append F to
decimal, octal, or binary FIXED numbers.  Append %F to hexadecimal numbers.  Here
are examples:
1200.09F                       !Decimal base; FIXED(2)
0.1234567F                     !Decimal base; FIXED(7)239840984939873494F            !Decimal base; FIXED(0)-10.09F                        !Decimal base; signed FIXED(2)
%B1010111010101101010110F      !Binary base; FIXED(0)-%765235512F                   !Octal base; signed FIXED(0)%H298756%F                     !Hexadecimal base; FIXED(0)
Floating-Point ConstantsA REAL or REAL(64) numeric constant is a signed floating-point number in the range
± 8.6361685550944446 * 10
-78 through ±1.15792089237316189 * 10+77.
A REAL numeric constant is a 32-bit value that is precise to approximately seven
significant digits.
A REAL(64) numeric constant is a 64-bit value that is precise to approximately 17significant digits.
The format of a floating-point constant includes an integer part, a fractional part
suffixed by E  for a REAL constant or L  for a REAL(64) constant, and an exponent as
follows:
356-30.3E-2
Exponent
Fractional part
Integer part

OperandsUsing Expressions
Decimal Value REAL REAL(64)0 0.0E0 0.0L0
2 2.0e0 2.0L0
2 0.2E1 0.2L12 20.0E-1 20.0L-1-17.2 -17.2E0 -17.2L0-17.2 -1720.0E-2 -1720.0L-2
Character String Constants
A character string constant consists of one or more contiguous ASCII characters
enclosed in quotation mark delimiters, as in:
"Now is the time for good parties."
If a quotation mark is a character within the string, use two quotation marks (in
addition to the quotation mark delimiters), as in:
"The title is ""East of Eden""."
The compiler does not upshift lowercase characters.When specifying character string constants, you can use any character in the ASCII
character set (shown in Appendix D), including:
Upper and lowercase alphabetic characters
Numerics 0 through 9
Special characters
Each character in a character string requires one byte of contiguous storage.  When
you initialize variables with character strings, follow these guidelines:
You can initialize simple variables or arrays of any data type with characterstrings.
When you initialize a simple variable, specify a character string that contains thesame number of bytes as the simple variable or fewer.
When you initialize an array, specify a character string that contains up to 127characters and that fits on one line.  If a character string is too long for one line, usea constant list and break the character string into smaller character strings.(Constant lists are described in Section 7, “Using Arrays.”)
When you assign character strings to variables, follow these guidelines:
You can assign character strings to STRING, INT, and INT(32) variables, but not to
FIXED, REAL, or REAL(64) variables.
In an assignment statement, specify a character string that contains up to fourcharacters, depending on the data type of the variable.

OperandsUsing Expressions
constant expression.  Each identifier in a LITERAL declaration is known as aLITERAL.  You can define a LITERAL once and then reference it by identifier manytimes in the program.  When a you need to change a LITERAL, you only change thedeclaration, not every reference to it.
LITERALs also make the source code more meaningful.  For example, identifiers such
as BUFFER_LENGTH and TABLE_SIZE are more meaningful than their respectiveconstant values of 80 and 128.
When you declare LITERALs, you can specify a constant expression for each identifier
or you can let the compiler supply some or all of the constants.
Declaring LITERALs With Constants
To include constants in a LITERAL declaration, specify the keyword LITERAL and one
or more identifiers , each followed by an equal sign (=) and a constant expression .
Separate consecutive identifier  and constant  combinations with commas.
The constant expressions in a LITERAL declaration:
Can be numeric constants of any data type except STRING or UNSIGNED
Can be character strings that each contain at most four characters long
Must not be the address of a global variable
Here are examples of LITERAL declarations that include constant expressions:
LITERAL buffer_length = 80;LITERAL true = -1,
```
        false = 0,        chars = "AB";
```
Declaring LITERALs Without Constants
You can omit constants for one or more identifiers in a LITERAL declaration.  The
compiler computes the omitted constants, using unsigned arithmetic:
If you omit the first constant in the declaration, the compiler supplies a zero.
If you omit a constant that follows an INT constant, the compiler supplies an INTconstant that is one greater than the preceding constant.  If you omit a constantthat follows a constant of any data type except INT, an error message results.
This example shows how the compiler supplies constants in a LITERAL declaration:
LITERAL a,             -- The compiler supplies 0
```
        b,             -- The compiler supplies 1        c,             -- The compiler supplies 2        d = 0,         -- You specify 0        e,             -- The compiler supplies 1        f = 17,        -- You specify 17        g,             -- The compiler supplies 18        h;             -- The compiler supplies 19
```

OperandsUsing Expressions
You can use LITERALs in declarations and statements:
LITERAL array_length = 50;               !Length of array
INT .buffer[0:array_length - 1];         !Declare array
You can also use LITERAL identifiers in subsequent LITERAL declarations:
LITERAL number_of_file_extents = 16,
file_extent_size_in_pages = 32,file_size_in_bytes = (number_of_file_extents '*'        file_extent_size_in_pages) * 2048D !bytes per page!;
Standard Functions A function is a procedure or subprocedure that returns a value to the calling
procedure or subprocedure.  Table 5-7 summarizes the kinds of operations thatstandard (built-in) functions perform.
Table 5-7.  Summary of Standard Functions
Category Operation
Type transfer Converts an expression from one data type to another
Address conversion Converts standard addresses to extended addresses or extended addresses
to standard addresses
Character test Tests for an alphabetic, numeric, or special ASCII character;  returns a true
value if the character passes the test or a false value if the character fails thetest
Minimum-maximum Returns the minimum or maximum of two expressionsCarry and overflow Tests the state of the carry or overflow indicator in the environment register;
returns a true value if the indicator is on or a false value if it is off
FIXED expression Returns the fpoint , or moves the position of the implied decimal point, of a
FIXED expression
Variable Returns the unit length, offset, data type, or number of occurrences of a
variable
Miscellaneous Tests for receipt of actual parameter;  returns the absolute value or one’s
complement from expressions;  returns the setting of the system clock orinternal register pointer
For example, the $DBL standard function converts an expression from any data type to
a signed INT(32) expression.  In the following example, $DBL converts an INTexpression to a signed INT(32) expression:
INT a;                  !Declare an INT variable
INT(32) b;              !Declare an INT(32) variable!Some code hereb := $DBL (a);          !Convert A to INT(32) expression                        ! and store it in B
Other examples are shown in various sections of this manual.  Each standard function
is described in the TAL Reference Manual.

Precedence of OperatorsUsing Expressions
OperatorsOperators in expressions can be arithmetic (signed, unsigned, or logical) or conditional
(Boolean or relational, signed or unsigned).
Within an expression, the compiler evaluates operators in order of precedence.  Within
each level of precedence, the compiler evaluates operators from left to right.  Table 5-8shows the level of precedence for each operator, from highest (0) to lowest (9).
Table 5-8.  Precedence of Operators (Page 1 of 2)
Operator Operation Precedence[
n] Indexing 0
. Dereferencing *0
@ Address of identifier 0
+ Unary plus 0
– Unary minus 0
.<...> Bit extraction 1
<< Signed left bit shift 2
>> Signed right bit shift 2
'<<' Unsigned left bit shift 2
'>>' Unsigned right bit shift 2
* Signed multiplication 3
/ Signed division 3
'*' Unsigned multiplication 3
'/' Unsigned division 3
'\' Unsigned modulo division 3
+ Signed addition 4
– Signed subtraction 4
'+' Unsigned addition 4
'–' Unsigned subtraction 4
LOR Bitwise logical OR 4
LAND Bitwise logical AND 4
XOR Bitwise exclusive OR 4
< Signed less than 5
= Signed equal to 5
> Signed greater than 5
<= Signed less than or equal to 5
>= Signed greater than or equal to 5
<> Signed not equal to 5
*   Not portable to future software platforms.

Precedence of OperatorsUsing Expressions
Operator Operation Precedence'<' Unsigned less than 5
'=' Unsigned equal to 5
'>' Unsigned greater than 5
'<=' Unsigned less than or equal to 5
'>=' Unsigned greater than or equal to 5
'<>' Unsigned not equal to 5
NOT Boolean negation 6
AND Boolean conjunction 7
OR Boolean disjunction 8
:= Assignment 9
.<...> := Bit deposit **9
**    Described in the TAL Reference Manual.
You can use parentheses to override the precedence of operators.  You can nest the
parenthesized operations.  The compiler evaluates nested parenthesized operationsoutward starting with the innermost level.  Here are examples:
414c * (a + b)
Resultc * ((a + b) / d)
Result(a OR b) AND c
Result

Arithmetic ExpressionsUsing Expressions
ExpressionsAn arithmetic expression is a sequence of operands and arithmetic operators that
computes a single numeric value of a specific data type.   Following are examples ofarithmetic expressions:
var1                 !operand
var1 / var2          !operand arithmetic-operator operandvar1 * (–var2)       !operand arithmetic-operator operand
You can append a unary plus operator or a unary minus operator to the leftmost
operand in the expression:
+var1 * 2            !unary plus
–var1 / var2         !unary minus
Arithmetic operators can be signed, unsigned, or logical, as described in this section.
Operands  in
Arithmetic ExpressionsAn operand consists of one or more elements that evaluate to a single value.  Table 5-9
describes the operands that can make up an arithmetic expression.
Table 5-9.  Operands in Arithmetic Expressions
Element Description ExampleVariable The identifier of a simple variable, array element, pointer,
structure data item, or equivalenced variable, with or without@ or an indexvar[10]
Constant A character string or numeric constant 103375
LITERAL The identifier of a named constant file_sizeFunction invocation The invocation of a procedure that returns a value $LEN (x)(expression) Any expression, enclosed in parentheses (x := y)Code space item The identifier of a  procedure, subprocedure, or label prefixed
with @ or a read-only array optionally prefixed with @, with orwithout an index@label_a

Arithmetic ExpressionsUsing Expressions
OperatorsSigned arithmetic operators and the operand types on which they can operate are
shown in Table 5-10.
Table 5-10.  Signed Arithmetic Operators
Operator Operation Operand Type*Example
+ Unary plus Any data type +5
– Unary minus Any data type –5
+ Binary signed addition Any data type alpha + beta– Binary signed subtraction Any data type alpha – beta
* Binary signed multiplication Any data type alpha * beta
/ Binary signed division Any data type alpha / beta
*The data type of the operands must match except as noted in “Data Types of Expressions”
earlier in this section.
Table 5-11 shows the combinations of operand types you can use with a binary signed
arithmetic operator and the result type yielded by such operators.  In eachcombination, the order of the data types is interchangeable.
Table 5-11.  Signed Arithmetic Operand and Result Types
Operand Type Operand Type Result Type ExampleSTRING STRING INT byte1 + byte2
INT INT INT word1 – word2
INT(32) INT(32) INT(32) dbl1 * dbl2
REAL REAL REAL real1 + real2REAL(64) REAL(64) REAL(64) quad1 + quad2FIXED FIXED FIXED fixed1 * fixed2
INT STRING INT word1 / byte1INT UNSIGNED(1–16) INT word + unsign12INT(32) UNSIGNED(17–31) INT(32) double + unsign20UNSIGNED(1–16) UNSIGNED(1–16) INT unsign6 + unsign9UNSIGNED(17–31) UNSIGNED(17–31) INT(32) unsign26 + unsign31
The compiler treats a STRING or UNSIGNED(1–16) operand as an INT operand.  If
bit <0> contains a 0, the operand is positive; if bit <0> contains a 1, the operand isnegative.
The compiler treats an UNSIGNED(17–31) operand as a positive INT(32) operand.

Arithmetic ExpressionsUsing Expressions
When you declare a FIXED variable, you can specify an implied fixed-point setting
(fpoint )—an integer in the range –19 through 19, enclosed in parentheses following the
keyword FIXED.  If you do not specify an fpoint , the default fpoint  is 0 (no decimal
places).
A positive fpoint  specifies the number of decimal places to the right of the decimal
point:
FIXED(3)  x := 0.642F;          !Stored as 642
A negative fpoint  specifies a number of integer places to the left of the decimal point.
To store a FIXED value, a negative fpoint  truncates the value leftward from the decimal
point by the specified number of digits.  When you access the FIXED value, zerosreplace the truncated digits:
FIXED(-3) y := 642945F;         !Stored as 642; accessed
```
                                ! as 642000
```
When FIXED operands in an arithmetic expression have different fpoints , the system
makes adjustments depending on the operator.
In addition or subtraction, the system adjusts the smaller fpoint  to match the larger
fpoint .  The result inherits the larger fpoint .  For example, the system adjusts the
smaller fpoint  in 3.005F + 6.01F to 6.010F,  and the result is 9.015F.
In multiplication, the fpoint  of the result is the sum of the fpoints  of the two
operands.  For example, 3.091F * 2.56F results in the FIXED(5) value 7.91296F.
In division, the fpoint  of the result is the fpoint  of the dividend minus the fpoint  of
the divisor.  (Some precision is lost.)  For example, 4.05F / 2.10F results in theFIXED(0) value 1.
To retain precision when you divide operands that have nonzero fpoints , use the
$SCALE standard function to scale up the fpoint  of the dividend by a factor equal
to the fpoint  of the divisor; for example:
FIXED(3) result, a, b;      !
fpoint  of 3
result := $SCALE(a,3) / b;  !Scale A to FIXED(6); result
```
                            ! is a FIXED(3) value
```

Arithmetic ExpressionsUsing Expressions
operands in an expression have different fpoints :
The fpoint of C is increased by 3FIXED a;
FIXED(2) b;FIXED (-1) c;
a := 2.015F * (b + c);
415Data declarations
The final result is truncated by
5 places to match the fpoint  of Aup 3
052 3
Effect on Hardware Indicators
Signed arithmetic operators affect the hardware indicators, as described in “Testing
Hardware Indicators” later in this section.
Unsigned Arithmetic
OperatorsYou can use binary unsigned arithmetic on operands with values in the range 0
through 65,535.  For example, you can use unsigned arithmetic with pointers thatcontain standard addresses.  Table 5-12 lists unsigned arithmetic operators and theoperand types on which they can operate.
Table 5-12.  Unsigned Arithmetic Operators
Operator Operation Operand Type Example'+' Unsigned addition STRING, INT, or UNSIGNED(1–16) alpha '+' beta
'–' Unsigned subtraction STRING, INT, or UNSIGNED(1–16) alpha '–' beta
'*' Unsigned multiplication STRING, INT, or UNSIGNED(1–16) alpha ' *' beta
'/' Unsigned division INT(32) or UNSIGNED (17–31)
dividend and STRING, INT, orUNSIGNED(1–16) divisoralpha '/' beta
'\' Unsigned modulo division *INT(32) or UNSIGNED (17–31)
dividend and STRING, INT, orUNSIGNED(1–16) divisoralpha '\' beta
*Unsigned modulo operations return the remainder.  If the quotient exceeds 16 bits, an overflow
condition occurs and the results will have unpredictable values.  For example, the modulooperation 200000D '\' 2 causes an overflow because the quotient exceeds 16 bits.

Arithmetic ExpressionsUsing Expressions
arithmetic operators and the result types yielded by such operators.  The order of theoperand types in each combination is interchangeable except in the last case.
Table 5-13.  Unsigned Arithmetic Operand and Result Types
Operator Operand Type Operand TypeResult
Type Example
'+'  '–' STRING STRING INT byte1 '–' byte2
INT INT INT word1 '+' word2
INT STRING INT byte1 '–' word1INT UNSIGNED (1–16) INT word1 '+' uns8STRING UNSIGNED (1–16) INT byte1 '–' uns5UNSIGNED(1–16) UNSIGNED(1–16) INT uns1 '+' uns7
'*' STRING STRING INT(32) byte1 ' *' byte2
INT INT INT(32) word1 ' *' word2
STRING INT INT(32) byte1 ' *' word1
INT UNSIGNED (1–16) INT(32) word1 ' *' uns9
STRING UNSIGNED (1–16) INT(32) uns1 ' *' uns7
UNSIGNED(1–16) UNSIGNED(1–16) INT(32) uns1 ' *' uns7
'/'  '\' UNSIGNED(17–31) or
INT(32)  dividendSTRING, INT, or
UNSIGNED(1–16)divisorINT dbword '\' word1
Effect on Hardware Indicators
Unsigned add and subtract operators affect the carry and condition code indicator, as
described in “Testing Hardware Indicators” later in this section.

Arithmetic ExpressionsUsing Expressions
on STRING, INT, and UNSIGNED(1–16) operands only.  Logical operators alwaysreturn 16-bit results.  Table 5-14 gives information about these operators.
Table 5-14.  Logical Operators and Result Yielded
Operator Operation Operand Type Bit Operations ExampleLOR Bitwise
logical ORSTRING, INT, or
UNSIGNED(1–16)1 LOR 1 = 1
1 LOR 0 = 10 LOR 0 = 010 LOR 12 = 14
10   1 0 1 0
12   1 1 0 0  ——   — — — —  14   1 1 1 0
LAND Bitwise
logical ADDSTRING, INT, or
UNSIGNED(1–16)1 LAND 1 = 1
1 LAND 0 = 00 LAND 0 = 010 LAND 12 = 8
10   1 0 1 0
12   1 1 0 0  ——   — — — —   8   1 0 0 0
XOR Bitwise
exclusiveORSTRING, INT, or
UNSIGNED(1–16)1 XOR 1 = 0
1 XOR 0 = 10 XOR 0 = 010 XOR 12 = 6
10   1 0 1 0
12   1 1 0 0  ——   — — — —   6   0 1 1 0
The Bit Operations column in the table shows the bit-by-bit operations that occur on
16-bit values.  Each 1-bit operand pair results in a 1-bit result.  The bit operands arecommutative.
Effect on Hardware Indicators
Logical operators set the condition code indicator, as described in “Testing Hardware
Indicators” later in this section.  Logical operators are always unsigned, however, socondition codes are not meaningful.

Conditional ExpressionsUsing Expressions
ExpressionsA conditional expression is a sequence of conditions and Boolean or relational
operators that establishes the relationship between values.  You can use conditionalexpressions to direct program flow.
Following are examples of conditional expressions:
a                     !condition
NOT a                 !NOT conditiona OR b                !condition OR conditiona AND b               !condition AND conditiona AND NOT b OR c      !condition AND NOT condition ...
Conditions A condition is an operand in a conditional expression that represents a true or false
state.  A condition can consist of one or more of the elements listed in Table 5-15.
Table 5-15.  Conditions in Conditional Expressions
Element Description ExampleRelational
expressionTwo conditions connected by a relational operator.  The result
type is INT;  a –1 if true or a 0 if false.  The example is true if Aequals B.If a = b THEN . . .
Group
comparisonexpressionUnsigned comparison of a group of contiguous elements with
another.  The result type is INT;  a –1 if true or a 0 if false.The example compares 20 words of two INT arrays.IF a = b FOR 20
WORDS THEN . . .
(conditional
expression)A conditional expression enclosed in parentheses.  The result
type is INT;  a –1 if true or a 0 if false.  The example is true ifboth B and C are false.  The system evaluates theparenthesized condition first, then applies the NOT operator.IF NOT (b OR c)
THEN . . .
Arithmetic
expressionAn arithmetic, assignment, CASE, or IF expression that has an
INT result*.  The expression is treated as true if its value is
not 0 and false if its value is 0.  The example is true if thevalue of X is not 0.IF x THEN . . .
Relational
operatorA signed or unsigned relational operator that tests a condition
code.  Condition code settings are CCL (negative), CCE (0), orCCG (positive).  The example is true if the condition codesetting is CCL.IF < THEN . . .
*If an arithmetic expression has a result other than INT, use a signed relational expression.

Conditional ExpressionsUsing Expressions
the relationship between two values.   Table 5-16 describes the Boolean operators, theoperand types you can use with them, and the results that such operators yield.
Table 5-16.  Boolean Operators and Result Yielded
Operator Operation Operand Type Result ExampleNOT Boolean negation; tests
condition for false stateSTRING, INT, or
UNSIGNED(1–16)True/False NOT a
OR Boolean disjunction;  produces
true state if either adjacentcondition is trueSTRING, INT, or
UNSIGNED(1–16)True/False a OR b
AND Boolean conjunction; produces
true state if both adjacentconditions are trueSTRING, INT, or
UNSIGNED(1–16)True/False a AND b
Evaluation of Boolean Operations
Conditions connected by the OR operator are evaluated from left to right only until a
true condition occurs.
Conditions connected by the AND operator are evaluated from left to right until a
false condition occurs.  The next condition is evaluated only if the preceding conditionis true.  In the following example, function F will not be called because A <> 0 is false:
a := 0;IF a <> 0 AND f(x) THEN ... ;
Effect on Hardware Indicators
Boolean operators set the condition code indicator, as described in “Testing Hardware
Indicators” later in this section.

Conditional ExpressionsUsing Expressions
Signed Relational Operators
Signed relational operators perform signed comparison of two operands and return a
true or false state.   Table 5-17 describes signed relational operators, operand datatypes, and the results yielded by such operators.
Table 5-17.  Signed Relational Operators and Result Yielded
Operator Operation Operand Type*Result
< Signed less than Any data type True/False
= Signed equal to Any data type True/False
> Signed greater than Any data type True/False
<= Signed less than or equal to Any data type True/False
>= Signed greater than or equal to Any data type True/False
<> Signed not equal to Any data type True/False
* The data type of the operands must match except as noted in “Data Types of Expressions”
earlier in this section.
Unsigned Relational Operators
Unsigned relational operators perform unsigned comparison of two operands and
return a true or false state.  Table 5-18 describes unsigned relational operators,operand data types, and the results yielded by such operators.
Table 5-18.  Unsigned Relational Operators and Result Yielded
Operator Operation Operand Type Result'<' Unsigned less than STRING, INT, UNSIGNED (1–16) True/False
'=' Unsigned equal to STRING, INT, UNSIGNED (1–16) True/False
'>' Unsigned greater than STRING, INT, UNSIGNED (1–16) True/False
'<=' Unsigned less than or equal to STRING, INT, UNSIGNED (1–16) True/False
'>=' Unsigned greater than or equal to STRING, INT, UNSIGNED (1–16) True/False
'<>' Unsigned not equal to STRING, INT, UNSIGNED (1–16) True/False
Effect on Hardware Indicators
Relational operators set the condition code indicator, as described in “Testing
Hardware Indicators” later in this section.

Conditional ExpressionsUsing Expressions
You use relational expressions in control statements to determine the flow of execution.
This example shows how you can direct program execution based on comparisonsusing signed and unsigned operators:
INT a :=  –2,                   !Unsigned value = %177776
```
    c :=   3,                   !Unsigned value = %000003    x := 271;
```
IF  a  '<' c  THEN x := 314;    !False; X still contains 271IF  a  <   c  THEN x := 313;    !True; X is assigned 313IF  a  <>  c  THEN              !True; this is an arithmetic
```
         IF < THEN x := 314;    ! comparison; since –2 < 3,                                ! CCL is set; x is assigned                                ! 314
```
IF  a '<>' c  THEN              !True; this is a logical
```
         IF > THEN x := 315;    ! comparison; since                                ! %177776 '>' %3, CCG is set;                                ! X is assigned 315
```
Assigning Conditional
ExpressionsYou can assign the value of a conditional expression to a variable.   The value assigned
is a –1 for the true state or a 0 for the false state.
For example, you can assign the result of a comparison to a variable:
INT neg := –1;           !Value = %177777
INT pos :=  1;           !Value = %000001INT result;
result := neg  <  pos;   !Signed comparison produces –1
result := neg '<' pos;   !Unsigned comparison produces 0
You can assign a –1 if either X or Y is a nonzero value (true), or a 0 if both X and Y are
zeros (false):
INT x, y, answer;
answer := x OR y;        !Assign –1 or 0 to ANSWER

Testing Hardware IndicatorsUsing Expressions
IndicatorsHardware indicators include condition code, carry, and overflow settings.  Arithmetic
and conditional operations, assignments, and some file-system calls affect the settingof the hardware indicators.  To check the setting of a hardware indicator, use an IFstatement immediately after the operation that affects the hardware indicator.
Condition Code Indicator The condition code indicator is set by a zero or a negative or positive result:
ResultState of Condition
Code Indicator
Negative CCL
0 CCE
Positive CCG
To check the state of the condition code indicator, use a relational operator (with no
operands) in a conditional expression.  Using a relational operator with no operands isequivalent to using the relational operator in a signed comparison against zero.  Whenused with no operands, signed and unsigned operators are equivalent.  The resultreturned by such a relational operator is as follows:
Relational Operator Result Returned< or '<' True if CCL
> or '>' True if CCG
= or '=' True if CCE
<> or '<>' True if not CCE
<= or '<=' True if CCL or CCE
>= or '>=' True if CCE or CCG
An example is:
IF < THEN ... ;
File-System Errors
File-system procedures signal their success or failure by returning an error number or
a condition code.  Your program can preserve the returned condition code for lateroperation as follows:
CALL WRITE( ... );
IF >= THEN  system_message := -1;            !TrueELSE  system_message := 0;             !FalseIF system_message = -1 THEN ... ;

Testing Hardware IndicatorsUsing Expressions
affected as follows:
Operation Carry IndicatorInteger addition On if carry out of bit <0>
Integer subtraction or negation On if no borrow out from bit <0>
INT(32) multiplication and division Always offMultiplication and division except INT(32) PreservedSCAN or RSCAN operation On if scan stops on a 0 (zero) byteArray indexing and extended structure addressing UndefinedShift operations Preserved
To check the state of the carry indicator, use $CARRY in an IF statement immediately
after the operation that affects the carry bit.  If the carry indicator is on, $CARRY is –1(true).  If the carry indicator is off, $CARRY is 0 (false).  The following example teststhe state of the carry indicator after addition:
INT i, j, k;              !Declare variable
i := j + k;IF $CARRY THEN ... ;      !Test state of carry bit from +
The following operations are not portable to future software platforms:
Testing $CARRY after multiplication or division
Passing the carry bit as an implicit parameter into a procedure or subprocedure
Returning the carry bit as an implicit result from a procedure or subprocedure
Overflow Indicator The overflow indicator is bit 8 in the environment register (ENV.V).  The overflow
indicator is affected as follows:
Operation Overflow IndicatorUnsigned INT addition, subtraction, and negation Preserved
Addition, subtraction, and negation except unsigned INT On or off
Division and multiplication On or offType conversions On, off, or preservedArray indexing and extended structure addressing UndefinedAssignment or shift operation Preserved
For example, the following operations turn on the overflow indicator (and interrupt
the system overflow trap handler if the overflow trap is armed through ENV.T):
Division by 0
Floating-point arithmetic result in which the exponent is too large or too small
Signed arithmetic result that exceeds the number of bits allowed by the data typeof the expression
For overflowed integer addition, subtraction, or negation, the result is truncated.  For
overflowed multiplication, division, or floating-point operation, the result isundefined.

Accessing OperandsUsing Expressions
Desired Effect MethodAbort on all overflows Use the system’s default trap handler.
Recover globally from overflows Use a user-supplied trap handler.
Recover locally from statement overflows Turn off overflow trapping and use $OVERFLOW.Ignore all overflows Turn off overflow trapping throughout the program.
For information on turning off overflow trapping and using $OVERFLOW, see the
description of $OVERFLOW in the TAL Reference Manual.
The following operations are not portable to future software platforms:
Passing the overflow bit as an implicit parameter into a procedure or
subprocedure
Returning the overflow bit as an implicit result from a procedure or subprocedure
Accessing Operands The remainder of this section discusses different ways of accessing operands:
Getting the address of a variable
Dereferencing a simple variable
Extracting a bit field
Shifting a bit field
For information on bit deposits, see the TAL Reference Manual.
Getting the Address
of VariablesTo get the address of a variable, prefix the variable identifier with @.  For example, you
can assign the address of an array element to a simple variable as follows:
INT .array[0:2];       !Declare array
INT var;               !Declare simple variable
var := @array[2];      !Assign address of ARRAY[2] to VAR
Dereferencing
Simple VariablesYou can dereference an INT simple variable in a statement by prefixing the variable
identifier with the dereferencing operator (.).  The content of the INT simple variablethen becomes the standard word address of another data item.  You can use thedereferencing operator in any INT arithmetic expression.
The dereferencing operator is not portable to future software platforms and is
described here only to explain its use in existing programs.
The following example uses the dereferencing operator to store data at the standard
word address that is saved in A:
INT a := 5;        !Declare A; initialize it with 5.a := 0;           !The 5 contained in A becomes an address;
```
                   ! thus 0 is stored at address G[5]
```

Accessing OperandsUsing Expressions
understand and maintain.  The following example:
Changes the data located at the address stored in VAR by using the dereferencingoperator
Changes the address stored in VAR by omitting the dereferencing operator
INT i;             !G[0]; declare I
INT a := 5;        !G[1]; declare A and initialize it with 5INT var;           !G[2]; declare VAR
var := @a;         !Assign 1 (the address of A) to VARi := .var;         !Assign 5 (the content of A to which
```
                   ! VAR points) to I
```
i := var;          !Assign 1 (the content of VAR or the
```
                   ! address of A) to I
```
Extracting Bit Fields You can access a bit extraction field in an INT expression without altering the
expression.  (Do not use a bit extraction field to compress data.  Instead, declare anUNSIGNED variable, specifying the appropriate number of bits in the bit field.)
To access a bit extraction field, specify an INT expression followed by a period (.) and
a bit-extraction field enclosed in angle brackets.  For example, to access bit <5> of anINT variable named VAR, specify the following construct with no intervening spaces:
var.<5>
To access bits <2> through <11> of VAR, specify the following construct with no
intervening spaces:
var.<2:11>
Specify the leftmost and rightmost bits of the field as INT constants.  The constant
specifying the rightmost bit must be equal to or greater than the constant specifyingthe leftmost bit.
The INT expression in a bit extraction operation can consist of STRING, INT, or
UNSIGNED(1–16) operands.  The system stores a STRING value in the right byte of aword and treats it as a 16-bit value, so you can access only bits <8> through <15> ofthe STRING value.  For example, to access bits <11> and <12> of a STRING simplevariable named BYTE_VAR, specify:
byte_var.<11:12>
You can assign the bits extracted from an array element as follows:
LITERAL len = 8;
STRING right_byte;INT array[0:len - 1];
right_byte := array[5].<8:15>;

Accessing OperandsUsing Expressions
INT word;
STRING var;
IF word.<0:7> = "A" THEN ... ;  !Check for “A” in 8-bit field
IF var.<15> THEN ... ;          !Check for nonzero value                                ! in bit <15>
To access bits in the result of an expression, enclose the expression in parentheses:
INT result;
INT num1 := 51;INT num2 := 28;
result := (num1 + num2).<4:7>;
Shifting Bit Fields You can shift a bit field a specified number of positions to the left or or to the right
within an INT or INT(32) expression.  You can then use the result of the shift as anoperand in an expression.
To shift a bit field, specify an INT or INT(32) expression, a left or right shift operator,
and the number of positions to shift.  For example, to shift the bits in an INT simplevariable named VAR two positions to the left, specify:
var '<<' 2
For an INT expression, the shift occurs within a word.  An INT expression can consist
of STRING, INT, or UNSIGNED(1–16) operands.
For an INT(32) expression, the shift occurs within a doubleword.  An INT(32)
expression can consist of INT(32) and UNSIGNED(17–31) operands.
Bit-Shift Operators
Table 5-19 lists the bit-shift operators you can specify.
Table 5-19.  Bit-Shift Operators
Operator Function Result'<<' Unsigned left shift through bit <0> Zeros fill vacated bits from the right
'>>' Unsigned right shift Zeros fill vacated bits from the left.
<< Signed left shift through bit <0> or
bit <1>Zeros fill vacated bits from the right.  In arithmetic
overflow cases, the final value of bit <0> isundefined (different for TNS/R accelerated modethan for TNS systems).
>> Signed right shift Sign bit (bit <0>) unchanged; sign bit fills vacated
bits from the left
For signed left shifts (<<), programs that run on TNS/R systems use unsigned left
shifts ('<<').

Accessing OperandsUsing Expressions
Specify the number of bit positions to shift as an INT expression.  A value greater than
31 gives undefined results (different on TNS and TNS/R systems).
Effect on Hardware Indicators
The bit-shift operation sets the condition code indicator, described under “Testing
Hardware Indicators” earlier in this section.
Bit-Shift Operations
Bit-shift operations include:
Operation User ActionMultiplication by powers of 2 For each power of 2, shift the field one bit to the left.  (Some
data might be lost.)
Division by powers of 2 For each power of 2, shift the field one bit to the right  (Some
data might be lost.)
Word-to-byte address conversion Shift the word address one bit to the left, using an unsigned
shift operator.
To multiply by powers of two, shift the field one position to the left for each power
of 2  (Some data might be lost.)  Here are examples:
a := b << 1;                 !Multiply by 2
a := b << 2;                 !Multiply by 4a := b << 5;                 !Multiply by 32
To divide by powers of two, shift the field one position to the right for each power of 2
(Some data might be lost.)  Here are examples:
a := b >> 3;                 !Divide by 8
a := b >> 4;                 !Divide by 16a := b >> 6;                 !Divide by 64
To convert a word address to a byte address, use an unsigned shift operator.  For
example, you can convert the word address of an INT array to a byte address andinitialize a STRING simple pointer with the byte address.  You can then access the INTarray as bytes and as words:
INT a[0:5];                  !Declare INT array
STRING .p := @a[0] '<<' 1;   !Declare and initialize                             ! STRING simple pointer with                             ! array byte addressp[3] := 0;                   !Assign 0 to fourth byte                             ! of A

Accessing OperandsUsing Expressions
INT b;                       !Declare variableb := b '<<' 8;               !Shift right byte into left
```
                             ! byte, leaving zero in                             ! right byte
```
The following unsigned left shift shows how zeros fill the vacated bits from the right:
Initial value  =  0 010 111 010 101 000
```
       '<<' 2  =  1 011 101 010 100 000
```
The following unsigned right shift shows how zeros fill the vacated bits from the left:
Initial value  =  1 111 111 010 101 000
```
       '>>' 2  =  0 011 111 110 101 010
```
The following signed left shift shows how zeros fill the vacated bits from the right,
while the sign bit remains the same (TNS systems only):
Initial value  =  1 011 101 010 100 000
```
        << 1   =  1 111 010 101 000 000
```
The following signed right shift shows how the sign bit fills the vacated bits from the
left:
Initial value  =  1 111 010 101 000 000
```
        >> 3   =  1 111 111 010 101 000
```