# Section 13: Using Special Expressions

This section describes the special expressions listed in Table 13-1.
Table 13-1.  Special Expressions
Expression Form Kind of Expression DescriptionAssignment Arithmetic Assigns the value of an expression to a variable
CASE Arithmetic Selects one of several expressions
IF Arithmetic Conditionally selects one of two expressionsGroup comparison Conditional Does unsigned comparison of two sets of data
The result of an expression can be of any data type except STRING or UNSIGNED.
The compiler determines the data type of an expression from the data type of theoperands in the expression.  All operands in an expression must have the same datatype, with the following exceptions:
An INT expression can include STRING, INT, and UNSIGNED(1–16) operands.The system treats STRING and UNSIGNED(1–16) operands as if they were 16-bitvalues.  The system:
Puts a STRING operand in the right byte of a word and sets the left byte to 0.
Puts an UNSIGNED(1–16) operand in the right bits of a word and sets theunused left bits to 0, with no sign extension.  For example, for anUNSIGNED(2) operand, the system fills the 14 leftmost bits of the word withzeros.
An INT(32) expression can include INT(32) and UNSIGNED(17–31) operands.The system treats UNSIGNED(17–31) operands as if they were 32-bit values.  Itplaces an UNSIGNED(17–31) operand in the right bits of a doubleword and setsthe unused left bits to 0, with no sign extension.  For example, for anUNSIGNED(29) operand, the system fills the three leftmost bits of the doublewordwith zeros.
In all other cases, if the data types do not match, use type transfer functions (described
in the TAL Reference Manual ) to make them match.

Assignment ExpressionUsing Special Expressions
ExpressionThe assignment expression assigns the value of an expression to a variable.
To use an assignment expression, specify:
The identifier of a variable
An assignment operator (:=)
An expression  that represents a value of the same data type as the variable.  The
result of the expression  becomes the result of the assignment expression.  The
expression  can be either:
An arithmetic expression
A conditional expression (excluding a relational operator with no operands),
the result of which has data type INT.
For example, you can increment a variable by specifying an assignment expression in
an IF statement.  As long as A + 1 is not 0 in the following example, the condition istrue and the THEN clause executes:
IF (a := a + 1) THEN ... ;
You can use an assignment expression as an index.  In the following example, A is
incremented and accesses the next array element:
IF array[a := a + 1] <> 0 THEN ... ;
You can use an assignment expression in a relational form.  The following example
assigns the value of B to A, then checks for equality with 0:
IF (a := b) = 0 THEN ... ;
You can use assignment expressions to assign a value to multiple variables:
a := b := c := d := 0;

CASE ExpressionUsing Special Expressions
expressions.  To use a CASE expression, specify:
CASE selector  OF
Specifies an INT arithmetic expression that selects the expression to evaluate.
BEGIN expressions ;
Specifies a choice of one or more expressions .  Separate successive expressions  with
semicolons.  Each expression  must be  either:
An INT arithmetic expression
A conditional expression (excluding a relational operator with no operands),
the result of which has data type INT.
The compiler numbers each BEGIN expression  consecutively, starting with 0.
When the selector  matches the compiler-assigned number of a BEGIN expression ,
the expression  is evaluated.  The result of expression  becomes the result of the
overall CASE expression.
OTHERWISE expression ;  (optional)
Specifies an expression to evaluate if the selector  does not select one of the BEGIN
expressions .  The OTHERWISE expression  and the BEGIN expressions  must have all
the same data type.  If you omit the OTHERWISE clause and an out-of-range caseoccurs, results are unpredictable.
END
Specifies the end of the CASE expression.
For example, you can use a CASE expression to select the value resulting from one of
several expressions  and assign it to variable X.  The expression  selected depends on the
value of selector  A:
INT x, a, b, c, d;
!Code to initialize variables
x := CASE a OF
```
       BEGIN         b; !If A is 0, assign value of B to X.         c; !If A is 1, assign value of C to X.         d; !If A is 2, assign value of D to X.         OTHERWISE –1; !If A is any other value,       END; ! assign –1 to X.
```
The CASE expression resembles the unlabeled CASE statement except that the CASE
expression selects an expression , while the unlabeled CASE statement selects a
statement .  (The unlabeled CASE statement is described in the TAL Reference Manual .)

IF ExpressionUsing Special Expressions
to a variable.  To use an IF expression, specify:
IF condition
Specifies a condition that, if true, causes the result of the THEN expression  to
become the result of the overall IF expression.  If the condition  is false, the result of
the ELSE expression  becomes the result of the overall IF expression.  The condition  is
either:
A conditional expression
An INT arithmetic expression.  If the result of this expression is not 0, thecondition  is true.  If the result is a 0, the condition  is false.
THEN expression
Specifies an expression to evaluate if the condition  is true.  The expression  is either:
An INT arithmetic expression
A conditional expression (excluding a relational operator with no operands),
the result of which has data type INT.
ELSE expression  (optional)
Specifies the expression to evaluate if the condition  is false.  The expression  is either:
An INT arithmetic expression
A conditional expression (excluding a relational operator with no operands),
the result of which has data type INT
For example, you can assign either of two arithmetic expressions  to VAR depending on
the condition  LENGTH > 0:
var := IF length > 0 THEN 10 ELSE 20;
You can include an IF expression, enclosed in parentheses, inside another expression:
var := index +
(IF index > limit THEN var * 2 ELSE var * 3);
You can nest an IF expression within another IF expression:
var := IF length < 0 THEN -1
```
       ELSE IF length = 0 THEN 0            ELSE 1;
```
The IF expression resembles the IF statement except that:
The THEN and ELSE clauses are both required in the IF expression.
The THEN and ELSE clauses contain expressions , not statements .

Group Comparison ExpressionUsing Special Expressions
ExpressionThe group comparison expression compares a variable with another variable or with a
constant.  In general, to use a group comparison expression, specify these items:
A variable ( var1) with or without an index
var1 can be a simple variable, array, simple pointer, structure, structure data item,
or structure pointer, but not a read-only array.
A relational operator.  All comparisons are unsigned regardless of whether youuse a signed or unsigned relational operator.  Relational operators are:
Signed: <, =, >, <=, >=, <>
Unsigned: '<', '=', '>', '<=', '>=', '<>'
An item to which to compare var1.  The item can be one of:
A variable ( var2)—a simple variable, array, read-only array, simple pointer,
structure, structure data item, or structure pointer—followed by the FORclause
A constant —a number, a character string, or a LITERAL
A constant list
Group comparison expressions often appear in IF statements:
IF var_1 <> 0 FOR n BYTES THEN ... ;
Comparing a Variable
to a Constant ListTo compare an array (but not a read-only array) to a constant list, specify the constant
list on the right side of the group comparison expression:
STRING array[0:3];
!Some code hereIF array = [ "ABCD" ] THEN ... ;                              !Compare ARRAY to constant list
Comparing a Variable
to a Single ByteTo compare a variable to a single byte, enclose a single constant in brackets ([ ]) on the
right side of the group comparison expression.  If the variable has a byte address or isa STRING structure pointer, the system compares a single byte regardless of the size ofthe constant:
STRING var[0:1];
!Some code hereIF var[0] = [5] THEN ... ;    !Compare VAR to a single byte
In the preceding example, if you do not enclose the constant 5 in brackets (or if VAR
has a word address or is an INT structure pointer), the system compares a word,doubleword, or quadrupleword as appropriate for the size of the constant.  Thefollowing example shows the preceding IF statement with brackets omitted:
IF var[0] = 5 THEN ... ;      !Compare VAR to two bytes

Group Comparison ExpressionUsing Special Expressions
to a VariableTo compare a variable to another variable, include the FOR clause in the group
comparison expression.  In the FOR clause, specify a count  value—a positive INT
arithmetic expression that specifies the number of bytes, words, or elements you wantto compare.
Comparing Bytes
To compare bytes regardless of the data type of var2, specify the BYTES keyword
following the count  value in the FOR clause of the group comparison expression.
BYTES compares the number of bytes specified by the count  value.  If both var1 and
var2 have word addresses, however, BYTES generates a word comparison for
(count  + 1) / 2 words.
For example, you can compare bytes between INT arrays:
LITERAL length = 12;                   !Number of array
```
                                       ! elementsINT word_array_one[0:length - 1];      !
```
var1
INT word_array_two[0:length - 1];      ! var2
INT byte_count;                        ! count value (number
```
                                       ! of bytes to compare)!Code to assign values to variablesIF word_array_one = word_array_two    FOR byte_count BYTES THEN ... ;
```
Comparing Words
To compare words regardless of the data type of var2, specify the WORDS keyword
following the count  value in the FOR clause of the group comparison expression.
WORDS compares the number of words specified by the count  value.
For example, to compare words instead of doublewords between INT(32) arrays,
multiply LENGTH by 2 and include the WORDS keyword:
LITERAL length = 12;                   !
count value (number
```
                                       !of words to compare)INT(32) dblw_array_one[0:length - 1];  !
```
var1
INT(32) dblw_array_two[0:length - 1];  ! var2
!Code to assign values to arraysIF dblw_array_one[0] = dblw_array_two[0]    FOR 2 * length WORDS THEN ... ;

Group Comparison ExpressionUsing Special Expressions
When you compare elements between arrays, you can specify the ELEMENTS
keyword following the count  value in the FOR clause of the group comparison
expression.  For example, you can compare doubleword elements between INT(32)arrays:
INT(32) in_array[0:19];
INT(32) out_array[0:19];
!Code to assign values to arrays
IF in_array <> out_array FOR 20 ELEMENTS THEN ... ;
When you compare array elements (as in the preceding example), the ELEMENTS
keyword is optional but provides clearer source code.
When you compare structure or substructure occurrences, you must specify the
ELEMENTS keyword in the group comparison expression:
STRUCT struct_one[0:9];
BEGIN  INT a[0:2];  INT b[0:7];  STRING c;  END;
STRUCT struct_two (struct_one)[0:9];!Code to assign values to structures
IF struct_one = struct_two FOR 10 ELEMENTS THEN ... ;
Using the Next Address The next address is the address (returned by the group comparison expression) of the
first byte or word in var1 that does not match the corresponding byte or word in var2.
To use the next address, you can declare a simple pointer and then use its identifier
(prefixed by @) in the next-address clause in a group comparison expression.  Here isan example of the next-address clause:
–> @next_addr_ptr
Here is an example of a group comparison expression that includes the next-address
clause:
array_one = array_two FOR 100 -> @next_addr_ptr ...

Group Comparison ExpressionUsing Special Expressions
Both var1 and var2 have standard byte addresses
Both var1 and var2 have standard word addresses
The compiler does an extended comparison (which is slightly less efficient) and
returns a 32-bit next address if:
Either var1 or var2 has a standard byte address and the other has a standard word
address
Either  var1 or var2 has an extended address
Variables (including structure data items) are byte addressed or word addressed as
follows:
Byte addressed STRING simple variables
STRING arraysVariables to which STRING simple pointers pointVariables to which STRING structure pointers pointSubstructures
Word addressed INT, INT(32), FIXED, REAL(32), or REAL(64) simple variables
INT, INT(32), FIXED, REAL(32), or REAL(64) arraysVariables to which INT, INT(32), FIXED, REAL(32), or REAL(64) simple         pointers pointVariables to which INT structure pointers pointStructures
After an element comparison, the next address might point into the middle of an
element, rather than at the beginning of the element.
You can, for example, compare the contents of two arrays and then determine from the
next address the first element that does not match:
INT .s_array[0:11] := "$SYSTEM SYSTEM  MYFILE  ",
```
    .d_array[0:11] := "$SYSTEM USER    MYFILE  ",    .ptr,     n;
```
IF d_array = s_array FOR 12 –> @ptr THEN ... ;
The preceding comparison stops with element [4];  PTR contains the address of
D_ARRAY[4] shown below:
0 1 2 3 4 5 6 7 8 9 ...
$SYSTEM SYSTEM  MYFILE      !Content of S_ARRAY$SYSTEM USER    MYFILE      !Content of D_ARRAY
To determine the number of array elements that matched, subtract the address of
D_ARRAY[0] from the address in PTR, using unsigned arithmetic:
n := @next_addr_ptr '-' @d_array;
```
                            !N gets 4 (fifth element)
```

Group Comparison ExpressionUsing Special Expressions
Code SettingThe system treats the items being compared as unsigned values.  After a group
comparison, you can test the condition code setting by using the following relationaloperators (with no operands) in a conditional expression:
< CCL if var1 '<' var2
= CCE if var1 =  var2
> CCG if var1 '>' var2
The following example compares two arrays and then tests the condition code setting
to see if the value of the element in D_ARRAY that stopped the comparison is less thanthe value of the corresponding element in S_ARRAY:
INT in_array[0:9];
INT out_array[0:9];
!Code to assign values to arrays
IF d_array = s_array FOR 10 –> ELEMENTS @ptr THEN  BEGIN                     !They matched    !Do something  ENDELSE  IF < THEN  ... ;          !PTR points to D_ARRAY element                            ! that is less than the                            ! corresponding S_ARRAY element