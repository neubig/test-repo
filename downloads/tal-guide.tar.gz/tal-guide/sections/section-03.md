# Section 3: Structuring Programs

structure is the order and level at which major components appear in a program.  Theformat is the spacing and alignment you use to make the program readable.
Source Files A program consists of one or more source files.  A source file can be a completeprogram or a part of a modular program.  In modular programming, for instance, youcan:
Divide a large program into smaller, more manageable source files
Work independently on a source file while other programmers work on othersource files
Compile and debug each source file separately.
Bind new object code to existing debugged object code, including general-purposelibrary routines
Use other languages, such as C or COBOL, for some of the source files
Group procedures into source files by the kinds of tasks the procedures perform;for example, a source file can provide input/output (I/O) processing and anothercan provide error processing
Compilation Units The input to the compiler is a single source file.  The source file, however, can containSOURCE directives that read in code from other source files.  The source file togetherwith code from other source files that are read in by SOURCE directives compose acompilation unit.
When you compile a compilation unit, the output is an object file that you can bind
with other object files into a new object file, as described in the Binder Manual.
Structuring
Compilation UnitsThe structure of a compilation unit is the order and level at which major components
appear.  Figure 3-1 shows the structure of a sample compilation unit.
Not all of the components shown in the figure need to appear in a compilation unit.
For example, if your compilation unit is a complete program, instead of a part of amodular program, the NAME declaration need not appear.

Compilation UnitsStructuring Programs
Main Procedure DeclarationUnblocked global data declarations
Blocked global data declarationsNAME declaration
Procedure declaration
Main procedure declarationLocal statements
Procedure declaration
Local declarations
Local statements
Local declarations
Local statementsLocal declarationsEntry-point declarations
Global scope
Local scope
Sublocal scope
345Subprocedure declaration
Sublocal declarations
Sublocal statementsEntry-point declarations

Compilation UnitsStructuring Programs
of procedures in a compilation unit.  You can declare any number of subprocedureswithin any procedure.  You cannot, however, declare a subprocedure within anothersubprocedure.
The shading in Figure 3-1 represents the scope of identifiers—that is, the set of levels at
which you can access identifiers:
Identifiers in the unshaded areas have global scope.  You can usually access globalidentifiers from all compilation units in the program and from within the currentcompilation unit.
Identifiers in the light gray areas have local scope.  You can access local identifiersonly from within the encompassing procedure.
Identifiers in the dark gray area have sublocal scope.  You can access sublocalidentifiers only from within the encompassing subprocedure.
Order of Components To structure a compilation unit, place declarations and statements in the following
order:
1. The NAME declaration, if present2. Any unblocked global data declarations3. Any blocked global data declarations4. Procedure declarations.  Within each procedure:
a. Any local data declarationsb. Any subprocedure declarations.  Within each subprocedure:
1) Any sublocal data declarations2) Any sublocal statements
c. Any local statements
The TAL compiler is a single-pass compiler.  The prescribed ordering enables the
compiler to recognize the scope and other characteristics of your data.  For example,you must declare variables before you use their identifiers in statements.
The following subsections give more information on how to specify program
components.

Naming Compilation UnitsStructuring Programs
Compilation UnitsYou can assign an identifier to the compilation unit by using the NAME declaration.  If
present, the NAME declaration must be the first declaration in the compilation unit.For example, you can assign the identifier INPUT_MODULE to a compilation unit asfollows:
NAME input_module;
Normally, you include the NAME declaration in compilation units that you compile
separately and then bind together by using Binder.  You must include the NAMEdeclaration in a compilation unit that contains blocked global data (those declaredwithin BLOCK declarations).
Declaring Data You declare data to associate identifiers with memory locations.  Table 3-1 lists thedata items you must declare before you access them.
Table 3-1.  Data Declarations
Data Item DescriptionLITERAL A named constant
DEFINE A named sequence of text
Simple variable A variable that contains one element of a specified data typeArray A variable that contains multiple elements of the same data typeStructure A variable that contains variables of different data typesSimple pointer A variable that contains a memory address, usually of a simple variable or
an array element, which you can access with this simple pointer
Structure pointer A variable that contains the memory address of a structure, which you can
access with this structure pointer
Equivalenced variable An alternate identifier and description for a previously declared variable
When you declare a variable, you specify at least a data type and an identifier.  For
example, you can declare a simple variable named TOTAL of data type INT as follows:
INT total;

Declaring Global DataStructuring Programs
Global data can be any data item listed in Table 3-1 earlier in this section.
All global data declarations except LITERALs and DEFINEs must appear before any
procedure declarations.  Global LITERAL and DEFINE declarations can appearbetween procedures as well.
You can declare unblocked or blocked data.
Declaring Unblocked
Global DataUnblocked global data are those you declare outside of BLOCK declarations
(described next).  Place all unblocked data declarations after the NAME declaration, ifpresent, and before any BLOCK declarations.  Identifiers of unblocked global data areaccessible to all compilation units in the program.
Declaring Blocked
Global DataBlocked global data are those you declare within BLOCK declarations.  The BLOCK
declaration lets you group global data into named or private data blocks.  All BLOCKdeclarations must appear after the NAME declaration and any unblocked datadeclarations and before the first procedure declaration.
Declaring Named Data Blocks
Use a named data block for global data you want to share with other compilation units
in the program.  You can include any number of named data blocks in a compilationunit.  The data declarations in a data block can be any data type:
BLOCK shared_data;
INT flag := True;  INT(32) index := 0;  STRING count := 0;  END BLOCK;
Declaring Private Data Blocks
Use a private data block for global data you want to share only with procedures within
the current compilation unit.  You can declare only one private data block in acompilation unit.  The private data block inherits the identifier you specify in theNAME declaration.
BLOCK PRIVATE;
INT average;  INT total;  END BLOCK;
For more information about global data blocks, see Section 14, “Compiling Programs.”

Declaring ProceduresStructuring Programs
compilation unit in the program.  You can declare procedures that perform discreteoperations such as I/O or error handling.  Normally, a procedure declaration includesa procedure heading and a procedure body.
Procedure Heading For the procedure heading, include the following:
The keyword PROC
The procedure identifier
Identifiers of formal parameters, if any
Procedure attributes, if any
Declarations of formal parameters, if any
A procedure heading that has no formal parameters or attributes looks like this:
PROC my_heading;
The following procedure heading has one parameter (named PARAM) and the MAIN
attribute.  MAIN means execute this procedure first.  The second line declares theformal parameter as being of data type INT:
PROC my_proc (param) MAIN;
```
    INT param;
```
A function is a procedure that returns a value to the caller.  You declare a function as
you do any other procedure except that in the function heading you specify a datatype for the return value.  Here is a function heading that specifies a return data typeof INT:
INT PROC my_function (param);
```
    INT param;
```
Procedure Body The procedure body is a BEGIN-END construct that can contain local data
declarations, subprocedure declarations, and local statements.  Here is an example:
PROC myproc;
BEGIN  INT var1;                      !Local data declarations  INT var2;  !Some code here  var1 := var1 - var2;           !Local assignment statement  END;
FORWARD Procedures If you need to call a procedure before you declare the procedure body, first declare a
procedure heading that includes the FORWARD keyword.  Once you declare aFORWARD procedure, you can call the procedure from anywhere in the currentcompilation unit.  For example, you can declare a FORWARD procedure namedTO_COME like this:
PROC to_come;
FORWARD;

Declaring ProceduresStructuring Programs
declare a procedure heading that includes the EXTERNAL keyword.  Once youdeclare an EXTERNAL procedure, you can call the procedure from anywhere in thecurrent compilation unit.  For example, you can declare an EXTERNAL procedurenamed FARAWAY like this:
PROC faraway;
EXTERNAL;
Procedure Entry Points A procedure entry point is an identifier by which callers can call a procedure.  The
primary entry point is the procedure identifier.
Secondary entry points are entry-point identifiers declared within the procedure and
then placed at statements where the procedure can begin executing.  The followingexample declares entry-point identifier ENTRY1 and places the identifier at astatement:
PROC myproc (param);            !Declare the procedure
```
    INT param;  BEGIN  ENTRY entry1;                 !Declare entry-point                                ! identifier  INT var;  !Some code hereentry1:                         !Apply entry-point  var := var - param;           ! identifier to statement  !More code  END;
```
Any procedure or subprocedure in the compilation unit can call an entry-point
identifier.  The caller must pass parameters as if the procedure identifier were beingcalled.  The called procedure begins executing at the location of the entry-pointidentifier.  At each activation of an entry-point identifier, all local variables receivetheir initial values.
The FORWARD declaration for the preceding ENTRY1 entry point is:
PROC entry1 (param);
```
    INT param;   FORWARD;
```
The EXTERNAL declaration for the ENTRY1 entry point is:
PROC entry1 (param);
```
    INT param;   EXTERNAL;
```

Declaring ProceduresStructuring Programs
procedure.  Local data can be any data item described in Table 3-1 earlier in thissection.  Within a procedure, all local data declarations must appear before anysubprocedure declarations or local statements.  Following is an example of how youdeclare local data:
PROC p;
BEGIN  INT total;                     !Declare local data  INT num;
!Subprocedures go here, if any   !Local statements go here  END;
Local Labels You can declare labels to reserve identifiers for later use as identifiers of locations in
the procedure.  For example, you can declare a label named LABEL_ONE and place itat a statement.  Here is an example:
PROC x;
BEGIN  INT var;  LABEL label_one;               !Declare a local label
!Lots of statements
label_one :                      !Place the label at this  var := 5;                      ! assignment statement  !More statements  END;
You can place the label identifier at the beginning of any statement, and then access
the label identifier from within the encompassing procedure.  (You can apply labelidentifiers without declaring them, but declaring them reserves their identifiers.)
Local Statements Statements perform specific operations.  Local statements are those you include in a
procedure but outside a subprocedure.  For example, to store a value in a variable, youcan use an assignment statement as follows:
PROC nonsense;
BEGIN  INT local_var;
local_var := 1000;             !Local assignment statement  END;

Declaring ProceduresStructuring Programs
uppercase reflect a keyword.  The assignment and move statements have no keywordsin them; their names are in lowercase.)
Table 3-2.  TAL Statements
Statement OperationASSERT Conditionally calls an error-handling procedure
Assignment Stores a value in a variable
CALL Invokes a procedure or a subprocedureCASE Selects a set of statements based on a selector valueCODE *Specifies machine codes or constants for inclusion in the object code
DO Executes a posttest loop until a true condition occursDROP Frees an index register or removes a label from the symbol tableFOR Executes a pretest loop for n times
GOTO Unconditionally branches to a label within a procedure or subprocedureIF Conditionally selects one of two possible statementsMove Copies a contiguous group of items from one location to anotherRETURN Returns from a procedure or a subprocedure to the caller;  returns a value from a
function.  As of the D20 release, it also can return a condition code value
RSCAN Scans a sequence of bytes, right to left, for a test characterSCAN Scans a sequence of bytes, left to right, for a test characterSTACK *Loads a value onto the register stack
STORE *Stores a register stack value in a variable
USE Reserves an index registerWHILE Executes a pretest loop while a condition is true
*  Not portable to future software platforms.
Local statements can refer to:
Global identifiers, including procedure identifiers, anywhere in the program
Local identifiers, including subprocedure identifiers, in the encompassing
procedure

Declaring SubproceduresStructuring Programs
SubproceduresYou declare subprocedures to specify discrete portions of source code within a
procedure.  You can call subprocedures only from within the encompassingprocedure.  You can declare any number of subprocedures within a procedure, butyou cannot declare subprocedures within subprocedures.
Place any subprocedure declarations following the procedure’s local declarations.  In a
subprocedure declaration, you normally specify a heading and a body.
Subprocedure Heading In the subprocedure heading, include:
The keyword SUBPROC
The subprocedure identifier
Identifiers of formal parameters, if any
The attribute VARIABLE, if needed
Declarations of formal parameters, if any
For example, a subprocedure heading with no formal parameters or attributes looks
like this:
SUBPROC my_heading;
A subprocedure heading with one parameter (named PARAM) and the VARIABLE
attribute looks like this:
SUBPROC my_heading (param) VARIABLE;
```
    INT param;
```
Subprocedure Body For the subprocedure body, specify a BEGIN-END construct that can contain sublocal
data declarations and statements.  For example, within the procedure namedMYPROC you can declare a subprocedure named MYSUB, declare sublocal dataVAR1 and VAR2, and assign a value to VAR1 in a sublocal assignment statement:
PROC myproc;              !Declare MYPROC
BEGIN  !Local data declarations
SUBPROC mysub;          !Declare MYSUB
```
    BEGIN    INT var1;    INT var2;
    var1 := var1 - var2;
    END;                  !End MYSUB
```
!Local statements
END;                    !End MYPROC
FORWARD Subprocedures If you need to call a subprocedure before you declare its body, declare a FORWARD
subprocedure.  You can then call it from anywhere in the encompassing procedure.
SUBPROC to_come;
FORWARD;

Declaring SubproceduresStructuring Programs
The primary entry point is the subprocedure identifier.
Secondary entry points are entry-point identifiers declared within the subprocedure
and then placed at statements where the subprocedure can begin executing.  Thefollowing example declares entry-point identifier SUB_ENTRY and places theidentifier at a statement:
PROC myproc;
BEGIN  !Local data declarations
SUBPROC some_sub (param);     !Declare subprocedure
```
      INT param;    ENTRY sub_entry;            !Declare entry-point                                ! identifier    INT var;    !Some code here  sub_entry:                    !Apply entry-point    var := var - param;         ! identifier to statement    !More code    END;                        !End subprocedure
```
!More subprocedures  !Local statements
CALL sub_entry (1);           !Call entry-point SUB_ENTRY  END;
A subprocedure can call an entry-point identifier of any subprocedure within the same
procedure.  The caller must pass parameters to the entry-point identifier as if it werecalling the subprocedure identifier.  The called subprocedure begins executing at thelocation of the entry-point identifier.  All the sublocal variables of the calledsubprocedure receive their initial values each time the subprocedure is activated.
If you need to reference a subprocedure entry-point identifier before you declare the
subprocedure, a FORWARD declaration is required:
SUBPROC sub_entry (param);
```
    INT param;   FORWARD;
```

Declaring SubproceduresStructuring Programs
within the same subprocedure.  Sublocal data can be any data item described inTable 3-1 earlier in this section.  Within a subprocedure, all sublocal data declarationsmust appear before any sublocal statements.  Also, sublocal arrays and structures mustbe directly addressed.  (Addressing is explained in Section 4, “Introducing theEnvironment.”)  Following is an example of how you declare sublocal data:
PROC myproc;
BEGIN  !Local data declarations
SUBPROC mysub;
```
    BEGIN    INT var1;               !Sublocal data declarations    INT var2;
    var1 := var1 - var2;    !Sublocal statement
    END;
```
!Local statements
END;
Sublocal Labels You declare sublocal labels as you do local labels, except that you declare sublocal
labels within a subprocedure.  You can access sublocal labels from anywhere withinthe encompassing subprocedure.
Sublocal Statements Within a subprocedure, you can specify any statement described in Table 3-2 earlier in
this section.  Sublocal statements can access:
Global identifiers, including procedures, anywhere in the program
Local identifiers, including subprocedures, in the encompassing procedure
Sublocal identifiers in the encompassing subprocedure

Formatting ProgramsStructuring Programs
compiler allows almost a free format for source code.  You can use any format thatserves your purposes.  The only limitation is that the maximum line length for sourcecode is 132 characters.
Here is an example of a format that is difficult to read:
INT num1;INT num2;INT num3;STRING char1;STRING char2;STRING
char3;PROC format_example MAIN; BEGIN num1 := 8; num2 := 5;num3 := num1 + num2; char1 := "A"; char2 := "B"; char3 :="C"; END;
Here is an example of a format that is easy to read:
INT num1;
INT num2;INT num3;STRING char1;STRING char2;STRING char3;
PROC format_example MAIN;
BEGIN  num1 := 8;  num2 := 5;  num3 := num1 + num2;  char1 := "A";  char2 := "B";  char3 := "C";  END;
In the second format, you can readily see each declaration.  You can tell where the
global declarations end and the procedure begins.  You can quickly see what theprocedure body contains.  You have space to add comments to clarify what is going onin the program.

Formatting ProgramsStructuring Programs
understand and maintain.  For instance, you can explain the purpose of certainconstructs or variables.  During compilation, the compiler ignores comments.
You can specify comments using either of two forms or can use both forms in the same
compilation unit:
Beginning Delimiter Ending Delimiter ExampleTwo hyphens End of line --One form of comments
Exclamation point Exclamation point or end of line !Another form of comments
Explaining the Purpose of Variables
Comments can explain the purpose of variables:
INT num1;                    --16-bit simple variables
INT num2;                    -- to use for processingINT num3;                    -- integer values
STRING char1;                --8-bit simple variables
STRING char2;                -- to use for processingSTRING char3;                -- ASCII characters
PROC format_proc MAIN;       --Declare FORMAT_PROC
BEGIN  --Assign values to variables  num1 := 8;  num2 := 5;  num3 := num1 + num2;  char1 := "A";  char2 := "B";  char3 := "C";  --Code to process the variables  END;                       --End FORMAT_PROC
Documenting Omitted Parameters
Comments within a CALL statement can help identify omitted parameters:
PROC some_proc (index, num, length, limit, total)
EXTENSIBLE;    INT index, num, length, limit, .total;  BEGIN  !Lots of code  END;
PROC caller_proc;
BEGIN  INT total;  !Some code  CALL some_proc (0, !num!, !length!, 40, total);  END;

Formatting ProgramsStructuring Programs
When you want the compiler to ignore a portion of the code, you can either:
Comment it out
Use conditional compilation
For example, when your code contains  ! comments, you can use  -- to comment
out the portion you want the compiler to ignore:
PROC my_proc;
BEGIN  !Lots of code  END;
--Comment out the following portion of code:
--PROC no_proc;--  BEGIN--  !Lots of code--  END;--End of commented-out portion of code
PROC your_proc;
BEGIN  !Lots of code  END;
Alternatively, you can use conditional compilation for the portion you want the
compiler to ignore.  Here is the preceding example shown with the DEFINETOG , IF,and ENDIF conditional compilation directives:
PROC my_proc;
BEGIN  !Lots of code  END;
?DEFINETOG omit              !Define toggle OMIT without
```
                             ! changing its off state?IF omit                     !If OMIT is off,PROC this_proc;              ! skip THIS_PROC BEGIN  !Lots of code  END;?ENDIF omit                  !End of skipped portion
```
PROC your_proc;
BEGIN  !Lots of code  END;
In the preceding example, DEFINETOG and named toggles are D20 or later features.
For pre-D20 systems, you can use RESETTOG with numeric toggles instead.  For moreinformation on these directives, see the TAL Reference Manual.

Formatting ProgramsStructuring Programs
BEGIN-END ConstructsYou use BEGIN-END constructs to group various items into a single entity.  If you
align the BEGIN and END keywords vertically, the program is easier to understand.Following are some uses for BEGIN-END constructs.
Procedure or Subprocedure Body
Within a procedure (or subprocedure) declaration, enclose the procedure (or
subprocedure) body in a BEGIN-END construct:
PROC add;
BEGIN  !Procedure body  END;
Structure Layout
Within a structure declaration, enclose the structure layout in a BEGIN-END construct:
STRUCT inventory;
BEGIN  !Structure item  !Structure item  !Structure item  END;
Compound Statements
Place a compound statement in a BEGIN-END construct.  A compound statement
consists of multiple statements you want treated as a single logical statement:
BEGIN
!Statement!Statement!StatementEND;
For example, you can specify a choice of compound statements in an IF statement as
follows:
IF a < b THEN
BEGIN                 !Begin compound statement  a := 1;  b := 2;  c := a + b;  END                   !End compound statementELSE  BEGIN                 !Begin compound statement  a := 5;  b := 6;  c := a + b;  END;                  !End compound statement

Formatting ProgramsStructuring Programs
Ending Data Declarations
Here is an example of using semicolons to end data declarations:
INT    num1;
INT    num2;INT    num3;STRING char1;STRING char2;
The following example is equivalent to the preceding example:
INT    num1, num2, num3;
STRING char1, char2;
Separating Successive Statements
You must use a semicolon between successive statements.  A semicolon before the last
END keyword of a procedure or subprocedure is optional.
PROC myproc;
BEGIN  INT num1;  INT num2 := 8;  INT total;
num1 := 9;              !Required semicolon
total := num1 + num2;   !Optional semicolon  END;
Using Semicolons Within Statements
Within a statement:
You can use a semicolon before the END keyword that terminates a compound
statement.
You cannot use a semicolon just before an ELSE or UNTIL keyword.
IF a < b THEN
BEGIN  a := 1;  b := 2;                 !Optional semicolon  END                     !No semicolon hereELSE  a := 0;
DO
a := a + b              !No semicolon hereUNTIL  a < b;

Using Compiler DirectivesStructuring Programs
You can use a semicolon without a statement to create a null statement, which means
do nothing.  The compiler generates no code for null statements.  You can use a nullstatement anywhere you can use a statement, except immediately before an ELSE orUNTIL keyword.
Here is an example of a null statement embedded in a labeled CASE statement:
CASE var OF
BEGIN  0 ->      ;                   !Null statement  1 ->      CALL fixit;         !CALL statement  END;
Using Compiler
DirectivesCompiler directives are options provided by the TAL compiler so you can control the
compilation.  For example, compiler directives let you:
Specify files from which to read in source code
Specify the content of compiler listings and object files
Conditionally compile portions of source code
You can specify most compiler directives either in the compilation command (that
runs the compiler) or in your source code.
In the compilation command, you can specify directives following the semicolon.   For
example, to compile the source file MYSRC, send the object code to object file MYOBJ,and specify the NOLIST directive to suppress the compiler listing, issue the followingcommand at the TACL prompt:
TAL /IN mysrc/ myobj; NOLIST
In your source file, you specify directives in directive lines.  Start each directive line
with a question mark (?) in column 1 as follows:
?LIST
!Some code here?NOLIST, NOCODE, INSPECT, SYMBOLS, NOMAP, NOLMAP, GMAP?CROSSREF, INNERLIST
The following directive line has a continuation line for the argument list of the
SEARCH directive:
?SEARCH (file1, file2, file3, file4,
?        file5, file6)

Using Compiler DirectivesStructuring Programs
at least the leading parenthesis of the argument list on the same line as the directivename:
?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (
?                         PROCESS_GETINFO_, PROCESS_STOP_)?POPLIST