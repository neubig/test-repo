# Section 6: Using Simple Variables

simple variables to store data that can change during program execution.
This section describes:
Declaring simple variables
Initializing simple variables
Allocating storage for simple variables
Assigning data to simple variables
Using simple variables, discussed by data type
Declaring
Simple VariablesBefore you access a simple variable, you must declare it.  Declaring a variable
associates an identifier with a memory address and informs the compiler how muchmemory storage to allocate for the variable.
You declare a simple variable by specifying a data type  and an identifier , using the type
and identifier formats described in Section 5, “Using Expressions.”  For example, youcan declare a simple variable named NUM of data type INT as follows:
INT num;
You can declare more than one variable in the same declaration.  In this format,
separate the variables with commas:
INT num1,
```
    num2,    num3;
```
Simple variables are always directly addressed.
Specifying Data Types When you declare a simple variable, you can specify any of the following data types.
The data type determines the storage unit the compiler allocates for each simplevariable:
Data Type Storage UnitSTRING Word
INT Word
INT(32) or REAL DoublewordREAL(64) or FIXED QuadruplewordUNSIGNED( n) Bit sequence of specified width
“Simple Variables by Data Types” in this section gives more information on specific
data types.

Declaring Simple VariablesUsing Simple Variables
declare it.  Following the identifier in the declaration, specify an assignment operator(:=) and an initialization value :
INT var := 45;                  !Declare VAR and initialize
```
                                ! it with the value 45
```
You can initialize a simple variable with character strings or numbers.
Initializing With Character Strings
When you initialize with a character string, specify a character string that has the same
number of bytes as the simple variable or fewer.  Each character in a character stringrequires one byte of contiguous storage.  The value of any uninitialized bytes areundefined.  In the following diagram, the question mark denotes an undefined value:
INT(32) chars := "ABC";
"A" "B"
"C" ?
Initializing With Numbers
When you initialize with a number, you must specify a value of the same data type as
the variable.  In other words, specify a value that is in the range and format describedfor each data type in “Simple Variables by Data Type” in this section.
For example, to initialize a REAL simple variable, specify a REAL value.  To initialize
an INT(32) simple variable, specify an INT(32) value:
REAL flt_num := 365335.6E-3;
INT(32) dbl_num := 256D;
Specifying Number Bases
When you initialize a STRING, INT, or INT(32) variable with a number, you can
specify integer constants in binary, octal, decimal, or hexadecimal base.  The defaultnumber base in TAL is decimal.  Table 6-1 describes the format of each number base.
Table 6-1.  Number Base Formats
Number Base Prefix Digits Allowed ExampleDecimal None 0 through 9 46
Octal % 0 through 7 %57
Binary %B 0 or 1 %B101111Hexadecimal %H 0 through 9, A through F %H2F

Declaring Simple VariablesUsing Simple Variables
At the global level, initialize variables with expressions that contain only constants or
LITERALs as operands.  At the local or sublocal level, you can use any arithmeticexpression, including previously declared variables:
INT global := 34;               !Only constants allowed in
```
                                ! global initializationsPROC mymain MAIN;  BEGIN  INT local := global + 10;     !Any expression allowed in  INT local2 := global * local; ! local and sublocal  FIXED local3 := $FIX(local2); ! initializations  !Lots of code  END;                          !End of MYMAIN procedure
```
Allocating Simple Variables The compiler allocates storage in the global, local, or sublocal storage area based on
the level at which you declare the variable, as shown in Figure 6-1.  The questionmarks in the diagram denote undefined bytes.
Figure 6-1.  Simple Variable Storage Allocation
STRING a;    !Global data
STRING b;INT c;
PROC proc_a;
BEGIN  STRING d;  !Local data  REAL e;   SUBPROC subproc_a;    BEGIN    INT f;   !Sublocal data    FIXED g;    !Lots of code    END;
!More code
END;  G[0]
S[0]Global
data?A
G[1]
G[2]
L[1]
L[2]
S[-4]?B
C
. . .
D?
F
S[-3]S[-2]S[-1]L[3]Local
data
Sublocal
data. . .
G
351E
Storage allocation specific to each data type is described in “Simple Variables by Data
Type” later in this section.   Storage allocation in programs that include BLOCKdeclarations is described in Section 14, “Compiling Programs.”

Assigning Data to Simple VariablesUsing Simple Variables
Simple VariablesAfter you declare a variable, you can assign a value to it.  In the assignment statement,
specify the identifier  of a previously declared simple variable, an assignment operator
(:=), and an expression :
INT var;                     !Declare VARvar := 345;                  !Assignment statement
Assigning Variables You can assign an arithmetic expression that contains variables:
INT var1 := 5;               !Declare and initialize VAR1
INT var2;                    !Declare VAR2
var2 := var1 + 10;           !Assign result of arithmetic
```
                             ! expression to VAR2
```
Matching Data Types Assign values that match the data type of the variable.  The assignment value should
be in the range and format described for each data type in “Simple Variables by DataType” in this section.  For example, if you declare a REAL simple variable, specify anassignment value in the correct range and format for REAL constants:
REAL num;                    !Declare NUM, a REAL variablenum := 36.6E-3;              !Assign REAL value to NUM
Converting Data Types If necessary you can use type transfer functions to convert the data type of the
assignment value to match the variable.    For example, to convert an INT assignmentvalue to an INT(32) value, use the $DBL standard function:
INT(32) dblwd;dblwd := $DBL(256);          !Convert assignment value to
```
                             ! match data type of variable
```
Assigning
Character StringsYou can assign character strings to STRING, INT, and INT(32) variables in assignment
statements.  In assignments, the character string can contain one to four ASCIIcharacters, depending on the variable’s data type.  (You can also initialize suchvariables with character strings when you declare the variables.)
You cannot, however, assign character strings to FIXED, REAL, or REAL(64) variables,
although you can initialize such variables with character strings when you declare thevariables.

Simple Variables by Data TypeUsing Simple Variables
example, the first assignment statement is equivalent to the three assignmentstatements that follow it:
INT int1;
INT int2;INT int3;                    !Declarations
int1 := int2 := int3 := 16;  !First assignment statementint1 := 16;                  !These three assignment
int2 := 16;                  ! statements are equivalent toint3 := 16;                  ! the first assignment statement
Simple Variables
by Data TypeThe following subsections present information about simple variables depending on
their data type.
STRING Simple Variables A STRING simple variable can contain an unsigned 8-bit integer in the range 0
through 255 or a one-character character string:
STRING a := 59;                !Decimal number
STRING b := %12;               !Octal numberSTRING c := %B101;             !Binary numberSTRING d := %h2A;              !Hexadecimal numberSTRING e := "A";               !Character string
Storage Allocation
A STRING simple variable represents a byte value, but the compiler allocates a word.
The compiler allocates the initialization value in the left byte of the word.  The rightbyte is undefined.  Here are allocation examples of initializations with a characterstring and a number:
"A" ?
254 ?
352STRING a_char := "A";
STRING byte_num := 254;

Simple Variables by Data TypeUsing Simple Variables
through 65,535 (unsigned) or –32,768 through 32,767 (signed).  It can also contain acharacter string of up to two characters:
INT a := 5;                    !Unsigned decimal number
INT b := -%5;                  !Signed octal numberINT c := %B1001111000010001;   !Binary numberINT d := %h2f;                 !Hexadecimal numberINT e := "AB";                 !Character string
You can initialize INT variables with the standard addresses of simple variables,
arrays, or structures.  The @ operator fetches the address of the variable:
INT var;                       !Declare word-addressed VARINT var_addr := @var;          !Declare VAR_ADDR; initialize
```
                               ! it with word address of VAR
```
You can convert a word address to a byte address by using a logical left bit-shift
operation ( '<<' 1 ):
INT var;                       !Declare word-addressed VARSTRING .var_ptr := @var '<<' 1;
```
                               !Declare VAR_PTR; initialize                               ! it with converted byte                               ! address of VAR
```
You can convert a byte address to a word address by using a logical right bit-shift
operation ( '>>' 1 ):
STRING var;                    !Declare byte-addressed VARINT var_addr := @var '>>' 1;   !Declare VAR_ADDR; initialize
```
                               ! it with converted word                               ! address of VAR
```

Simple Variables by Data TypeUsing Simple Variables
The compiler allocates a word for each INT simple variable.  Here are examples of
numeric and character string initializations:
INT int_num := %110;
INT two_chars := "AB";%110
"A" "B"
For INT simple variables, a one-byte initialization behaves differently from a one-byte
assignment as follows:
If you initialize  an INT variable with a one-byte character string, the compiler
allocates the character in the left byte of the word.  The right byte is undefined.
If you assign  a one-byte character string to the variable, at run-time the system
places it in the right  byte and sets the left byte to zero.  If you want the character to
be placed in the left byte, assign a two-byte character string that consists of acharacter and a blank space.
The following example contrasts how the system stores a byte initialization in INT
simple variables as opposed to how the system stores a byte assignment:
"A" ?
0"A"
"A" "    "
354INT il, i2;
INT i3 := "A";  !Initialize with "A"i1 := "A";      !Assign "A"i2 := "A ";     !Assign "A" and a blank

Simple Variables by Data TypeUsing Simple Variables
range –2,147,483,648 through 2,147,483,647, suffixed by D for decimal, octal, or binary
integers or %D for hexadecimal integers.  It also can contain a character string of up to
four characters.
INT(32) a := 0D;                !Decimal number
INT(32) b := -327895066D;       !Decimal numberINT(32) c := %1707254361D;      !Octal numberINT(32) d := %B000100101100010001010001001D;                                !Binary numberINT(32) e := -%H99FF29%D;       !Hexadecimal numberINT(32) f := "ABCD";            !Character string
You can initialize INT(32) simple variables with the 32-bit addresses of extended
indirect variables:
INT .EXT x_array[0:2];          !Declare X_ARRAY
INT(32) x_addr := @x_array[0];  !Declare X_ADDR; initialize                                ! it with address of X-ARRAY
Storage Allocation
For an INT(32) simple variable, the compiler allocates a doubleword.   The compiler
allocates numeric and character string initialization values as follows:
INT(32) dbl_num := 256D;
INT(32) dbl_chars := "ABC";
355"A" "B"
"C" ?256D

Simple Variables by Data TypeUsing Simple Variables
±8.6361685550944446 * 10-78 through ±1.15792089237316189 * 10+77, precise to
approximately seven significant digits.
The format of a REAL constant includes an integer part, a fractional part suffixed by E,
and an exponent.  Here is an example of a REAL constant value:
356-30.3E-2
Exponent
Fractional part
Integer part
Here are more examples of REAL constant values:
Decimal Value REAL0 0.0E0
2 2.0e0
2 0.2E12 20.0E-1-17.2 -17.2E0-17.2 -1720.0E-2
Storage Allocation
The compiler allocates a doubleword of storage for each REAL simple variable:
REAL num := 2.0E0;
3572.0E0

Simple Variables by Data TypeUsing Simple Variables
same range as REAL numbers, but precise to approximately 17 significant digits.
The format of a REAL(64) constant is the same as for REAL constants, except that the
suffix is L instead of E.  Here are examples of REAL(64) values:
Decimal Value REAL(64)0 0.0L0
2 2.0L0
2 0.2L12 20.0L-1-17.2 -17.2L0-17.2 -1720.0L-2
Storage Allocation
The compiler allocates a quadrupleword of storage for each REAL(64) simple variable:
REAL(64) num := 2718.2818284590452L-3;
358%26770
%52130
%121273
%45401

Simple Variables by Data TypeUsing Simple Variables
–9,223,372,036,854,775,808 through 9,223,372,036,854,775,807, suffixed by F for decimal,octal, or binary numbers or %F for hexadecimal numbers.  For decimal numbers, youcan also specify a fractional part, preceded by a decimal point:
300.667F                        !FIXED decimal number with
```
                                ! fractional part
```
You can initialize a FIXED variable with a character string when you declare the
variable.  You cannot, however, use an assignment statement to assign a characterstring to a FIXED variable.
Fixed-Point Settings (fpoints)
When you declare a FIXED variable, you can specify the implied fixed-point setting
(fpoint ) for values stored in the variable.  The fpoint  is an integer in the range –19
through 19, enclosed in parentheses, following the FIXED keyword.  The default fpoint
is 0.  You can specify a positive or negative fpoint .
Positive  fpoints.   A positive fpoint  specifies the number of decimal places to the right of
the decimal point:
FIXED(3) x := 0.642F;           !Stored as 642; accessed
```
                                ! as 0.642
```
Take care to specify an fpoint  that allows enough decimal places for all the data that
you might assign to the variable.  The system truncates any assignment value thatdoes not fit.  For example, if you declare a FIXED(2) variable and then assign a valuethat has three decimal places, the rightmost digit is lost:
FIXED(2) some_num;              !
fpoint  is 2
some_num := 2.348F;             !Stored as 234; accessed                                ! as 2.34
Negative  fpoints.   A negative fpoint  specifies a number of integer places to the left of the
decimal point.  To store a value, a negative fpoint  truncates digits leftward from the
decimal point in accordance with the fpoint .  When you access the value, zeros replace
the truncated digits:
FIXED(-3) y := 642913F;         !Stored as 642; accessed
```
                                ! as 642000
```
FIXED(*)
If you declare a FIXED( *) simple variable, the value stored in the variable is not scaled.

Simple Variables by Data TypeUsing Simple Variables
The following examples compare the stored form of values having various fpoints:
FIXED(-3) a := 643000F;         !Stored as 000000643
FIXED(-3) b := .643F;           !Stored as 000000000FIXED     c := 643000F;         !Stored as 000643000FIXED     d := .643F;           !Stored as 000000000FIXED(3)  e := 643000F;         !Stored as 643000000FIXED(3)  f := .643F;           !Stored as 000000643
Number Bases
The following initialization examples illustrate different number bases:
FIXED    a := 239840984939873494F;
```
                                !Decimal numberFIXED(3) b := %B1010111010101101010110F;                                !Binary numberFIXED(5) c := %765235512F;      !Octal numberFIXED    d := %H298756F;        !Hexadecimal number
```
Storage Allocation
The compiler allocates a quadrupleword for each FIXED variable.  It allocates
character string and numeric initialization values as follows:
FIXED char := "A";
?
?
?
FIXED num := %H23F;
359%H23F"A" ?
You can initialize a FIXED variable with a character string when you declare the
variable (as shown in the preceding example), but you cannot assign a character stringto such a variable.

Simple Variables by Data TypeUsing Simple Variables
Simple VariablesWhen you declare an UNSIGNED simple variable, you must specify the width , in bits,
of the simple variable.  Specify the width  as a constant expression in the range 1
through 31, enclosed in parentheses, following the UNSIGNED keyword.  Theconstant expression can include LITERALs and DEFINEs:
UNSIGNED(5) bit_var;       !Width of BIT_VAR is 5 bits
You cannot initialize UNSIGNED variables when you declare them.
Storage Allocation
The compiler packs consecutive UNSIGNED simple variables where possible.  That is,
the compiler allocates the first UNSIGNED variable starting on a word boundary, andthen allocates each successive UNSIGNED variable in the remaining bits of the sameword as the preceding variable if:
The variable contains 1 to 16 bits and fits in the same word
The variable contains 17 to 31 bits and fits in the same word plus the next word
If an UNSIGNED variable does not fit in the same word or doubleword, the compiler
starts the variable on a word boundary.
A?
DE
JSTRING a;
UNSIGNED(8) d, e;UNSIGNED(3) f;UNSIGNED(5) g;UNSIGNED(6) h;UNSIGNED(25) j;UNSIGNED(2) k;FG H?
K?