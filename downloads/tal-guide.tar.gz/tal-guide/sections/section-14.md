# Section 14: Compiling Programs

source text such as data declarations, statements, compiler directives, and comments.
The output from a compilation is an executable or bindable object file that consists of
relocatable code and data blocks.  You can bind object files with other object files into anew executable or bindable object file.
This section describes:
The TAL compiler
Compiling source files
Binding object files
Compiling with source lists
Compiling with search lists
Compiling with relocatable data blocks
Compiling with saved global data
Collecting cross-references
The Compiler The TAL compiler process is integrated with two other processes—BINSERV and
SYMSERV.  You can govern all three processes by using compiler directives.
The compiler compiles source code, processes compiler directives, and starts BINSERV
and SYMSERV for additional processing.  The compiler also produces any listings thatresult from the three processes.
Compiler directives let you select compilation options such as:
Using conditional compilation (IF directive)
Saving compiled global declarations for use in later compilations
(SAVEGLOBALS, USEGLOBALS, BEGINCOMPILATION, and SEARCHdirectives)
Checking the syntax without producing an object file (SYNTAX directive)
BINSERV If compilation is successful and the SYNTAX directive is not in effect, BINSERV:
Constructs an object file
Resolves external references by locating pertinent code and data blocks in object
files listed in SEARCH directives and binding them into the object file
Produces binder statistics for inclusion in the compiler listings
You can do further binding by using Binder.
SYMSERV If you compile using the SYMBOLS directive, SYMSERV provides symbol-table
information to the object file for use by the Inspect product.  If you compile using theCROSSREF directive, SYMSERV generates source-level cross-reference information foryour program.

Compiling Source filesCompiling Programs
Source FilesFigure 14-1 shows the source file as input to the compiler and the object file as output
from the compiler.
Figure 14-1.  Compiling a Source File Into an Object File
Source file Object file TAL compiler
The source file can include SOURCE directives that read in code from other sourcefiles.  In effect, you can compile more than one source file into an object file, but theinput to the compiler is always a single source file.  The source file and the code that isread in from other source files by SOURCE directives together compose a compilationunit.
The compiler accepts information you specify in TACL commands (DEFINE, PARAM,
and ASSIGN) if you issue them before you run the compiler.  These commands aredescribed in Appendix E, “File Names and TACL Commands.”
Running the Compiler To run the compiler, issue a compilation command at the TACL prompt.  For example,
you can compile the source file MYSOURCE and have the object code sent to the objectfile MYOBJECT as follows:
TAL /IN mysource/ myobject
Following are options you can specify in the compilation command.
IN File Option
In the compilation command, the IN file is the source file.  You can specify a file name
or a TACL DEFINE as described in Appendix E.  In the preceding example, the IN fileis MYSOURCE.
The IN file can be an edit-format disk file, a terminal, a magnetic tape unit, or a
process.  The compiler reads the file as 132-byte records.
If you omit the IN file and the TACL product is in interactive mode, the default file is
your home terminal.   In noninteractive mode, the default file is the TACL commandfile.  For information about the TACL product, see the TACL Reference Manual .
OUT File Option
The OUT file receives the compiler listings.  The OUT file can be a disk file (not in edit
format), a terminal, a line printer, a spooler location, a magnetic tape unit, or a process.

Compiling Source filesCompiling Programs
blanks through column 132.  You can specify a file name or a TACL DEFINE name.The file must exist before you specify its name for the OUT file.  You can create the fileby using the File Utility Program (FUP).
The following example specifies a file named MYLIST as the OUT file:
TAL /IN mysource, OUT mylist/ myobject
The OUT file is often a spooler location, in this case, $S.#LISTS:
TAL /IN mysource, OUT $s.#lists/ myobject
If you specify OUT with no file, you suppress the listings:
TAL /IN mysource, OUT/ myobject
If you omit OUT and the TACL product is in interactive mode, the listings go to the
home terminal.  In noninteractive mode, the listings go to the current TACL OUT file:
TAL /IN mysource/ myobject
TACL Run Options
You can include one or more TACL run options in the compilation command, such as:
A process name
A CPU number
A priority level
The NOWAIT option
For example, you can specify CPU 3 and NOWAIT when you run the compiler:
TAL /IN mysource, CPU 3, NOWAIT/ myobject
Another run option you can specify is the MEM (memory) option, but the compiler
always uses 64 pages.  For information on all the TACL run options, see the RUNcommand in the TACL Reference Manual .

Compiling Source filesCompiling Programs
The target file is the disk file that is to receive the object code.  You can specify a file
name or a TACL DEFINE name as described in Appendix E.
Previous examples sent the object code to a disk file named MYOBJECT:
TAL /IN mysource/ myobject
If you omit the target file, BINSERV creates a file named OBJECT on your current
default subvolume.  If an existing file has the name OBJECT or the name you specify,BINSERV purges the file before creating the new target file.  If the existing file issecured so BINSERV cannot purge it, BINSERV creates a file named ZZBI nnnn,  where
nnnn  is a different number each time.
Compiler Directives
You can include one or more compiler directives in the compilation command.
Precede the directives with a semicolon and separate them with commas.
You can control the compilation listing.  For example, NOMAP suppresses the symbol
map, and CROSSREF produces cross-reference listings:
TAL /IN mysource/ myobject; NOMAP,CROSSREF
You can specify any directive in the compilation command except the following,
which can appear only in the source file:
ASSERTION
BEGINCOMPILATIONDECSDUMPCONSENDIFIFIFNOTPAGERPSECTIONSOURCE
The following directives can appear only in the compilation command:
EXTENDTALHEAP
SQL with the PAGES optionSYMBOLPAGES

Binding Object FilesCompiling Programs
Returned by the CompilerWhen the compiler compiles a source file, it either completes the compilation normally
or stops abnormally.  It then returns a process-completion code to the TACL productindicating the status of the compilation.  Table 14-1 explains the process-completioncode values.
Table 14-1.  Completion Codes
Code Termination Meaning0 Normal The compiler found no errors or unsuppressed warnings in the source file.
(Warnings suppressed by the NOWARN directive do not count.)  The objectfile is complete and valid (unless a SYNTAX directive suppressed itscreation).
1 Normal The compiler found at least one unsuppressed warning.  (Warnings
suppressed by the NOWARN directive do not count.)  The object file iscomplete and valid (unless a SYNTAX directive suppressed its creation).
2 Normal The compiler found at least one compilation error and did not create an
object file.
3 Abnormal The compiler exhausted an internal resource such as symbol table space or
could not access an external resource such as a file.  The compiler did notcreate an object file.
5 Abnormal The compiler discovered a logic error during internal consistency checking
or one of the compiler’s server processes terminated abnormally.  Thecompiler did not create an object file.
8 Normal The compiler could not use the object file name you specified, so it chose
the name reported in the summary.  The object file is complete and valid.
Binding Object Files You can compile source files into interim object files and then use Binder to bind the
interim object files into a new object file, as shown in Figure 14-2.
Figure 14-2.  Binding Object Files
New object
fileBINDERInterim
object file
Interim
object fileSource fileSource file
TAL compilerTAL compiler

Binding Object FilesCompiling Programs
During a compilation session
After a compilation session
At run time (library binding)
Binding During
CompilationDuring compilation, BINSERV constructs a master search list of object files from
SEARCH directives in the source file.  After a successful compilation, BINSERV bindsinto the new object file any procedures from object files listed in the master search listthat resolve external references.
You can do further binding on the object file produced by BINSERV by using Binder
or the operating system.
Binding After Compilation After compilation, you can bind object files interactively by using Binder as described
in the Binder Manual .  For example, you can build a target file from separate object
files, display the content of object files, reorder target-file code blocks, produceoptional load maps and cross-reference listings, specify a user run-time library, andmodify the content of named global data blocks and code blocks in the target file.
Binding at Run Time You can build a library of procedures to share at run time among applications or to
extend an application’s code space.  At run time, the operating system binds thelibrary file to the program file.  You store the run-time library in a separate file, andthen associate the library file with your object file by using any of the followingmethods:
A LIBRARY directive in the source file
The Binder SET LIBRARY command, described in the Binder Manual
The TACL RUN LIB command, described in the TACL Reference Manual
The LIBRARY directive lets you specify a user library to search before searching the
system library for satisfying external references.  LIBRARY can appear anywhere onthe compilation command or in the source code:
!Lots of code
?LIBRARY mylib!More code

Using Directives in the Source FileCompiling Programs
in the Source FileCompiler directives let you:
Specify input source code
Control listings, generate the object code, and build the object file
Perform conditional compilation
A directive line in your source file can contain any number of compiler directives.  You
must start each new directive line and any continuation lines with a question mark (?)in column 1.
The following directive line contains one directive:
?NOLIST
The following directive lines contain multiple directives:
?NOLIST, NOCODE, INSPECT, SYMBOLS, NOMAP, NOLMAP, GMAP
?CROSSREF, INNERLIST
The following directive line shows a continuation line for the argument list of a
directive:
?SEARCH (file1, file2, file3, file4,
?file5, file6)
If the list of arguments in a directive continues on subsequent lines, you must specify
the leading parenthesis of the argument list on the same line as the directive name:
?NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (
? PROCESS_GETINFO_,? PROCESS_STOP_)

Using Directive StacksCompiling Programs
directive settings.  Directives that have directive stacks are:
CHECK
CODEDEFEXPANDICODEINNERLISTINT32INDEXLISTMAP
Each directive stack is 32 levels deep.  The compiler initially sets all levels of each
directive stack to the off state.
Pushing Directive Settings When you push the current directive setting onto a directive stack, the current
directive setting of the source file remains unchanged until you specify a new directivesetting.
To push a directive setting onto a directive stack, specify the directive name prefixed
by PUSH.  For example, to push the current setting of the LIST directive onto the LISTdirective stack, specify PUSHLIST.  The other values in the directive stack move downone level.  If a value is pushed off the bottom of the directive stack, that value is lost.
Popping Directive Settings To restore the top value from a directive stack as the current setting of the source file,
specify the directive name prefixed by POP.  For example, to restore the top value offthe LIST directive stack, specify POPLIST.  The remaining values in the directive stackmove up one level, and the vacated level at the bottom of the stack is set to the offstate.
Directive Stack Example In the following example:
1. LIST is the default setting for the source file.2. PUSHLIST pushes the LIST directive setting onto the LIST directive stack.3. NOLIST suppresses listing of sourced-in procedures.4. POPLIST pops the top value off the LIST directive stack and restores LIST as the
current setting for the remainder of the source file:
!LIST is the default setting for the source file?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (
? PROCESS_GETINFO_, FILE_OPEN_, WRITEREADX, READX)
?POPLIST

File Names as Directive ArgumentsCompiling Programs
Directive ArgumentsThe following directives accept names of disk files as arguments:
ERRORFILE
LIBRARYSAVEGLOBALSSEARCHSOURCEUSEGLOBALS
A disk file name   consists of four parts, with each part separated by periods:
A D-series node name or a C-series system name
A volume name
A subvolume name
A file ID
Here is an example of a file name:
\mynode.$myvol.mysubvol.myfileid
Partial File Names You can omit any part of the file name except the file ID.  If you specify a partial file
name, the compiler uses the current default node (system), volume, and subvolume asneeded.
For the SEARCH, SOURCE, and USEGLOBALS directives, the compiler can also use
the  node (system), volume, and subvolume specified in TACL ASSIGN SSV (SearchSubVolume) commands.
Logical File Names The following directives accept a logical file name in place of a file name:
ERRORFILE
SAVEGLOBALSSEARCHSOURCEUSEGLOBALS
A logical file name is a TACL DEFINE name or a TACL ASSIGN name.Appendix E gives more information on specifying disk file names, including those
specified in TACL  DEFINE and ASSIGN commands.

Compiling With Source DirectivesCompiling Programs
SOURCE DirectivesYou can specify a SOURCE directive in a source file to read in source code from other
source files.  In the SOURCE directive, specify the source file name, followed by anoptional list of one or more section names enclosed in parentheses.  If you omit the listof section names, the compiler reads in the entire file.
Section Names If you specify SOURCE with no section names, the compiler processes the specified
source file until an end of file occurs.  The compiler treats any SECTION directives inthe source file as comments.
If you specify SOURCE with section names, the compiler processes the source file until
it reads all the specified sections.  A section begins with a SECTION directive and endswith another SECTION directive or the end of the file, whichever comes first.
The compiler reads the sections in order of appearance in the source file, not in the
order specified in the SOURCE directive.  If you want the compiler to read sections ina particular order, use a separate SOURCE directive for each section and place theSOURCE directives in the desired order.
Nesting Levels You can nest SOURCE directives to a maximum of seven levels, not counting the
original outermost source file.  For example, the deepest nesting allowed is as follows:
1. The MAIN file F sources in file F1.
2. File F1 sources in file F2.3. File F2 sources in file F3.4. File F3 sources in file F4.5. File F4 sources in file F5.6. File F5 sources in file F6.7. File F6 sources in file F7.
Effect of Other Directives If LIST and NOSUPPRESS are in effect after a SOURCE directive completes execution,
the compiler prints a line identifying the source file to which it reverts and beginsreading at the line following the SOURCE directive.
You can precede SOURCE with NOLIST to suppress the listings of procedures to be
read in.  Place NOLIST and SOURCE on the same line, because the line containingNOLIST is not suppressed:
?PUSHLIST, NOLIST, SOURCE $src.current.routines
!Suppress listings; read in external declarations of routines?POPLIST
If USEGLOBALS is in effect, the compiler ignores all SOURCE directives until it
encounters BEGINCOMPILATION.  For more information on how these directivesinteract, see “Compiling With Saved Global Data” later in this section.

Compiling With Source DirectivesCompiling Programs
Procedure DeclarationsYou can use SOURCE directives to read in external declarations of system procedures
from the EXTDECS files.  In these files, the procedure name and the correspondingsection name are the same.  EXTDECS0 contains the current release version of systemprocedures, for example, the D20 version.
In the following D-series example, a SOURCE directive specifies the current version of
system procedures.  A NOLIST directive suppresses the listings for the systemprocedures.  Place NOLIST and SOURCE on the same line, because the line containingthe NOLIST directive is not suppressed:
?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS0 (
?   PROCESS_DEBUG_, PROCESS_STOP_)!Suppress listings; read in external declarations of! current system procedures?POPLIST
A D-series procedure in the same source file can then call the procedures listed in the
preceding SOURCE directive:
PROC a MAIN;
BEGIN  INT x, y, z, error;  !Code for manipulating x, y, and z  If x = 5 THEN CALL PROCESS_STOP_;  CALL PROCESS_DEBUG_;          !Call procedures listed  END;                          ! in SOURCE directive
To convert the two preceding examples to C-series examples, change the procedure
names PROCESS_STOP_ and PROCESS_DEBUG_ to STOP and DEBUG, respectively.

Compiling With Search ListsCompiling Programs
Search ListsYou can share data and procedures between object files by specifying search lists of
object file names for resolving unsatisfied external references and validating parameterlists at the end of the compilation session.
To create search lists of object files, use the SEARCH directive:
?SEARCH (file1, file2, file3)
Creating the
Master Search ListThe compiler sends the search list from each SEARCH directive to BINSERV, the
compile-time binder process.  BINSERV appends the file names, in the order specified,to the master search list for the current source file.
For example, if you specify the following SEARCH directives, the master search list is
in the order FILE2, FILE1, FILE3, and FILE4:
?SEARCH (file2, file1)
!Lots of code?SEARCH (file3, file4)
Clearing the
Master Search ListYou can clear the current master search list at any point in the source file.  BINSERV
uses only the files that remain on the search list at the end of compilation to resolveexternal references.
To clear the master search list at any point, specify a SEARCH directive with no file
names.  For example, suppose you specify two search lists that comprise the mastersearch list.  You can then clear the master search list as follows:
?SEARCH (file1, file2)         !Specify search list?SEARCH (file3)                !Add FILE3 to search list?SEARCH                        !Clear master search list
```
                               ! of FILE1, FILE2, FILE3!Lots of code?SEARCH (file4, file5)         !Specify new search list;                               ! master search list is                               ! now FILE4 and FILE5
```

Compiling With Search ListsCompiling Programs
Master Search ListBINSERV searches the object files in the order in which they appear in the master
search list.   If a procedure or entry-point name that resolves an external referenceappears in more than one file, BINSERV uses only the first occurrence.  Thus, the orderin which you specify the files could be important.
Binding the
Master Search ListIf the compilation is successful, BINSERV binds the new object file by using
procedures from object files in the master search list to resolve any unsatisfiedreferences in your program.  If procedures from object files in the search list containreferences to other external procedures or to data blocks, BINSERV tries to resolvethose from object files in the master search list.
This example shows SEARCH directives for external procedures:
?SEARCH partx            !Object file containing PROC_X
PROC proc_x;  EXTERNAL;
?SEARCH party            !Object file containing PROC_Y
PROC proc_y;  EXTERNAL;
PROC proc_z;
BEGIN  CALL proc_x;  CALL proc_y;  END;
Retrieving Global
InitializationsYou can use SEARCH to retrieve global initialization values and template structure
declarations as described in “Compiling With Saved Global Data” later in this section.

Compiling With Relocatable Data BlocksCompiling Programs
Relocatable Data
BlocksWhen you compile modules of a program separately or bind TAL code with code
written in other languages, the binding process might relocate some of your globaldata.  All global data to be shared with compilation units written in other languagesmust be relocatable.
Declaring Relocatable
Global DataYou can declare blocked and unblocked relocatable global data (variables, LITERALs,
and DEFINEs).
Blocked global data declarations are those appearing within BLOCK declarations.
BLOCK declarations let you group global data declarations into named or privateblocks.  Named blocks are shareable among all compilation units in a program.  Theprivate block is private to the current compilation unit.  If you include a BLOCKdeclaration in a compilation unit, you must assign an identifier to the compilation unitby using a NAME declaration.
Unblocked global data declarations are those appearing outside a BLOCK declaration.
Such declarations are also relocatable and shareable among all compilation units in aprogram.
If present in a compilation unit, global declarations must appear in the following
order:
1. NAME declaration
2. Unblocked global data declarations3. BLOCK declarations4. PROC declarations
Naming Compilation units
To assign an identifier to a compilation unit, specify the NAME declaration as the first
declaration in the compilation unit.  (If no BLOCK declaration appears in thecompilation unit, you need not include the NAME declaration.)   In the NAMEdeclaration, specify an identifier that is unique among all BLOCK and NAMEdeclarations in the target file.  The following example assigns the identifierINPUT_MODULE to the current compilation unit.
NAME input_module;         !Name the compilation unit
Declaring Named Data Blocks
A named data block is a global data block that is shareable among all compilation
units in a program.  You can include any number of named data blocks in acompilation unit.  To declare a named data block, specify an identifier in the BLOCKdeclaration that is unique among all BLOCK and NAME declarations in the target file.The following declaration assigns the identifier GLOBALS to the named data block:
BLOCK globals;             !Declare named data block
INT .vol_array[0:7];     !Declare global data  INT .out_array[0:34];  DEFINE xaddr = INT(32)#;  END BLOCK;

Compiling With Relocatable Data BlocksCompiling Programs
name as the data block.  Modules written in TAL can share global variables withmodules written in C by placing each shared variable in its own block and giving thevariable and the block the same name.  Here is an example of a variable named thesame as the data block:
BLOCK c_var;
INT c_var;  END BLOCK;
Declaring Private Data Blocks
A private data block is a global data block that is shareable only among the procedures
within a compilation unit.  You can include only one private data block in acompilation unit.  The private data block inherits the identifier you specify in theNAME declaration.  To declare a private global data block, specify the PRIVATEoption of the BLOCK declaration:
BLOCK PRIVATE;             !Declare private global data block
INT term_num;            !Declare global data  LITERAL msg_buf = 79;  END BLOCK;
Specifying the Data Block Location
You can use the AT and BELOW clauses to control where Binder locates a block.  For
example:
AT (0)—to detect the use of uninitialized pointers
BELOW (64)]—to use XX (extended, indexed) machine instructions
BELOW (256)—to use directly addressed global data
For example, you can specify where to allocate data blocks as follows:
BLOCK ext_indexed_stuff BELOW (64);     !Specify location
INT .EXT symbol_table[0:32760];  INT .EXT error_table[0:16380];  END BLOCK;
The following limitations apply to the AT and BELOW clauses:
Using the AT[0] option might cause conflicts if you:
Share data with compilation units written in other languages
Run your program in the CRE
Use 0D as nil for pointers
Some of the AT and BELOW clauses are not portable to future software platforms.

Compiling With Relocatable Data BlocksCompiling Programs
Place all unblocked global declarations (those not contained in BLOCK declarations)
before the first BLOCK declaration.  Unblocked declarations are relocatable andshareable among all compilation units in a program.
Here is an example of unblocked data declarations:
INT a;
INT .b[0:9];  INT .EXT c[0:14];  LITERAL limit = 32;
The compiler places unblocked data declarations in implicit primary data blocks.  As
of the D20 release, the compiler creates implicit data blocks as follows:
A data block named #GLOBAL for all unblocked declarations except templatestructures.  A compilation unit can have only one #GLOBAL block.
A data block for each unblocked template structure declaration.  The data blockfor a given template structure is given the template name prefixed with anampersand (&).
You can bind object files compiled with and without template blocks with no loss of
information.  You can use Binder commands to replace the #GLOBAL and templateblocks in the target file.
Referencing Declarations
A referral structure and the structure layout to which it refers can appear in different
data blocks.  The structure layout must appear first.
In all other cases, a data declaration and any data to which it refers must appear in the
same data block.  The following declarations, for example, must appear in the samedata block:
INT var;                !Declare VAR
INT .ptr := @var;       !Declare PTR by referring to VAR
Allocating Global
Data BlocksWhen you compile a program, the compiler constructs relocatable blocks of code and
data that are bound into the object file.  The compiler:
Allocates each read-only array in its own data block in the user code segment inwhich the array is referenced
Allocates all other variables in relocatable global data blocks in the user datasegment (except LITERALs and DEFINEs, which require no storage space)
In the user data segment, the compiler creates and names global data blocks that are
primary, secondary, or extended.

Compiling With Relocatable Data BlocksCompiling Programs
The compiler creates and names primary data blocks as follows:
Primary Block Compiler-Assigned NameImplicit #GLOBAL
Implicit & template-name   (for each unblocked template structure)
Named The identifier specified in the BLOCK declarationPrivate The identifier specified in the NAME declaration
The compiler allocates the following variables in primary data blocks:
Directly addressed variables
Standard or extended pointers (including those you declare and those the
compiler provides when you declare indirect arrays and structures)
The compiler associates the symbol information for the allocated variables with that
data block.   The compiler also associates the symbol information for any LITERALs,DEFINEs, or read-only arrays declared in that data block, but allocates 0 words ofstorage for such declarations.  If a global data block contains only LITERALs,DEFINEs, or read-only arrays, the compiler creates a primary data block andassociates their symbol information with the data block, but allocates 0 words ofstorage for the data block.
Size of Combined Primary Blocks.   After a binding session, the combined primary global
data blocks in the resulting object file must not exceed 256 words.
Secondary Relocatable Data Blocks
The compiler creates and names secondary data blocks as follows:
Secondary Block Compiler-Assigned NameImplicit .#GLOBAL
Named The identifier specified in the BLOCK declaration, prefixed with a dot ( .)
Private The identifier specified in the NAME declaration, prefixed with a dot ( .)
Secondary data blocks contain the data of standard indirect arrays and standard
indirect structures.
Extended Relocatable Data Blocks
The compiler names the extended data blocks as follows:
Extended Block Compiler-Assigned NameImplicit $#GLOBAL
Named The identifier specified in the BLOCK declaration, prefixed with $
Private The identifier specified in the NAME declaration, prefixed with $
Extended data blocks contain the data of extended indirect arrays and extended
indirect structures.

Compiling With Relocatable Data BlocksCompiling Programs
Table 14-2 shows the primary, secondary, and extended data blocks the compiler
creates from the example global data declarations, including the names (shown inboldface) that the compiler gives them.
Table 14-2.  Data Blocks Created by the Compiler
```
                                               Data Blocks Created by the TAL Compiler
```
Example Declaration Primary Data Block Secondary Data Block Extended Data Block
Implicit
block INT a;
INT .b[0:9];INT .EXT c[0:14];INT(32) .d;LITERAL lmt = 32;#GLOBAL contains:
Variable A (1 word)Pointer for B (1 word)Pointer for C (2 words)Simple pointer D (1 word)LITERAL (0 words).#GLOBAL  contains:
Data for B (10 words)$#GLOBAL  contains:
Data for C (15 words)
Named
blockBLOCK myglobals;
INT g; INT .h[0:9]; INT .EXT k[0:14]; LITERAL one = 1; END BLOCK;MYGLOBALS  contains:
Variable I (1 word)Pointer for J (1 word)Pointer for K (2 words)LITERAL (0 words).MYGLOBALS
contains:
Data for J (10 words)$MYGLOBALS  contains:
Data for K (15 words)
Private
blockNAME mysource;
BLOCK PRIVATE;
INT x; INT .y[0:9]; INT .EXT z[0:14]; DEFINE xaddr =   INT(32)#; INT ro_array = 'P'   := [0,1]; END BLOCK;MYSOURCE  contains:
Variable X (1 word)Pointer for Y (1 word)Pointer for Z (2 words)DEFINE (0 words)
Read-only array (0 words).MYSOURCE  contains:
Data for Y (10 words)$MYSOURCE contains:
Data for Z (15 words)
Address Assignments
The compiler assigns each direct variable and each pointer an offset from the
beginning of the encompassing global data block.  Within the data block, it allocatesstorage for each data declaration according to its data type and size.
Binder uses the address of the data block and the offset within the block to construct
addresses for indirect data in the secondary and extended storage areas.

Compiling With Relocatable Data BlocksCompiling Programs
Figure 14-3 shows the global storage allocation resulting from binding object files that
contain BLOCK declarations.  You can rearrange the primary block by using Bindercommands.  Secondary blocks must always follow the primary blocks.
Figure 14-3.  Allocating Global Data Blocks
Global
primary
areaUser data segment
Global
secondary
area#GLOBAL
Named blocks
Private block
.#GLOBAL
Named blocks
Private block$#GLOBAL
Named blocks
Private blockExtended data segment
Global primary area

Compiling With Relocatable Data BlocksCompiling Programs
recommended that you declare all shareable global data in one source file.  You canthen share that global data block with other source files as follows:
1. In the source file that declares the data block, specify the SECTION directive at the
beginning of the data block to assign a section name to the data block.  TheSECTION directive remains in effect until another SECTION directive or the endof the source file occurs:
NAME calc_unit;?SECTION unblocked_globals         !Name first section
LITERAL true   = -1,             !Implicit data block          false  =  0;  STRING read_only_array = 'P' := [ " ","COBOL",                          "FORTRAN", "PASCAL", "TAL"];
?SECTION default                   !Name second section
BLOCK default_vol;               !Declare named block    INT .vol_array [0:7],        .out_array [0:34];    END BLOCK;
?SECTION msglits                   !Name third section
BLOCK msg_literals;              !Declare named block    LITERAL      msg_eof   = 0,      msg_open  = 1,      msg_read  = 2;      END BLOCK;                   !End msglits section
?SECTION end_of_data_sections
2. In each source file that needs to include the sections, specify the file name and the
section names in a SOURCE directive:
NAME input_file;?SOURCE calcsrc(unblocked_globals) !Specify implicit block
?SOURCE calcsrc(default)           !Specify named block
3. If you then change any declaration within a data block that has a section name,
you must recompile all source files that include SOURCE directives listing thechanged data block.

Compiling With Relocatable Data BlocksCompiling Programs
Relocatable DataThe RELOCATE and INHIBITXX directives help you make sure that your global data
is relocatable.  These directives do not affect local and sublocal variables.
RELOCATE Directive
RELOCATE instructs the compiler and BINSERV to issue warnings if references to
nonrelocatable data occur.  RELOCATE can appear anywhere on the compilationcommand or in the source file.  It is effective for the source code that follows it.
The following RELOCATE example shows base-address equivalencing, which declares
nonrelocatable data because it locates variables relative to the global, local, or sublocalbase address.
?RELOCATE
INT i = 'G' + 22;               !Nonrelocatable global data;                                ! base-address equivalencing!Some codei := 25;                        !Compiler emits warning
For more information on base-address equivalencing and the RELOCATE directive,
see the TAL Reference Manual.
INHIBITXX Directive
INHIBITXX suppresses efficient addressing for extended pointers, extended indirect
array elements, and extended indirect structure items located within the first 64 wordsof primary global storage.
INHIBITXX has no effect on data declared in BLOCK declarations with the AT (0) or
BELOW (64) option.  The compiler always generates efficient code for such BLOCKdeclarations regardless of INHIBITXX.
If the default NOINHIBITXX is in effect, the compiler produces efficient addressing
that might become incorrect if binding relocates extended pointers, extended indirectarray elements, or extended indirect structure items outside the first 64 words.
The INT32INDEX directive overrides INHIBITXX or NOINHIBITXX.

Compiling With Relocatable Data BlocksCompiling Programs
which it applies.  The specified directive then applies to those declarations throughoutthe compilation.  The following example shows how NOINHIBITXX generatesefficient addressing, while INHIBITXX suppresses efficient addressing:
!Default NOINHIBITXX in effect; assign NOINHIBITXX
! attribute to subsequent declaration.
STRUCT .EXT xstruct[0:9]; !XSTRUCT has NOINHIBITXX
BEGIN                   ! attribute.  STRING array[0:9];  END;
INT index;
STRING var;?INHIBITXX                !Assign INHIBITXX attribute to                          ! subsequent declaration.STRING .EXT xstruct2 (xstruct);                          !XSTRUCT2 has INHIBITXX attribute.                          !Preceding declarations are                          ! allocated in #GLOBAL and                          ! $#GLOBAL.
PROC my_proc MAIN;
BEGIN  @xstruct2 := @xstruct;  var := xstruct[index].array[0];                          !Generate efficient addressing                          ! because XSTRUCT has NOINHIBITXX                          ! attribute, but if Binder                          ! relocates #GLOBAL beyond G[63],                          ! the addressing is incorrect.
var := xstruct2[index].array[0];
```
                          !Generate less efficient addressing                          ! because XSTRUCT2 has INHIBITXX                          ! attribute; the addressing is                          ! correct even if Binder relocatesEND;                      ! #GLOBAL.
```

Compiling With Saved Global DataCompiling Programs
Saved Global DataDuring program development or maintenance, you often need to change procedural
code or data without changing the global declarations.  You can save the global data ina file during a compilation session and then use the saved global data during asubsequent compilation.  You can shorten the compile time by not compiling globaldeclarations each time.
Saving Global Data To save the compiled global data declarations, use the SAVEGLOBALS directive.
SAVEGLOBALS causes the data declarations to be stored as follows:
Identifiers and data characteristics (including data type and kind of variable) in aglobal declarations file
Initialization values (including addresses and constant lists) in the object file
Note Whenever you switch to a different version of the compiler, you must create a new global declarations file
by using SAVEGLOBALS.  Otherwise, an error message occurs when you compile to retrieve the savedglobals.  Each version of the compiler expects declarations in a different format.  (C30, D10, and D20, forexample, are different versions of the compiler.)
Retrieving Global Data After a SAVEGLOBALS compilation completes successfully, you can retrieve the
global data declarations and initializations in a subsequent USEGLOBALS compilationby specifying the following directives:
Directive for Retrieving
Global Data Effect
USEGLOBALS Retrieves global data declarations; suppresses compilation of text lines
and SOURCE directives (but not other directives) untilBEGINCOMPILATION appears
SEARCH Retrieves global initialization values and template structures
BEGINCOMPILATION Begins compilation of text lines and SOURCE directives
Specify BEGINCOMPILATION between the last global data declaration or SEARCH
directive and the first procedure declaration, including EXTERNAL or FORWARDdeclarations.  (You must recompile EXTERNAL or FORWARD procedure declarationsin the USEGLOBALS compilation.  SAVEGLOBALS does not save such declarations.)
Note If you specify SAVEGLOBALS and USEGLOBALS in the same compilation, the compiler issues an error
message and uses only the first of the two directives.
If you use CROSSREF with USEGLOBALS, the compiler does not pass Inspect and CROSSREF
symbols information for global identifiers to SYMSERV.

Compiling With Saved Global DataCompiling Programs
Compilation SessionThe following session shows how you can save and retrieve global data.  It also shows
how you can check the syntax of global data declarations and how to save and retrievesuch declarations.
Creating the Source File
Using an editor, you can create a source file, such as MYPROG, that includes
BEGINCOMPILATION and USEGLOBALS.
!Source file MYPROG!If USEGLOBALS is active, the compiler ignores text lines
! and SOURCE directives (but not other directives) until! BEGINCOMPILATION appears.
?SOURCE globfile
?SOURCE glbfile1 (section1, section2)?SOURCE moreglbs  INT ignore_me1;  INT ignore_me2;
?BEGINCOMPILATION             !Compile code that follows
?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS?POPLIST
PROC my_first_proc;
BEGIN  !Lots of code  END;
PROC my_last_proc;
BEGIN  !Lots of code  END;
Saving the Global Data
The following compilation command compiles MYPROG and produces object file
MYOBJ.  The SAVEGLOBALS directive saves global declarations in file TALSYM andthe global initializations in object file MYOBJ:
TAL /IN myprog/ myobj; SAVEGLOBALS talsym
Retrieving the Saved Global Data
The following compilation command recompiles MYPROG and produces object file
NEWOBJ.  The USEGLOBALS directive retrieves the saved global declarations fromfile TALSYM.  The SEARCH directive retrieves the global initializations from MYOBJ:
TAL /IN myprog/ newobj; USEGLOBALS talsym, SEARCH myobj

Compiling With Saved Global DataCompiling Programs
The following compilation command compiles source file MYPROG but produces no
object file.  The SAVEGLOBALS directive saves global declarations in file TALSYM.The SYNTAX directive checks the syntax of the global declarations:
TAL /IN myprog/; SAVEGLOBALS talsym, SYNTAX
You can then recompile and retrieve the saved global declarations (but not the saved
global initializations, because no object file was produced in the precedingcompilation):
TAL /IN myprog/; USEGLOBALS talsym, SYNTAX
Effects of Other Directives When you use the following directives in the SAVEGLOBALS compilation, they affect
subsequent USEGLOBALS compilations as follows:
Directive in
SAVEGLOBALSCompilation Effect in Subsequent USEGLOBALS Compilations
SYNTAX Negates the need for using SEARCH in the USEGLOBALS compilation because
no object file was produced by the SAVEGLOBALS compilation
INHIBITXX Continues to inhibit generation of extended indexed instructions for extended
pointers located in the first 64 words of primary global area
INT32INDEX Continues to generate INT(32) indexes from INT indexesPRINTSYM Continues to print symbols in the listingSYMBOLS Continues to make symbols available for all data blocks that had symbols during
the SAVEGLOBALS compilation
These directives set the corresponding attribute in ensuing variable declarations.  The
compiler saves such information in the SAVEGLOBALS object file along with all theother information it saves about each variable.

Compiling With Cross-ReferencesCompiling Programs
Cross-ReferencesThe CROSSREF directive either:
Collects source-level cross-reference information produced during compilation
Selects the identifier classes for which you want to collect cross-references
The default is NOCROSSREF.You can specify CROSSREF or NOCROSSREF in the compilation command or any
number of times anywhere in the source file.
Note If you use CROSSREF with USEGLOBALS, the compiler does not pass Inspect and cross-reference
symbols information for global identifiers to SYMSERV.
Selecting Classes You can specify that the compiler collects cross-reference information for one or more
of the following classes:
Class DescriptionBLOCKS Named and private data blocks
DEFINES Named text
LABELS Statement labelsLITERALS Named constantsPROCEDURES ProceduresPROCPARAMS Procedures that are formal parametersSUBPROCS SubproceduresTEMPLATES Template structuresUNREF Unreferenced identifiersVARIABLES Simple variables, arrays, definition structures, referral
structures, pointers, and equivalenced variables
The default class list includes all classes except UNREF.  The CONSTANTS class is
available in the stand-alone Crossref product, but not in the CROSSREF directive.
You can make changes to the current class list at any point in the compilation unit.
When you specify parameters, CROSSREF and NOCROSSREF only modifies the classlist.  To start (or stop) the collection of cross-references, you must specify CROSSREF(or NOCROSSREF) without parameters.  The compiler collects cross-references for theclass list in effect at the end of the compilation.

Compiling With Cross-ReferencesCompiling Programs
than one class, enclose the list in parentheses.
To add classes to the current list, specify CROSSREF and list the classes you wantto add.  The following example adds the one missing class to the default list:
?CROSSREF UNREF
To delete classes from the current list, specify NOCROSSREF and list the classes
you want to delete.  The following example retains the procedure, subprocedure,block, and template classes by deleting all other classes from the default list:
?NOCROSSREF (DEFINES,LABELS,LITERALS,PROCPARAMS,VARIABLES)
To add and delete classes, specify a CROSSREF that adds classes and a
NOCROSSREF that deletes classes:
?CROSSREF UNREF, NOCROSSREF LITERALS
Collecting
Cross-ReferencesYou can collect cross-reference information for individual procedures or data blocks.
When a CROSSREF without parameters appears, it starts collection of cross-referencesat the beginning of a procedure or data block and remains in effect until aNOCROSSREF without parameter appears.  CROSSREF and NOCROSSREF withoutparameters do not modify the class list.
For each class in effect at the end of the compilation, CROSSREF without parameters
collects the following information:
Identifier qualifiers—structure, subprocedure, and procedure identifiers
Compiler attributes—class and type modifiers
The name of the host source file
The type of reference—definition, invocation, parameter, write, or other
To start collecting cross-references, specify CROSSREF without parameters.  To stop
collecting cross-references, specify NOCROSSREF without parameters.  For example,you can stop the collection for the private data block, and then start the collection for aprocedure:
?CROSSREF         !Start collecting cross-references
NAME test;  INT i;
?NOCROSSREF       !Stop cross-references for BLOCK
BLOCK PRIVATE;  INT j;  END BLOCK;
?CROSSREF         !Start cross-references for procedure
PROC p MAIN;  BEGIN  !Lots of code  END;

Compiling With Cross-ReferencesCompiling Programs
?CROSSREF, CROSSREF UNREF, NOCROSSREF VARIABLES
```
                  !Start collecting cross-references and                  ! change the class listNAME test;  INT i;
```
?NOCROSSREF       !Stop cross-references for BLOCK
BLOCK PRIVATE;  INT j;  END BLOCK;
?CROSSREF, CROSSREF VARIABLES
```
                  !Start cross-references for procedure and                  ! add a class to the class listPROC p MAIN;  BEGIN  !Lots of code  END;
```
For other cross-reference options, use the stand-alone Crossref product as described in
the Crossref Manual .  For example, stand-alone Crossref can collect cross-references
from source files written in one or more languages.
Printing Cross-References To print the collected cross-references in the compiler listing, LIST and NOSUPPRESS
(the defaults) must be in effect at the end of compilation.  CROSSREF collects cross-references even if NOLIST is in effect for all or part of the compilation.  In the compilerlisting, the cross-reference list follows the global map and precedes the load maps.
In the following example, SUPPRESS suppresses part of the cross-reference listing, and
NOSUPPRESS resumes the listing for subsequent code:
!Default LIST and NOSUPPRESS are in effect.
?CROSSREF            !Collect (and list) cross-referencesPROC p;  BEGIN  !Some code  END;
?SUPPRESS            !Stop listing cross-references
PROC q;  BEGIN  !More code  END;?NOSUPPRESS          !Resume listing cross-references!More code!LIST and NOSUPPRESS are in effect at the end of compilation.

Compiling With Cross-ReferencesCompiling Programs
or listing of cross-references on and off:
!Default LIST and NOSUPPRESS are in effect?CROSSREF, CROSSREF UNREF, NOCROSSREF VARIABLES
```
                   !Collect (and list) cross-referencesNAME test;  INT i;
```
?NOCROSSREF        !Stop collecting cross-references
BLOCK PRIVATE;  INT j;  END BLOCK;
?CROSSREF, CROSSREF VARIABLES
```
                   !Resume collecting (and listing)                   ! cross-referencesPROC p MAIN;  BEGIN  !Lots of code  END;
```
?SUPPRESS          !Stop listing cross-references
PROC q;  BEGIN  !More code  END;?NOSUPPRESS        !Resume listing cross-references!Lots more code!LIST and NOSUPPRESS are in effect at the end of! compilation.