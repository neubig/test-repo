# Section 2: Getting Started

basic commands for developing and running a program.
Sample Source File The sample program adds two numbers together.  The source code for the sampleprogram is in a source file named MYSRC.  Figure 2-1 shows the content of the samplesource file.
Figure 2-1.  Sample Source File
!This is a source file named MYSRC.
?SOURCE $SYSTEM.SYSTEM.EXTDECS (INITIALIZER)
```
                              !Include system procedure
```
PROC myproc MAIN;             !Declare procedure MYPROC
BEGIN  INT var1;                   !Declare variables  INT var2;  INT total;
CALL initializer;           !Handle start-up message
var1 := 5;                  !Assign value to VAR1  var2 := 10;                 !Assign value to VAR2  total := var1 + var2;       !Assign sum to TOTAL  END;                        !End MYPROC
This section describes how to:
1. Create the source file
2. Compile the source file into an object file3. Run the object file

Creating Source FilesGetting Started
declarations, statements, compiler directives, and comments.
You can use a text editor to create a file and to type source code into the file.  The
PS Text Edit Reference Manual  and the Edit User’s Guide and Reference Manual  describe
how to use an editor.
When you enter the source code into the source file, you can use lowercase or
uppercase letters.  The compiler does not distinguish between lowercase anduppercase.
The sample source file shows keywords in uppercase and identifiers in lowercase to
make it easy to see which is which.  Keywords are terms that have predefinedmeanings to the compiler.  Identifiers are names you supply.
The sample source file contains the following kinds of items:
Compiler directives
System procedures
Procedures
Data declarations
Statements
Comments
Compiler Directives Compiler directives let you select compilation options that control various aspects of
the compilation.  For example, you can use compiler directives to:
Include source code from other source files
Control the listing
Perform conditional compilation
Check the syntax without generating object code
You can include compiler directives in the source file or in the command to run the
compiler.  In the source file, you specify compiler directives in directive lines.  Eachdirective line begins with a question mark in the leftmost column.
In the sample source file, the SOURCE directive reads the INITIALIZER system
procedure, which handles the startup message (a system message sent to a processwhen it starts).

Creating Source FilesGetting Started
system procedures are located in the EXTDECS files.  You can, for instance, use systemprocedures when your program needs to:
Perform input/output operations
Manage processes
Communicate with other processes
Interface with the command interpreter (TACL)
Interface with terminals, printers, magnetic tapes, and card readers
Send operator messages
Provide fault tolerance
Handle traps
Appendixes A and B contain examples that include input/output and other system
procedures.  For information on how to use the system procedures, however, see theGuardian Programmer’s Guide  and the Guardian Procedure Calls Reference Manual .
The sample source file includes one system procedure, INITIALIZER, which processes
the startup message.
Procedures Procedures contain the executable parts of a TAL program.  Procedures can contain
data declarations, statements, and subprocedures.
A TAL program consists of one or more procedures.  The program must include a
MAIN procedure (a procedure that has the MAIN attribute).  The MAIN procedureexecutes first when you run the program.
The sample source file consists of one procedure, named MYPROC.  This procedure
has the MAIN attribute and contains data declarations and statements.
Data Declarations Data declarations associate identifiers with memory locations and allocate storage
space for variables.  Variables contain data that can change during program execution.You can initialize variables with values when you declare the variables, or you canassign values to them later in assignment statements.
The sample source file includes data declarations for variables named VAR1, VAR2,
and TOTAL.  These variables are not initialized when they are declared;  they areassigned values later in the source file.

Compiling Source FilesGetting Started
are executable.  For example, you use statements to:
Call procedures
Return from called procedures
Assign values to variables
Copy data from one location to another
Scan data for a character
Select statements to execute based on a condition
The sample source file includes statements that call a procedure and assign values to
variables.  The following statements appear in the sample source file:
A CALL statement that calls the INITIALIZER system procedure
An assignment statement that assigns a value to VAR1
An assignment statement that assigns a value to VAR2
An assignment statement that assigns the sum of VAR1 and VAR2 to TOTAL
Comments Comments are notes you include in the source file to explain the source code.  For
example, you can use a comment to explain a construct or describe an operation.Comments in a source file can either:
Start with two hyphens ( --) and terminate with the end of the line
Start with an exclamation point (!) and terminate with either another exclamation
point or the end of the line
In the sample source file, each comment begins with an exclamation point  and ends
with the end of the line.
Compiling
Source FilesWhen you compile a source file, the compiler produces an object file and a compiler
listing.  The compiler listing consists of source code and summary information.  Youcan execute the object file if it contains a procedure that has the MAIN attribute.
To compile the sample source file MYSRC, issue the following compilation command
at the TACL prompt:
TAL /IN mysrc/ myprog
The preceding command sends the compiler listing to your terminal and the object
code to an object file named MYPROG.  You can include compiler directives andadditional run options in the compilation command.  Section 14, “CompilingPrograms,” gives an overview of run options and compiler directives.

Running ProgramsGetting Started
by issuing a TACL RUN command.
To run the sample program MYPROG, issue the following command at the TACL
prompt:
RUN myprog
You can include run options in the TACL RUN command.  Section 16, “Running and
Debugging Programs,” gives an overview of some commonly used run options.  Formore information on run options, see the TACL Reference Manual.
The remainder of this manual describes the structure of a TAL source file, variable
declarations, expressions, statements, procedure declarations, and other language- andcompiler-specific information.