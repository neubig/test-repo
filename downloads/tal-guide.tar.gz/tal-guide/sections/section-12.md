# Section 12: Controlling Program Flow

statements contain a condition, which lets the program select which path to takeduring execution.
Some statements can also be executed repeatedly, applying a set of operations to
different data during each iteration.  A group of statements that can be executedrepeatedly is called a loop.  Each loop must contain a termination condition, which letsthe program decide whether to continue repeating the loop or to stop after a particulariteration.
Other statements provide unconditional control over program flow.  They contain no
decision-making conditions but often follow, or are nested in, a conditional statement.
This section discusses conditional and unconditional control statements in the order
shown in Table 12-1.
Table 12-1.  Program Control Statements
Statement Type OperationIF Conditional Conditionally selects one of two possible statements
CASE Conditional Selects a set of statements based on a selector value
WHILE Conditional Executes a pretest loop while a condition is trueDO Conditional Executes a posttest loop until a condition is trueFOR Conditional Executes a pretest loop n times
ASSERT Conditional Conditionally calls an error-handling procedureCALL Unconditional Calls a procedure or subprocedureRETURN Unconditional Returns from a procedure or subprocedure to the caller;  returns a
value from a function.  As of the D20 release, it can also return acondition code value.
GOTO Unconditional Branches to a label within a procedure or subprocedure

IF StatementControlling Program Flow
the condition before selecting a statement.  If the condition is true, the THEN clauseexecutes.  If the condition is false, the ELSE clause executes, if present.
To specify an IF statement, include:
IF condition
Specifies a condition that, if true, causes the THEN clause to execute.  If false,  the
condition  causes the ELSE clause to execute.  If no ELSE clause is present, the
statement following the IF statement executes.  The condition  can be either:
A conditional expression
An INT arithmetic expression.  If the result of the arithmetic expression is not
0, the condition  is true.  If the result is 0, the condition  is false.
THEN statement
Specifies a statement to execute if the condition  is true.   If you omit the statement
in the THEN clause,  no action occurs for the THEN clause.  The statement  can be
any TAL statement.
ELSE statement  (optional)
Specifies a statement to execute if the condition  is false.  If the condition  is false and
no ELSE clause is present, the statement following the IF statement executes.  Thestatement  can be any TAL statement.
For example, the following IF statement calls an error handler if VAR_ITEM contains a
nonzero value:
INT var_item;
!Some code hereIF var_item <> 0 THEN  CALL error_handler;
The following example is equivalent to the preceding example:
IF var_item THEN
CALL error_handler;
The following IF statement compares two arrays.  If the arrays are equal, the IF
statement assigns a 1 to ITEM_OK.  If they are not equal, it assigns 0 to ITEM_OK:
INT new_array[0:9];
INT old_array[0:9];INT item_ok;!Some code hereIF new_array = old_array FOR 10 WORDS THEN  item_ok := 1            !No semicolon when followed by ELSEELSE  item_ok := 0;

IF StatementControlling Program Flow
Figure 12-1.  IF-THEN Execution
IF
FALSE
; next-statement
404condition
TRUETHEN statement
The IF-THEN-ELSE form executes as shown in Figure 12-2.
Figure 12-2.  IF-THEN-ELSE Execution
IF
; next-statementFALSE
ELSE statement
405condition
TRUETHEN statement

IF StatementControlling Program Flow
clause pairs with the closest ELSE clause.  Formatting can make the IF-ELSE pairingobvious or ambiguous.
The following side-by-side examples are equivalent.  In both cases, the ELSE clause
belongs to the second IF statement, but the pairing is clearer in the example on the left:
Recommended Format Unclear Format
IF expression1 THEN               IF expression1 THEN
IF expression2 THEN             IF expression2 THEN stmt1    stmt1                         ELSE stmt2;  ELSE    stmt2;
To override the default IF-ELSE pairing, you can use the BEGIN-END construct.  For
example, if you insert a BEGIN-END pair in the preceding example, the ELSE clausebelongs to the first IF clause rather than to the second IF clause:
IF expression1 THEN
BEGIN                      !Begin compound statement    IF expression2 THEN      stmt1;  END                        !End compound statement;ELSE                         ! no semicolon before ELSE    stmt2;

CASE Statement, LabeledControlling Program Flow
LabeledA labeled CASE statement consists of a selector and a series of case alternatives.   Each
alternative associates one or more case labels with a set of statements.  When theselector matches a case label, the associated set of statements executes.
The unlabeled CASE statement is described in the TAL Reference Manual .
To specify a labeled CASE statement, include:
CASE selector  OF BEGIN
Specifies a value that selects the case-alternative  to execute.  The selector  must be an
INT arithmetic expression; for example:
INT i;                    !Declare INT variable I
!Code to initialize ICASE i OF BEGIN ...       !Selector is I
case-alternatives
Each case-alternative  specifies a choice of statements  to execute when the selector
matches a case-label .  You can specify any number of case-alternatives ; at least one is
required.  Each case-alternative  consists of:
case-labels  ->
One or more INT constants in any order, separated by commas, followed by
->.  To include a case-label  as a range of constants, specify the lowest and
highest values separated by two periods (..):
2, 9, 4 .. 7, 11 ->     !Case labels 2, 4, 5, 6, 7,
```
                          ! and 9 for one alternative
```
statements
One or more statements to execute if the selector  matches any case-label  in this
alternative:
2, 9, 4 .. 7 ->         !Case labels
```
    aa := cc + dd;        !When I is 2 or 9 or any of    bb := cc – dd;        ! 4 through 7, execute these                          ! statements
```
OTHERWISE –> statements
An optional clause that specifies optional statements  to execute if the selector  does
not match any case-label  in the CASE statement.  If no OTHERWISE clause is
present and the selector  does not match a case-label , a run-time error results.  So
always include the OTHERWISE clause, even if it contains no statements .
END
Specifies the end of the CASE statement.

CASE Statement, LabeledControlling Program Flow
OTHERWISE clause:
INT location;
LITERAL bay_area, los_angeles, hawaii, elsewhere;
PROC area_proc (area_code);       !Declare procedure
```
    INT area_code;                !Declare selector  as
```
BEGIN                           ! formal parameter  CASE area_code OF               !
Selector  is AREA_CODE
```
    BEGIN    408, 415 ->      location := bay_area;    213, 818 ->      location := los_angeles;    808 ->      location := hawaii;    OTHERWISE ->      location := elsewhere;    END;                          !End CASE statement  END;                            !End AREA_PROC
```
Statement Forms
Generated by the CompilerThe compiler generates a branch table form or a conditional test form of the labeled
CASE statement, depending on the maximum range and number of case label values:
The compiler generates a branch table form if the maximum range (between thesmallest and largest case labels) is either:
Less than 257
Between 257 and 2048 inclusive and the approximate number of words of codefor the branch table form (maximum range  + 12) is no greater than theapproximate number of words of code for the conditional test form (numberof labels * 13 + 2)
In all other cases, the compiler generates a conditional test form.   If the statement
has more than 63 case labels, the compiler issues an error.
The branch table form is much faster than the conditional test form.To improve the efficiency of the conditional test form, you can order the alternatives
from most common to least common.

CASE Statement, LabeledControlling Program Flow
StatementsIf a CASE statement contains many GOTO statements, you can use the OPTIMIZE
directive to reduce the size of the object code.  Use OPTIMIZE level 1 or 2 as follows:
In a program under development, use level 1.
In a stable program, use level 2, which optimizes code across statementboundaries, so debugging is more difficult.
The CHECK directive does not affect the labeled CASE statement (as it does the
unlabeled CASE statement).
Labeled CASE
Statement ExecutionFigure 12-3 shows how the labeled CASE statement executes.
Figure 12-3.  Labeled CASE Statement Execution
CASE selector OF
BEGIN
END;
next-statement
406OTHERWISE clausecase-alternativecase-alternative
.
..

WHILE StatementControlling Program Flow
condition is true.
To specify a WHILE statement, include:
WHILE condition
Specifies a condition that, if true, causes the loop to execute.  If the condition  is
false, the loop does not execute.  The condition  can be either:
A conditional expression
An INT arithmetic expression.  If the result of the arithmetic expression is not
0, the condition  is true.  If the result is 0, the condition  is false.
DO statement
Specifies a statement to execute while the condition  is true.  The statement  can be
any TAL statement.
For example, this WHILE loop continues while ITEM is less than LEN:
LITERAL len = 100;
INT .array[0:len - 1];INT item := 0;
WHILE item < len DO          !WHILE statement
BEGIN  array[item] := 0;  item := item + 1;  END;  !ITEM equals LEN at this point
The WHILE statement tests the condition  before each iteration of the loop.  If the
condition  is false before the first iteration, the loop never executes.  If the condition  is
always true, the loop executes indefinitely unless a statement in the loop causes anexit.  In the following example, a GOTO statement branches to a label outside theWHILE statement when the IF condition is true:
WHILE -1 !true! DO
BEGIN  !Lots of code  IF <condition> THEN GOTO exit_loop;  !More code  END;exit_loop:                   !Label!<statement>!More code

WHILE StatementControlling Program Flow
LITERAL len = 255;
STRING .array[0:len - 1];INT index := -1;
WHILE (index < len - 1) AND
```
      ($ALPHA(array[index := index + 1]))DO ... ;
```
Figure 12-4 shows the action of the WHILE statement.
Figure 12-4.  WHILE Statement Execution
WHILE condition
; next-statementFALSETRUEDO statement

DO StatementControlling Program Flow
condition becomes true.  If the condition is always false, the loop repeats until astatement in the DO loop causes an exit.
To specify a DO statement, include:
DO statement
Specifies a statement to execute until the condition  becomes true.  The statement  can
be any TAL statement.
UNTIL condition
Specifies a condition that, if false, causes the DO loop to continue.  If the condition
is true, the statement following this DO statement executes.  The condition  can be
either:
A conditional expression
An INT arithmetic expression.  If the result of the arithmetic expression is not0, the condition  is true.  If the result is 0, the condition  is false.
A DO statement always executes at least once because the compiler tests the condition
at the end of the loop.  Unless you have a special reason to use the DO statement, it issafer to use the WHILE statement.
The following DO loop cycles through an array until each element is assigned a 0:
LITERAL len = 50;
LITERAL limit = len - 1;INT i := 0;STRING .array_a[0:limit];       !Declare array
DO                              !DO statement
BEGIN  array_a[i] := 0;              !Compound statement to  i := i+1;                     ! execute in DO loop  ENDUNTIL i > limit;                !Condition for ending loop!Rather than I = LEN
Figure 12-5 shows the action of the DO statement.

DO StatementControlling Program Flow
DO statement UNTIL condition
; next-statementFALSE
TRUE

FOR StatementControlling Program Flow
decrementing an index automatically.  The loop terminates when the index reaches alimit value.  If the index is greater than the limit on the first test, the loop neverexecutes.
To specify a FOR statement, include:
FOR index  :=
Specifies a value that increments or decrements automatically until it reaches a
specified value and terminates the loop.
In a standard FOR loop, index  is the identifier of an INT simple variable, array
element, simple pointer, or structure data item.
In an optimized FOR loop, index  is the identifier of an index register you have
reserved by using the USE statement.
initial-value
An INT arithmetic expression (such as 0) that initializes index .
limit
An INT arithmetic expression specified as either:
TO limit —Increments index  each time the loop executes until index  exceeds
limit
DOWNTO limit —Decrements index  each time the loop executes until index  is
less than limit
BY step
An optional clause for specifying an INT arithmetic expression by which to
increment or decrement index .  The default value is 1.
DO statement
Specifies the statement to execute each time through the loop.  The statement  can be
any TAL statement.
For example, this standard FOR loop clears an array by assigning a space to each
element in the array:
LITERAL len = 100;
LITERAL limit = len - 1;STRING .array[0:limit];INT index;
FOR index := 0 TO limit DO       !Use default step of 1;
array[index] := " ";           ! fill elements with spaces
FOR index := 4 TO limit BY 5 DO
array[index] := "!";           !Replace every fifth space                                 ! with exclamation point

FOR StatementControlling Program Flow
"TAB":
LITERAL len = 3;
LITERAL limit = len - 1;STRING .normal_str[0:limit] := "BAT";STRING .reversed_str[0:limit];INT index;
FOR index := limit DOWNTO 0 DO
reversed_str[limit - index] := normal_str[index];
Nesting FOR Loops You can nest FOR loops to any level.  The following nested FOR loop treats
MULTIPLES as a two-dimensional array.  It fills the first row with multiples of 1, thenext row with multiples of 2, and so on:
INT .multiples[0:10*10-1];
INT row;INT column;
FOR row := 0 TO 9 DO
FOR column := 0 TO 9 DO    multiples [row * 10 + column] := column * (row + 1);
Standard FOR Loops For index , standard FOR loops specify an INT variable.  Standard FOR loops execute as
follows:
When the looping terminates, index  is one greater than limit  if:
The step value is 1.
The TO keyword (not DOWNTO) is used.
The limit  value (not a GOTO statement) terminates the looping.
limit  and step are recomputed at the start of every iteration of the loop.

FOR StatementControlling Program Flow
Figure 12-6 shows the action of the standard FOR loop.
Figure 12-6.  Standard FOR Loop Execution
Increment or decrement
index BY stepFOR index := initial-value
Calculate limit and step
FALSETRUEIs
index
past
limit
?
; next-statement
409DO statement

FOR StatementControlling Program Flow
Optimized FOR loops execute faster than standard FOR loops;  they execute asfollows:
When the looping terminates, index  is equal to limit .
limit  is calculated only once, at the start of the first iteration of the loop.
You optimize a FOR loop as follows:1. Before the FOR statement, specify a USE statement to reserve an index register.2. In the FOR statement:
For index, use the identifier of the index register.
Omit the step value (thereby using the default value of 1).
For limit , use the TO keyword.
3. If you modify the register stack, save and restore it before the end of the looping.
(Modifying the register stack, however, is not portable to future softwareplatforms.)
4. After the FOR statement, specify a DROP statement to release the index register.
Do not drop the index register during the looping.
The following example contrasts a standard FOR loop with an equivalent optimized
FOR loop.  Both FOR loops clear the array by assigning a blank space to each elementin the array:
LITERAL len = 100;
LITERAL limit = len-1;           !Declare ARRAY to useSTRING .array[0:limit];          ! in both FOR loopsINT index;                       !Declare INDEX
FOR index := 0 TO limit DO       !Standard FOR loop;
array[index] := " ";
USE x;                           !Reserve index register
FOR x := 0 TO limit DO           !Optimized FOR loop  array[x] := " ";DROP x;                          !Release index register
For more information on the USE and DROP statements, see the TAL Reference Manual.
Inclusion of procedure calls in the FOR loop slows down the loop because the
compiler must save and restore registers before and after each call.

FOR StatementControlling Program Flow
The execution of optimized FOR loops differs from standard FOR loops as follows:
When the looping terminates, index  is equal to limit .
limit  is calculated only once—at the start of the first time through the loop.
The following example compares the value of index  in standard and optimized FOR
loops:
PROC a MAIN;
BEGIN  INT i, j, k;  FOR i := 1 TO 10 DO k := i;    !Standard FOR loop  k := i;                        !K is 11
USE j;
FOR j := 1 TO 10 DO k := j;    !Optimized FOR loop  k := j;                        !K is 10
DROP j;
END;

ASSERT StatementControlling Program Flow
directive.  It is a debugging or error-handling tool.
To specify the ASSERT statement, include:
ASSERT assert-level
Specifies an integer in the range 0 through 32,767, followed by a colon.  If the
assert-level  is equal to or higher than the assertion level specified in the current
ASSERTION directive and if the condition  is true, the compiler activates the
procedure specified in the ASSERTION directive.  If the assert-level  is lower than
the assertion level, the procedure is not activated.
condition
An expression that tests a program condition and yields a true or false result.
For example, this ASSERT statement specifies an assert-level  of 7 and the expression
$CARRY, which tests a program condition:
ASSERT 7 : $CARRY;
$CARRY is a standard function that tests the state of the carry indicator.  If the carry
indicator is on, $CARRY returns a true; if it is off, it returns a false.  The carry indicatoris set when a scan resulting from a SCAN or RSCAN statement is stopped by a 0.  It isalso set by some arithmetic operations.
Using ASSERT
with ASSERTIONYou use the ASSERT statement with the ASSERTION directive as follows:
1. Place an ASSERTION directive in the source code where you want to start
debugging.  In the directive, specify an assertion-level  and an error-handling
procedure such as the D-series PROCESS_DEBUG_ or the C-series DEBUG systemprocedure.  The assertion-level  is an integer in the range 0 through 32,767:
?ASSERTION 5, PROCESS_DEBUG_     !Assertion-level is 5
2. Place an ASSERT statement at places where you want to invoke the error-handling
procedure when an error occurs.  In the statement, specify an assert-level  that is
equal to or higher than the assertion-level  and specify an expression such as
$CARRY that tests a program condition:
ASSERT 10 : $CARRY;              !Assert-level is 10
3. During program execution, if an assert-level  is equal to or higher than the current
assertion-level  and condition  is true, the compiler activates the error-handling
procedure.
4. After you debug the program, you can nullify all or some of the ASSERT
statements by specifying an ASSERTION directive with a higher assertion-level
than the ASSERT statements you want to nullify:
?ASSERTION 11, PROCESS_DEBUG_
```
     !Assertion-level nullifies 
```
assert-level  10 and below

ASSERT StatementControlling Program Flow
occurs:
?SOURCE $SYSTEM.SYSTEM.EXTDECS (PROCESS_DEBUG_)
?ASSERTION 5, PROCESS_DEBUG_        !Assertion-level 5 activates all ASSERT conditionsSCAN array WHILE " " -> @pointer;ASSERT 10 : $CARRY;!Lots of codeASSERT 10 : $CARRY;!More codeASSERT 20 : $OVERFLOW;        !$OVERFLOW function tests for arithmetic overflow
Nullifying ASSERT
StatementsTo make it easier to nullify all ASSERT statements that cover a particular condition, set
all such ASSERT statements to the same assert-level .  In the previous example, if you
specify an ASSERTION directive with an assertion-level  of 11, you nullify the two
ASSERT statements that are set at 10.   If you specify an ASSERTION directive set to30, you nullify all the ASSERT statements.

CALL StatementControlling Program Flow
identifier, and optionally pass parameters to it.
To specify a CALL statement, you can include:
CALL identifier
Specifies the identifier of a procedure, subprocedure, or entry-point identifier.  As
of the D20 release, the CALL keyword is optional.
parameter-list
Specifies an optional list, enclosed in parentheses, of one or more comma-
separated actual parameters that you want to pass to the called procedure orsubprocedure.  The actual parameters in the list must correspond to the formalparameters of the called procedure or subprocedure.
Calling Procedures
and SubproceduresTo call a procedure or subprocedure that has no formal parameters, simply include the
identifier of the procedure or subprocedure in the CALL statement:
CALL error_handler;
When a called procedure or subprocedure finishes executing, control returns to the
statement following the CALL statement that invoked the procedure or subprocedure.
To call a procedure or subprocedure that has formal parameters, include the identifier
of the procedure or subprocedure and a list of actual parameters in the CALLstatement:
CALL compute_tax (item, rate, result);
For VARIABLE or EXTENSIBLE procedures, some or all of the formal parameters are
optional.   When you call such a procedure, you can omit some or all of the optionalparameters:
Omitting Parameters Unconditionally
To omit some of the parameters or parameter pairs, use a place-holding comma for
each omitted parameter or parameter pair up to the last specified parameter orparameter pair.  Here are examples of omitted parameters:
CALL extensible_proc (num, , char, , , eof);CALL extensible_proc ( , , , , , x);
To omit all parameters, you can specify an empty parameter list or you can omit the
parameter list altogether:
CALL extensible_proc ( );CALL extensible_proc;
In addition to place-holding commas, you can include comments to keep track of
omitted parameters:
CALL extensible_proc (num, !name!, char, !val!, !size!, eof);

CALL StatementControlling Program Flow
To omit a parameter or parameter pair conditionally, use the $OPTIONAL standard
function (D20 release or later) as described in Section 11, “Using Procedures.”
Calling Functions Callers usually invoke functions by using the function identifier in expressions, as
described in Section 11, “Using Procedures.”  A caller can also invoke functions byusing a CALL statement, in which case the caller ignores the returned value.
Calling Procedures
Declared as Formal
ParametersCallers can call procedures declared as formal parameters.  If the called procedure is a
VARIABLE or EXTENSIBLE procedure, the caller must provide the appropriateparameter mask.  For more information, see Section 11, “Using Procedures.”
Passing Parameter Pairs You can pass parameter pairs in the CALL statement, as described in Section 17,
“Mixed-Language Programming.”

RETURN StatementControlling Program Flow
subprocedure is a function, RETURN must return a result.  As of the D20 release,RETURN can also return a program-specified condition code (CC).
The form of the RETURN statement depends on whether the return is from a function
or from a procedure or subprocedure that is not a function.
Returning From Functions A function should contain a RETURN statement and must return a result-expression  to
the caller.  The result-expression  can be any arithmetic or conditional expression of the
same data type as specified in the function declaration.  (A function can be a procedureor a subprocedure.)
If a function lacks a RETURN statement, the compiler issues a warning but the
compilation can complete and the resulting object file can be run.  After the functionexecutes, it returns a zero.
The following function returns the result-expression  20 in a RETURN statement:
INT PROC a;
BEGIN  !Lots of code  RETURN 20;                 !Return a result from a function  END;
The following function contains two RETURN statements nested in an IF statement:
INT PROC other (nuff, more); !Declare function with type INT
```
    INT nuff;    INT more;  BEGIN  IF nuff < more THEN        !IF statement      RETURN nuff * more     !Return either of two  ELSE                       ! results based on the      RETURN 0;              ! condition NUFF < MORE  END;
```

RETURN StatementControlling Program Flow
As of the D20 release, if result-expression  is any type except FIXED or REAL(64), a
function can return a cc-expression  and a result-expression.   cc-expression  is an INT
expression whose numeric value specifies the condition code value to return to thecaller.  If the cc-expression  is:
Less than 0 Set the condition code to less than (<)
Equal to 0 Set the condition code to equal (=)Greater than 0 Set the condition code to greater than (>)
The following function returns a result and a condition code to inform its caller that
the returned value is less than, equal to, or greater than some maximum value:
INT PROC p (i);
```
    INT i;  BEGIN    RETURN i, i - max_val;   !Return a value and a  END;                       ! condition code
```
If you call a function, rather than invoking it in an expression, you can test the
returned condition code:
INT PROC p1 (i);
```
    INT i;  BEGIN  RETURN i;  END;
```
INT PROC p2 (i);
```
    INT i;  BEGIN  INT j := i + 1;  RETURN i, j;  END;
```
CALL p1 (i);
IF < THEN ... ;              !Test the condition codeCALL p2 (i);IF < THEN ... ;              !Test the condition code

RETURN StatementControlling Program Flow
operation overflows:
PROC p (s, x, y);
```
    INT .s, x, y;  BEGIN  INT cc_result;  INT i;  i := x + y;  IF $OVERFLOW THEN cc_result := 1               ELSE cc_result := 0;  s := i;
```
RETURN , cc_result;        !If overflow, condition code
END;                       ! is >; otherwise, it is =
Returning From
Nonfunction ProceduresIn procedures and subprocedures that are not functions, a RETURN statement is
optional.  If you include a RETURN statement, it cannot return a result .
The following procedure returns control to the caller when A is less than B:
PROC something;
BEGIN  INT a,      b;  !Manipulate A and B  IF a < b THEN    RETURN;                  !Return to caller  !Lots more code  END;
To return a condition code value, a nonfunction procedure or subprocedure must use
a RETURN statement that includes cc-expression .
In a main procedure, a RETURN statement stops execution of the program and returns
control to the operating system.

GOTO StatementControlling Program Flow
is preceded by the specified label.
To specify a GOTO statement, include a label identifier after the GOTO keyword; for
example:
GOTO label_one;
Local Scope A local GOTO statement can refer only to a local label in the same procedure.  A local
GOTO statement cannot refer to a label in a subprocedure or in any other procedure.
In the following example, a local GOTO statement branches to a local label:
PROC p
BEGIN  LABEL calc_a;          !Declare local label  INT a;  INT b := 5;
calc_a :                 !Place label at local statement
a := b * 2;  !Lots of code  GOTO calc_a;           !Local branch to local label  END;
Sublocal Scope A sublocal GOTO statement can refer to a label in the same subprocedure or in the
encompassing procedure.  A sublocal GOTO statement cannot refer to a label inanother subprocedure.
In the following example, a sublocal GOTO statement branches to a local label:
PROC p;
BEGIN  LABEL a;               !Declare local label  INT i;
SUBPROC s;
```
    BEGIN    !Lots of code    GOTO a;              !Sublocal branch to local label    END;
```
!Lots of code
a :                      !Place label at local statement  i := 0;  !More code  END;

GOTO StatementControlling Program Flow
are useful when you need to:
Branch to a common exit or common error-handling code after some condition ismet
Exit from the middle of a multidimensional search or loop after some condition ismet
Maximize program performance
For most other circumstances, use conditional control statements such as labeled
CASE, DO, IF, and WHILE.