# Section 1: Introducing TAL

language that works efficiently with the system hardware to provide optimal objectprogram performance.  The TAL compiler compiles TAL source programs intoexecutable object programs.  The compiler and the object programs it generatesexecute under control of the Tandem NonStop Kernel.
Using TAL You use TAL most often for writing systems software or transaction-orientedapplications where optimal performance has high priority.  You can, for example, useTAL to write the kinds of software listed in Table 1-1.
Table 1-1.  Uses of TAL
Kind of
Software Examples
Systems
softwareOperating system components
Compilers and interpretersCommand interpretersSpecial subsystemsSpecial routines that support data communication activities
ApplicationssoftwareServer processes used with Tandem data management software
Conversion routines that allow data transfer between Tandem software and otherapplicationsProcedures that are callable from programs written in other languagesApplications that require optimal performance
Many Tandem software products are written in TAL.
Major Features The major features of TAL are:
Procedures—Each program contains one or more procedures.  A procedure is a
discrete sequence of declarations and statements that performs a specific task.  Aprocedure is callable from anywhere in the program.
Each procedure executes in its own environment and can contain local data that is
not affected by the actions of other procedures.  When a procedure calls anotherprocedure, the operating system saves the caller’s environment and restores theenvironment when the called procedure returns control to the caller.
Subprocedures—A procedure can contain subprocedures, callable only fromwithin the same procedure.  When a subprocedure calls another subprocedure, thecaller’s environment remains in place.  The operating system saves the location inthe caller to which control is to return when the called subprocedure terminates.
Private data area—Each activation of a procedure or subprocedure has its owndata area.   When each activation terminates, it relinquishes its private data area,thereby keeping the amount of memory used by a program to a minimum.

Major FeaturesIntroducing TAL
data area, a procedure or subprocedure can call itself or can call other proceduresthat in turn calls the original procedure.
Parameters—A procedure or subprocedure can have optional or requiredparameters.  The same procedure or subprocedure can process different sets ofvariables sent by different calls to it.
Data types—You can declare and reference the following types of data:
Data Type DescriptionSTRING 8-bit integer byte
INT,  INT(16) 16-bit integer word
INT(32) 32-bit integer doublewordFIXED,  INT(64) 64-bit fixed-point quadruplewordREAL,  REAL(32) 32-bit floating-point doublewordREAL(64) 64-bit floating-point quadruplewordUNSIGNED(
n) n-bit field, where 1 <= n <= 31
Data sets—You can declare and use sets of related variables such as arrays and
structures (records).
Pointers—You can declare pointers (variables that can contain byte addresses orword addresses) and use them to access locations throughout memory.  You canstore addresses in them when you declare them or later in your program.
Data operations—You can copy a contiguous group of words or bytes andcompare one group with another.  You can scan a series of bytes for the first bytethat matches (or fails to match) a given character.
Bit operations—You can perform bit deposits, bit extractions, and bit shifts.
Standard functions—You can use built-in functions, for example, to convert datatypes and addresses, test for an ASCII character, or determine the length, offset,type, or number of occurrences of a variable.
Compiler directives—You can use directives to control a compilation.  You can, forexample, check the syntax in your source code or control the content of compilerlistings.
Modular programming—You can divide a large program into modules, compilethem separately, and then bind the resulting object files into a new object file.
Mixed-language programming—You can use NAME and BLOCK declarations,procedure declaration options—such as public name, language attribute, andparameter pairs—and compiler directives in support of mixed-languageprogramming.
NonStop SQL features—You can use compiler directives to prepare a program inwhich you want to embed SQL statements.

CRE ServicesIntroducing TAL
and whether your program fits into memory.  For example, programs are loaded intomemory for you and absent pages are brought from disk into memory as needed.
System Procedures The file system treats all devices as files, including disk files, disk packs, terminals,printers, and programs running on the system.   File-system procedures provide afile-access method that lets you ignore the peculiarities of devices.  Your program canrefer to a file by the file’s symbolic name without knowing the physical address orconfiguration status of the file.
Your program can call system procedures that activate and terminate programs
running in any processor on the system.  Your program can also call systemprocedures that monitor the operation of a running program or processor.  If themonitored program stops or a processor fails, your program can determine this fact.
System procedures are described in the Guardian Procedure Calls Reference Manual  and
the Guardian Programmer’s Guide for your system .
TAL Run-Time Library  The TAL run-time library provides routines that:
Initialize the Common Run-Time Environment (CRE) when you use D-series
compilers (as described later in this manual)
Prepare a program for SQL statements (as described in the  NonStop SQL
Programming Manual for TAL )
CRE Services The CRE provides services that support mixed-language programs compiled on
D-series compilers.  A mixed-language program can consist of C, COBOL85,FORTRAN, Pascal, and TAL routines.
A routine is a program unit that is callable from anywhere in your program.  The term
routine can represent:
A C function
A COBOL85 program
A FORTRAN program or subprogram
A Pascal procedure or function
A TAL procedure or function procedure

CRE ServicesIntroducing TAL
Use the routine’s run-time library without overwriting the data of another run-
time library
Share data in the CRE user heap
Share access to the standard files—standard input, standard output, and standardlog
Call math and string functions provided in the CRELIB file
Call Saved Messages Utility (SMU) functions provided in the Common LanguageUtility Library (CLULIB file)
Without the CRE, only routines written in the language of the MAIN routine can fully
access their run-time library.  For example, if the MAIN routine is written in TAL, aroutine written in another language might not be able to use its own run-time library.
Section 17, “Mixed-Language Programming,” gives CRE guidelines for TAL programs.The CRE Programmer’s Guide  describes the services provided by the CRE, including the
math, string, and SMU functions.