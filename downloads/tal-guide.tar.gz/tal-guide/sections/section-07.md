# Section 7: Using Arrays

to store constants, especially character strings.  You can use the array identifier toaccess the elements individually or as a group.
This section describes:
Declaring arrays
Initializing arrays
Allocating storage for arrays
Accessing arrays
Assigning data to arrays
Copying data into arrays
Scanning arrays
Comparing arrays
This section mostly describes arrays located in the user data segment or in an extended
data segment.  “Read-only Arrays” at the end of the section briefly discusses arrayslocated in a user code segment.
Section 8, “Using Structures,” shows how structures can simulate multidimensional
arrays, arrays of arrays, or arrays of structures.
Declaring Arrays Before processing an array, you must declare it and store data in it.  The declarationassociates an identifier with a memory address.  It also tells the compiler how muchstorage to allocate for the array and the storage area in which to allocate it.
To declare an array, specify:
A data type
An identifier , usually preceded by an indirection symbol (. or .EXT)
Lower and upper bounds —the indexes of the first and last array elements,
specified as INT constant expressions in the range –32,768 through 32,767,separated by a colon and enclosed in brackets as follows.  The upper bound mustbe equal to or larger than the lower bound.
[0:5]                        !Six elements
Here are examples of array bounds you can declare:
STRING a_array[0:2];            !Three-element array
INT b_array[0:19];              !Twenty-element arrayUNSIGNED(1) flags[0:15];        !Array of 16 one-bit elements
Specify the data type and identifier using the type and identifier formats described in
Section 5, “Using Expressions.”
The preceding arrays are all direct arrays;  that is, declared without an indirection
symbol.  Arrays of any data type can be direct.  The compiler allocates storage fordirect arrays in the primary areas of the global, local, or sublocal storage areas.

Declaring ArraysUsing Arrays
limited to 127 words.  The global and local secondary areas have no explicit size, andthe total of all primary and secondary areas can be as large as the lower 32K-word areaof the user data segment.  You can minimize the impact on the primary areas bydeclaring indirect global and local arrays.  Global and local arrays of any data typeexcept UNSIGNED can be indirectly addressed.
The sublocal storage area has no secondary area, so all sublocal arrays must be directly
addressed.
To declare a standard indirect array, precede the array identifier with a standard
indirection symbol (.) as follows:
INT .array_x[0:1];         !Declare standard indirect array
To declare an extended indirect array, precede the array identifier with an extended
indirection symbol (.EXT) as follows:
INT .EXT array_y[0:1];     !Declare extended indirect array
Specifying Data Types The data type determines the kind of values the array can contain.  The data type also
determines the storage unit the compiler allocates for each array element, as follows:
Data Type Storage UnitSTRING Byte
INT Word
INT(32) or REAL DoublewordREAL(64) or FIXED QuadruplewordUNSIGNED Sequence of 1, 2, 4, or 8 bits
“Arrays by Data Type” in this section gives more information on each data type.
Initializing Arrays You can initialize most arrays when you declare them.  You cannot initialize
UNSIGNED or local extended indirect arrays.  It is recommended that you initializearrays with values that are appropriate for the data type of the array.
To initialize an array, include an assignment operator (:=) and a constant list  or a
constant  in the array declaration.   For example, you can initialize an array with a
constant list as follows:
INT array[0:1] := ["A", "B"];
More information on array initializations is given in the following subsections.

Declaring ArraysUsing Arrays
A constant list can include the following elements:
Numbers
INT .numbers[0:5] := [1,2,3,4,5,6];
Character strings of up to 127 characters on one line
INT(32) .words[0:3] := ["cats", "dogs", "bats", "cows"];STRING .buffer[0:102] := [ "A constant list can consist ",
```
                 "of several character string constants ",                  "one to a line, separated by commas." ];
```
Repetition factors—INT constants by which to repeat constant lists
INT zeros[0:9] := 10 * [0];  !Repetition factor of 10
You can nest constant lists that include repetition factors.  The following example
expands to [1,1,0,0,1,1,0,0,1,1,0,0]:
INT digits[0:11] := [3 * [2 * [1], 2 * [0]]];
LITERALs
LITERAL len = 80;
STRING .buffer[0:len - 1] := len * [" "];
If you specify fewer initialization values than the number of elements (and the values
are appropriate for the data type of the array), the values of uninitialized elements areundefined:
STRING bean[0:9] := [1,2,3,4];  !Values in BEAN[4:9]
```
                                ! are undefined
```
Initializing Arrays With Constants
You can initialize an array with a numeric constant or a character string constant:
INT some_array[0:3] := -1;      !Values in SOME_ARRAY[1:3]
```
                                ! are undefined
```
INT any_array[0:1] := "abcd";   !Store one character per byte

Declaring ArraysUsing Arrays
You can initialize an array declared at any level except for extended indirect arrays
declared at the local level:
INT(32) .a[0:1] := [5D, 7D];    !Global array can be
```
                                ! initializedPROC my_procedure;  BEGIN  STRING .b[0:1] := ["A","B"];  !Local array can be                                ! initialized
```
FIXED .EXT c[0:3];            !Local extended indirect
```
                                ! array cannot be initialized  SUBPROC my_subproc;    BEGIN    INT d[0:2] := ["Hello!"];   !Sublocal array can be    !Lots of code               ! initialized    END;  END;
```
Arrays by Data Type The following subsections give information about arrays by data type.  For
information about the appropriate range and format of values for each data type, seeSection 6, “Using Simple Variables.”
STRING Arrays
For STRING arrays, the compiler allocates one byte for each element.  The compiler
always starts the zeroth element of a STRING array on a word boundary.  In thediagram, question marks denote undefined values:
STRING a[0:2];
STRING b[3:4];STRING c[-1:1];
361A[0] A[1]
A[2]    ?
? B[3]
B[4]    ?
? C[-1]
C[0] C[1]B[0]

Declaring ArraysUsing Arrays
For INT arrays, the compiler allocates a word for each element:
INT a[0:2];
INT b[2:3];INT c[-2:-1];B[0]
C[-1]
362B[3]
C[-2]A[2]
B[2]A[0]
A[1]
INT(32) Arrays
For INT(32) arrays, the compiler allocates a doubleword for each element:
D[0]
D[1]
363INT(32) d[0:1];
REAL ArraysFor REAL arrays, the compiler allocates a doubleword for each element:
REAL r[4:5];
R[4]
R[5]

Declaring ArraysUsing Arrays
For REAL(64) arrays, the compiler allocates a quadrupleword for each element:
REAL(64) r[0:1];
365R[0]
R[1]
FIXED Arrays
For FIXED arrays, the compiler allocates a quadrupleword for each element:
366FIXED f[0:1];
F[0]
F[1]
When you declare a FIXED array, you can specify the implied fpoint  of values you
store in the array elements.  The fpoint  is an integer in the range –19 through 19,
enclosed in parentheses, following the FIXED keyword.  The default fpoint  is 0 (no
decimal places).  Here is an example of a FIXED array with an fpoint  of 5:
FIXED(5) array[0:2];
If you declare a FIXED( *) array, values stored in the array are not scaled and are
treated as having an fpoint  of 0.

Declaring ArraysUsing Arrays
When you declare an UNSIGNED array, you must specify as part of the data type a
value of 1, 2, 4, or 8 that specifies the width , in bits, of the elements in the array.  Here is
an example of an UNSIGNED array that has eight 4-bit elements:
UNSIGNED(4) array[0:7];
The compiler packs allocation of UNSIGNED array elements in sequential words.  A
word can contain up to sixteen 1-bit elements, eight 2-bit elements, four 4-bit elements,or two 8-bit elements in successive bit fields.  For example, if you declare an array ashaving six 2-bit elements, the compiler packs allocation of all six 2-bit elements in thesame word:
UNSIGNED(2) a[0:5];0123456789 1 0 1 1 1 2 1 3 1 4 1 5
A[0] A[1] A[2] A[3] A[4] A[5]
The compiler always allocates the zeroth element of an UNSIGNED array at a wordboundary.  For example, if you declare an UNSIGNED simple variable followed by anUNSIGNED array having bounds of [4:7], the compiler allocates the array in the sameword as the simple variable, with the zeroth array element at bit [0]:
UNSIGNED(5) uns_var;
UNSIGNED(2) b[4:7];
36801234567891 0 1 1 1 2 1 3 1 4 1 5
UNS_VAR B[4] B[5] B[6] B[7]
If you declare a STRING simple variable followed by an UNSIGNED array, the
compiler allocates the zeroth array element starting at bit [0] of the next word:
STRING str_var;
UNSIGNED(2) c[4:7];
36901234567891 0 1 1 1 2 1 3 1 4 1 5
STR_VAR
C[4] C[5] C[6] C[7] C[0]

Declaring ArraysUsing Arrays
declaration characteristics such as:
The global, local, or sublocal level
The direct, standard indirect, or extended indirect addressing mode
Allocating Direct Arrays
The compiler allocates storage for directly addressed arrays in the global, local, or
sublocal primary areas of the user data segment as shown in Figure 7-1.
Figure 7-1.  Allocating Direct Arrays
INT(32) a[0:1];    !Global
INT b[1:2];        ! arrays
PROC proc_a;
BEGIN  STRING c[0:2];   !Local  FIXED d[0:3];    ! arrays    SUBPROC subproc_a;    BEGIN    INT e[0:1];    !Sublocal     STRING f[0:3]; ! arrays    !Lots of code    END;
!Lots of code
CALL subproc_a;  !More code  END; G[0]
S[0]L[1] C[0]
S[-3]
S[-2]S[-1]L[3]
Sublocal
arraysGlobal
arrays
Local
arraysB[1]
B[2]
. . .G[4]
C[1]
C[2]
. . .
. . .
E[0]E[1]
F[0]
F[2]F[1]
F[3]
370A[0]
D[0]A[1]
D[3]

Declaring ArraysUsing Arrays
You can declare global or local indirect arrays.  Sublocal arrays cannot be indirectly
addressed.
For each standard indirect array, the compiler allocates space as follows:1. It allocates a word of storage in the global (or local) primary area of the user data
segment for an implicit standard pointer.
2. It then allocates storage for each array in the global (or local) secondary area.3. Finally, it initializes each implicit pointer (provided in step 1) with the 16-bit
address of the array.  For a STRING array, the pointer contains a byte address.  Forany other array, the pointer contains a word address.
For each extended indirect array, the compiler allocates space as follows:1. It allocates a doubleword of storage in the global (or local) primary area of the user
data segment for an implicit extended pointer.
2. It then allocates storage for each extended array in an automatic extended data
segment.
3. Finally, it initializes each implicit pointer (provided in step 1) with the 32-bit byte
address of the array.  The address is always an even-byte address.
If you declare arrays within BLOCK declarations, however, the compiler allocates
storage anywhere within the list of data blocks, as described in Section 14, “CompilingPrograms.”

Declaring ArraysUsing Arrays
Figure 7-2.  Allocating Indirect Arrays
INT(32) .EXT a[0:9];
INT .EXT b[1:9];STRING .c[0:1];INT .d[-1:49]; G[0]
Global
primary
area
C[0] C[1]
D[-1]ptr to Cptr to DG[1]
G[2]G[3]G[4]G[5]G[6]G[7]G[8] D[0]
. . .
D[49]
Automatic extended
data segment
B[1]B[0]
B[2]
. . .
B[9]. . .User data segment
Global
secondary
area
G[57]
371ptr to A
ptr to B
A[0]
A[9]A[1]

Declaring ArraysUsing Arrays
the compiler issues an address range violation error.
Addressability in the User Data Segment
The zeroth element of a direct array must fit within the lower 32K-word area of the
user data segment, even if the zeroth element is not allocated.
The global area has G-plus addressing.  If a global array is located at G[0], its lower
bound must be a zero or negative value.  Avoid the following practice:
G[0]
G[1]A[1]
A[2]
372( A[0] )
INT a[1:2];
The sublocal area has S-minus addressing.  If a sublocal array is located at S[0], its
upper bound must be a zero or larger value.  Avoid the following practice:
S[-2]
S[-1]
S[0]A[-3]
A[-1]A[-2]
373SUBPROC s;
BEGIN  !Sublocal data  INT a[-3:-1];  !Lots of code  END;
( A[0] )
Addressability in the Extended Segment
The zeroth element of an extended indirect array must reside within the automatic
extended data segment, even if the zeroth element is not allocated.  If an extendedindirect array is located at the beginning of the extended data segment, its lowerbound must be a zero or negative value.  Avoid the following practice:
INT .EXT aa[1:2];
Automatic extended
data segmentUser data segment
G[0]ptr to AA
374AA[1]
AA[2]( AA[0] )

Accessing ArraysUsing Arrays
statements, regardless of addressing mode.  For example, you can declare a directarray, a standard indirect array, and an extended indirect array, and then access eachby its identifier:
INT dir_array[0:2];      !Declare direct array
INT .std_array[0:2];     !Declare standard indirect arrayINT .EXT ext_array[0:2]; !Declare extended indirect array
dir_array[2] := 5;       !Access third element of each
std_array[2] := 5;       ! array by using its identifier inext_array[2] := 5;       ! an assignment statement
Indexing Arrays To access an array element, you append an index  such as [5] to the array identifier.
You can access element [0] of any array (except type UNSIGNED) by specifying thearray identifier with no index.  Thus, the references BUFFER and BUFFER[0] areequivalent.  To access an UNSIGNED array, however, you must always append anindex:
UNSIGNED(8) uns_array[0:2];uns_array[0] := 0;       !UNS_ARRAY requires index
Index Values
The index value represents the array element you want to access, relative to the zeroth
element.  For example, to access the third element, specify an index of [2]:
INT array[0:2];array[2] := 5;           !Access third element of array
For the index value, use a signed arithmetic expression:
For standard addressing, use a signed INT expression, which has a range of
–32,768 through 32,767.
For extended addressing, use either a signed INT expression or an INT(32)expression, which has a range of –2,147,483,648 through 2,147,483,647.

Assigning the Address of ArraysUsing Arrays
LITERAL index = 5;       !Declare LITERAL
INT table[0:9];          !Declare array
table[index] := "AB";    !Access sixth element of array
You can use variables as index values:
INT .EXT b[0:10];        !Declare array
INT .c[0:9];             !Declare arrayINT(32) x;               !Declare variables X, Y, andINT y;                   ! Z to use for indexesINT z;
!Code to manipulate indexes and initialize arraysb[x] := c[y-z];          !Access array element
Assigning Data
to Array ElementsYou can assign data to one array element at a time.  For each array element, use a
separate assignment statement:
STRING .an_array[0:4];   !Declare AN_ARRAYan_array[1] := "Z";      !Assign "Z" to second
```
                         ! element of AN_ARRAY
```
You cannot use constant lists in assignment statements (as you can in declarations) to
assign values to multiple array elements.  For example, the following initialization ofTHIS_ARRAY is equivalent to the three assignment statements applied toTHAT_ARRAY:
INT .this_array[0:2] := ["ABCDEF"];
```
                         !Constant list initializes                         ! all elements of THIS_ARRAY
```
INT .that_array[0:2];that_array[0] := "AB";   !Assignment statements assign
that_array[1] := "CD";   ! values to elements ofthat_array[2] := "EF";   ! THAT_ARRAY, one at a time
However, you can copy data to multiple array elements by using a move statement,
described in “Copying Data Into Arrays” later in this section.
Assigning the
Address of ArraysYou can assign the address of array elements to other variables.  For example, to
assign the address of ARRAY[1] to VAR, prefix the array identifier with the @ operatorin an assignment statement:
INT .array[0:2];         !Declare array
INT var;                 !Declare simple variable
var := @array[1];        !Assign address of ARRAY[1]
```
                         ! to VAR
```

Copying Data Into ArraysUsing Arrays
Into ArraysTo copy data to multiple array elements, use the move statement.  You can, for
example, copy:
A constant list into an array
Data between arrays
Data within an array
Copying a Constant
List Into an ArrayTo copy a constant list into an array, specify the destination  array and the constant list  in
a move statement.  You can copy the source data from left to right or from right to left.
Copying Left to Right
To start copying from the leftmost item of the source data, use the left-to-right move
operator (':=').  For example, you can start copying from the leftmost character in asource character string such as "A ... Z."   In this case, you copy "A" into element [0] ofthe destination array, then "B" into element [1], and so on through element [25]:
STRING .alpha_array[0:25];      !Declare 26-element arrayalpha_array[0] ':=' ["ABCDEFGHIJKLMNOPQRSTUVWXYZ"];
```
                                !Copy "A" through "Z" into                                ! ALPHA_ARRAY[0] through [25]
```
Copying Right to Left
To start copying from the rightmost item of the source data, use the right-to-left move
operator ('=:').  For example, you can start copying from the rightmost constant of aconstant list such as [1, 2, 3, 4].  In this case, you copy the constant 4 into element [3] ofthe destination array, the constant 3 into element [2], and so on through element [0]:
INT num_array[0:3];             !Declare 4-element arraynum_array[3] '=:' [1, 2, 3, 4]; !Copy 4 through 1 into
```
                                ! NUM_ARRAY[3] through [0]
```
Using Repetition Factors
To repeat the same value in consecutive elements of the destination array, specify a
repetition factor followed by a multiplication operator ( *) and the value to repeat.  For
example, you can copy a zero into all elements of the destination array:
LITERAL len = 100;              !Specify repetition factor
INT .an_array[0:len - 1];       !Declare 100-element array
an_array[0] ':=' len * [0];     !Copy a zero into all
```
                                ! elements of AN_ARRAY
```

Copying Data Into ArraysUsing Arrays
To copy a single byte constant into an element of the destination array, enclose the
constant in brackets in the move statement.  The destination array must be a STRINGarray or have a byte address:
STRING x[0:8];                   !Declare STRING array Xx[0] ':=' ["A"];                 !Copy a single byte;
```
                                 ! puts "A" in X[0]
```
If you do not enclose the constant in brackets, you copy a word, doubleword, or
quadrupleword depending on the size of the constant.  The following example repeatsthe preceding example, substituting an unbracketed constant in the move statement:
STRING x[0:8];                   !Declare STRING array Xx[0] ':=' "A";                   !Copy a word; put %0 in
```
                                 ! X[0] and "A" in X[1]
```
Copying Data
Between ArraysTo copy data from one array to another, specify the destination  and source  arrays in the
move statement and include the FOR clause.  In the FOR clause, specify a count
value—an INT arithmetic expression that specifies the number of elements, bytes, orwords you want to copy.
Copying Bytes
To copy bytes regardless of source data type, specify the BYTES keyword in the FOR
clause of the move statement.  BYTES copies the number of bytes specified by the count
value.  If both source  and destination  have word addresses, however, BYTES generates a
word copy for ( count  + 1) / 2 words.
For example, you can copy bytes instead of words from an INT array as follows:
LITERAL length = 70;             !Number of array elements
INT .new_array[0:length - 1];    !Destination arrayINT .old_array[0:length - 1];    !Source arrayINT file_number;                 !File numberINT byte_count;                  !Count value (number of                                 ! bytes to copy)!Lots of code here
CALL READ (file_number, old_array, byte_count);
new_array[0] ':=' old_array[0] FOR byte_count BYTES;                                 !Copy bytes from OLD_ARRAY                                 ! to NEW_ARRAY

Copying Data Into ArraysUsing Arrays
To copy words regardless of source data type, specify the WORDS keyword in the
FOR clause.  WORDS generates a word copy for the number of words specified by thecount  value.
For example, to copy words instead of doublewords from an INT(32) source array,
multiply LENGTH by 2 and include the WORDS keyword:
LITERAL length = 12;             !Count value (number of
```
                                 ! words to copy)INT(32) .new_array[0:length - 1];!DestinationINT(32) .old_array[0:length - 1];!Source
```
!Some code here to put values in OLD_ARRAYnew_array[0] ':=' old_array[0] FOR 2 * length WORDS;
```
                                 !Copy 24 words from                                 ! OLD_ARRAY to NEW_ARRAY
```
Copying Elements
To copy elements based on the data type of the source array, you can specify the
ELEMENTS keyword.  For example, you can copy doubleword values from anINT(32) source array into the destination array as follows:
LITERAL length = 12;             !Count value (number of
```
                                 ! elements to copy)INT(32) .new_array[0:length - 1];!DestinationINT(32) .old_array[0:length - 1];!Source
```
!Some code here to put values in OLD_ARRAY
new_array[0] ':=' old_array[0] FOR length ELEMENTS;                                 !Copy 12 doublewords from                                 ! OLD_ARRAY to NEW_ARRAY
When you copy array elements, the ELEMENTS keyword is optional but provides
clearer source code.  When you copy structure occurrences, the ELEMENTS keywordis required, as described in Section 8, “Using Structures.”

Copying Data Into ArraysUsing Arrays
Within an ArrayTo copy data within an array, specify the same array for the destination and source
arrays and include the FOR clause in the move statement.
For example, you can free element [0] of a 12-element array by specifying the
following move statement.  This move statement first copies element [10] into element[11], then element [9] into element [10], and so forth.  Finally, it copies element [0] intoelement [1], thereby freeing element [0] for new data:
LITERAL upper_bound = 11;        !Upper bound of array
FIXED .buffer[0:upper_bound];    !12-element array
!Some code here to put values in
! BUFFER[0] through BUFFER[10]
buffer[upper_bound] '=:'
buffer[upper_bound - 1] FOR upper_bound;                                 !Start copy with BUFFER[10]                                 ! into BUFFER[11]
Using the Next Address The next address (also known as next-addr ) is the memory location immediately
following the last item copied.  The next address is returned by the move statement.You can use the next address for various purposes, such as the starting location for anew group of values.
First declare a simple pointer and then use its identifier (prefixed by @) in the next-
address clause in a move statement.  Here is an example of the next-address clause:
–> @next_addr_ptr
For example, you can copy spaces into the first five elements of an array, and then use
the next address as the destination for copying dashes into the next five elements:
LITERAL len = 10;                !Length of array
STRING .array[0:len - 1];        !Destination arraySTRING .next_addr_ptr;           !Simple pointer for                                 ! the next address
array[0] ':=' 5 * [" "] -> @next_addr_ptr;
```
                                 !Complete first copy                                 ! and capture next addressnext_addr_ptr ':=' 5 * ["-"];    !Use next address as start                                 ! of second copy operation
```

Copying Data Into ArraysUsing Arrays
Both arrays have standard byte addresses
Both arrays have standard word addresses
The compiler does an extended move and returns a 32-bit next address if:
One of the two arrays has a standard byte address and the other has a standard
word address
Either array has an extended address
STRING arrays and arrays pointed to by STRING pointers are byte addressed.  All
other arrays are word addressed.
Copying Bytes Into INT Arrays
To copy data from a byte-addressed source array into a word-addressed destination
array, declare an extended STRING simple pointer and use it in the next-addressclause of the move statement:
STRING  byte_array[0:9];         !Byte-addressed source array
INT     word_array[0:4];         !Word-addressed destination                                 ! arraySTRING  .EXT next_addr;          !STRING simple pointer for                                 ! the next-address clause!Some code hereword_array[0] ':=' byte-array[0] FOR 3 BYTES -> @next_addr;                                 !Copy three bytes into                                 ! WORD_ARRAY
When the copy operation is complete, the next-address pointer (NEXT_ADDR) points
to the right byte of WORD_ARRAY[1], not the left byte.
Concatenating
Copy OperationsYou can concatenate any number of move sources in a single move statement by using
the ampersand operator (&).
The following move statement concatenates six move sources.  It copies three string
constants and data from three arrays into LINE_ARRAY:
LITERAL line_len = 63;           !Length of destination array
LITERAL date_len = 11;           !Length of source array 1LITERAL id_len = 11;             !Length of source array 2LITERAL dept_len = 3;            !Length of source array 3
STRING .line_array[0:line_len - 1];     !Destination array
STRING .date_array[0:date_len - 1] := "Feb 1, 1992";STRING .id_num[0:id_len - 1] := "854-70-1950";STRING .dept_num[0:dept_len - 1] := "107";
line_array ':='   "   DATE: " & date_array FOR date_len BYTES
```
           & "   ID NUMBER: " & id_num FOR id_len BYTES          & "   DEPARTMENT: " & dept_num FOR dept_len BYTES;
```

Scanning ArraysUsing Arrays
DATE: Feb 1, 1992   ID NUMBER: 854-70-1950   DEPARTMENT: 107
Initializing a Large Array Quickly
To initialize a large array quickly, you can concatenate two copy operations in a move
statement.  The first copy operation copies two spaces into element [0], and the secondcopies the spaces from element [0] into the remaining elements:
LITERAL length = 100;           !Length of array
INT .array[0:length - 1];       !Destination array
array[0] ':=' "  " & array[0] FOR (length - 1);
```
                                !Initialize array to blanks
```
In the preceding example, make sure the value in the FOR clause is a positive number.
The move statement treats the value as an unsigned integer.  It treats a small negativenumber (such as –1) as a large positive number (in this case, 65,535).
Scanning Arrays You can use scan statements to scan arrays for a test character.  You can apply scanstatements to any array (except UNSIGNED arrays) located in the lower 32K-wordarea of the user data segment or no more than 32K words away in the user codesegment.  You can only scan bytes.
The SCAN statement scans an array from left to right.  The RSCAN statement scans an
array from right to left.  Both scan statements return the next address, described in“Using the Next Address” earlier in this section.
Delimiting the Scan Area Unless you delimit the scan area, a scan operation might continue to the 32K-word
boundary if:
A SCAN UNTIL operation does not find a zero or the test character
A SCAN WHILE operation does not find a zero or a character other than the testcharacter
When you declare the array to scan, you can use zeros to delimit the start and end of
the scan area.  Here is an example for delimiting the scan area with zeros:
INT .buffer[-1:20] := [0,"  John James Jones  ",0];
Here is another example for delimiting the scan area with zeros:
LITERAL stopper = 0;
STRING an_array[0:9];
!Fill array from some source
an_array[0] := stopper;an_array[9] := stopper;

Scanning ArraysUsing Arrays
Stopped the ScanTo determine what stopped the scan, test $CARRY in an IF statement immediately
after the SCAN or RSCAN statement.  If $CARRY is true after a SCAN UNTIL, the testcharacter did not occur.  If $CARRY is true after SCAN WHILE, a character other thanthe test character did not occur.  Here are examples for using $CARRY:
IF $CARRY THEN ... ;        !If test character not found
IF NOT $CARRY THEN ... ;    !If test character found
To determine the number of multibyte elements processed, divide (next address '–'
byte address of the array) by the number of bytes per element, using unsignedarithmetic.
Scanning Bytes in
Word-Aligned ArraysOperating system procedures require that procedure parameters use INT arrays,
which are word aligned.  To scan bytes in a word-aligned array, convert the wordaddress of the array to a byte address by using the unsigned left-shift operation('<<' 1) .
The following example converts the word address of an INT array to a byte address.
The assignment statement stores the resulting byte address into a STRING pointer.The SCAN statement then scans the bytes in the array until it finds a comma:
INT .words[-1:3] := [0,"Doe, J",0];
```
                            !Declare INT array (WORDS)
```
STRING .byte_ptr := @words[0] '<<' 1;
```
                            !Declare BYTE_PTR; initialize                            ! with byte address of WORDS[0]
```
SCAN byte_ptr[0] UNTIL ","; !Scan bytes in WORDS
Multipart Scan Example These declarations apply to a series of scan statement examples that follow:
INT .int_array[-1:9] := [0,"  Smith, Maurice  ",0];
```
                            !INT_ARRAY
```
STRING .sptr := @int_array[0] '<<' 1;
```
                            !STRING pointer to INT_ARRAY[0]
```
STRING .start_last_name,    !
```
       .end_last_name,      !       .start_first_name,   !STRING pointers for next address       .end_first_name,     !       .comma;              !
```
INT offset,                 !
```
    length;                 !INT variables
```

Scanning ArraysUsing Arrays
that stopped the scan.
Scanning WHILE
SCAN WHILE searches until it finds a byte character other than the test character or a
zero.  The following example scans left to right while spaces occur, starting from thezeroth element of INT_ARRAY.  The scan stops at the beginning of the last name andstores that address in the next-address pointer START_LAST_NAME.  An IF statementthen checks the carry bit to see what stopped the scan.  If a character (rather than azero) stopped the scan, the program calls a string-handling procedure:
SCAN sptr[0] WHILE " " -> @start_last_name;
IF NOT $CARRY THEN     CALL string_handler;
Smith, Maurice
375START_LAST_NAME
Scanning UNTIL
SCAN UNTIL searches until it finds the test character or a zero.  The following
example scans INT_ARRAY left to right until it finds a comma or a zero, starting fromthe address stored in START_LAST_NAME by the previous scan.  If any character buta comma stops the scan, the program calls an error-printing procedure:
SCAN start_last_name UNTIL "," -> @comma;
IF $CARRY THEN        CALL invalid_input;
Smith, Maurice
376COMMA
Scanning Right to Left
The following RSCAN example finds the end of the last name.  It scans INT_ARRAY
right to left for a character other than a space or a zero, starting from the locationpreceding the comma.  Because no space separates the end of the last name from thecomma, the scan starts and stops at the same location:
RSCAN comma[-1] WHILE " " -> @end_last_name;
Smith, Maurice
377END_LAST_NAME

Scanning ArraysUsing Arrays
The following SCAN WHILE example finds the offset of the first name from the
beginning of the array.  It scans left to right from the address following the comma,looking for a character other than a space or a zero.  It stops at the beginning of thefirst name and stores that address in the next-address pointer START_FIRST_NAME.The assignment statement then computes the offset and assigns it to OFFSET:
SCAN comma[1] WHILE " " -> @start_first_name;
offset := @start_first_name '-' @sptr;
Smith, Maurice
378START_LAST_NAME SPTR[0]
Computing the Length of a Character String
The following SCAN UNTIL example finds the length of the name contained in the
array.  It scans left to right from the address stored in START_FIRST_NAME by thepreceding scan, looking for a space or a zero.  It stores in END_FIRST_NAME theaddress where the space occurs.  The assignment statement then computes the lengthof the entire name and assigns it to LENGTH:
SCAN start_first_name UNTIL " " -> @end_first_name;
length := @end_first_name '-' @start_last_name;
Smith, Maurice
379START_FIRST_NAME
END_FIRST_NAMESTART_LAST_NAME

Using Standard Functions With ArraysUsing Arrays
comparison expression in a statement.  Group comparison expressions are described inSection 13, “Using Special Expressions.”  Here are some examples.
You can compare an array to a constant list:
STRING an_array[0:3];                   !Declare array!Some code here
IF an_array[0] = ["ABCD"] THEN ... ;    !Compare array to                                        ! constant list
You can compare two arrays:
INT in_array[0:8];                      !Declare array
INT out_array[0:8];                     !Declare array
!Some code here
IF in_array = out_array FOR 9 ELEMENTS THEN ... ;                                        !Compare the arrays
You can use the next address in a group comparison expression:
STRING .sp;                             !Declare next-address
```
                                        ! pointerSTRING .a[0:1] := "AB";                 !Declare arraySTRING .b[0:1] := "AC";                 !Declare array
```
IF b <> a FOR 2 BYTES -> @SP THEN ... ; !SP points to B[1]
Using Standard
Functions With ArraysYou can use the following standard functions to get certain information about arrays,
such as the number of elements in an array:
Standard Function Effect$BITLENGTH Returns the length, in bits, of one array element
$LEN Returns the length, in bytes, of one array element (1 for STRING arrays, 2
for INT arrays, and so forth)
$OCCURS Returns the number of elements in an array$TYPE Returns a value that denotes the data type of an array
For example, you can find the total length of an array as follows:
INT array_length;
INT array[0:2];
array_length := $LEN (array) * $OCCURS (array);

Using Read-Only ArraysUsing Arrays
ArraysA read-only array is an array you cannot modify.  When you declare a read-only array,
the compiler allocates storage for the array in a user code segment.
Declaring
Read-Only ArraysRead-only array declarations differ from other array declarations in a number of ways:
You must specify the read-only array symbol (= 'P') following the array identifier.
You must initialize read-only arrays when you declare them, because you cannot
assign values to read-only arrays by using assignment statements later in yourprogram.
You cannot declare read-only arrays of data type UNSIGNED because you cannotinitialize UNSIGNED arrays.
You cannot declare indirect read-only arrays, because code segments have noprimary or secondary storage areas.
You can omit the array bounds.  The default lower bound is 0; the default upperbound is the number of elements initialized minus one.
For example, you can declare and initialize two read-only arrays, PROMPT and
ERROR, using default bounds:
STRING prompt = 'P' := ["Enter a character: ", 0];INT    error  = 'P' := ["Incorrect input"];
Numeric constants in the constant list should be appropriate for the data type of the
array.
The system uses the program counter (P register) to access read-only arrays.  The P
register contains the address of the next instruction to be executed in the current codesegment.
If you declare a read-only array in a procedure declared with the RESIDENT
procedure attribute, the array is also resident in main memory.  For more informationon the RESIDENT attribute of procedures, see the TAL Reference Manual.
Accessing
Read-Only ArraysYou can access read-only arrays in the same way as you access any other array, except
that:
You cannot modify a read-only array;  that is, you cannot specify a read-only arrayon the left side of an assignment or move operator.
You cannot specify a read-only array on the left side of a group comparisonexpression.
In a SCAN or RSCAN statement, you cannot use next-address  to read the last
character of a string.  You can use next-address  to compute the length of the string.
A procedure can access any global read-only array located in the same 32K-word area
of the code segment.

Using Read-Only ArraysUsing Arrays
STRING read-only arrays located in the lower 32K-word area only by using extendedpointers.  Here is an example:
PROC q (sp, len);
```
    STRING .EXT sp;    INT len;  BEGIN  !Code to print sp[0:len - 1]  END;
```
PROC p;
BEGIN  STRING s = 'P' := "Hello";  STRING .EXT sp := $XADR(s);  LITERAL LEN = 5;  CALL q (sp, len);  END;
A procedure can pass the data of a read-only array only by reference to a procedure
located in the same code segment.
You can copy data from a read-only array into a user data segment array as follows:
STRING message = 'P' := ["** LOAD MAG TAPE #00144"];
STRING .array[0:22];
array ':=' message FOR 23;