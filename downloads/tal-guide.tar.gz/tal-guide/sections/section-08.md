# Section 8: Using Structures

as a group.  Structures contain structure items (fields) such as simple variables, arrays,simple pointers, structure pointers, and nested structures (called substructures).  Thestructure items can be of different data types.
Structures usually contain related data items such as the fields of a file record.  For
example, in an inventory control application, a structure can contain an item number,unit price, and quantity.
Structures can simulate multidimensional arrays, arrays of arrays, or arrays of
structures.
This section describes:
Kinds of structures—definition, template, and referral
Declaring and allocating definition structures
Declaring template structures
Declaring and allocating referral structures
Declaring and allocating structure items
Accessing structure items
Assigning data to structure items
Copying structure data
Kinds of Structures A structure declaration associates an identifier with any of three kinds of structures.
Table 8-1 lists the kinds of structures you can declare.
Table 8-1.  Kinds of Structures
Structure DescriptionDefinition Describes a structure layout and allocates storage for it
Template Describes a structure layout but allocates no storage for it
Referral Allocates storage for a structure whose layout is the same as the layout of a
previously declared structure

Structure LayoutUsing Structures
items.  Table 8-2 lists structure items.
Table 8-2.  Structure Items
Structure Item DescriptionSimple variable A single-element variable
Array A variable that contains multiple elements of the same data type
Substructure A structure nested within a structure (to a maximum of 64 levels)Filler byte A place-holding byteFiller bit A place-holding bitSimple pointer A variable that contains the memory address, usually of a simple variable or
array, which you can access with this simple pointer
Structure pointer A variable that contains the memory address of a structure, which you can
access with this structure pointer
Redefinition A new identifier and sometimes a new description for a substructure, simple
variable, array, or pointer declared in the same structure
You can nest substructures within structures up to 64 levels deep.  That is, you can
declare a substructure within a substructure within a substructure, and so on, for up to64 levels.  The structure and each substructure has a BEGIN-END level depending onthe level of nesting.
The following rules apply to all structure items:
You can declare the same identifier in different structures and substructures, but
you cannot repeat an identifier at the same BEGIN-END level.
You cannot initialize a structure item when you declare it.  After you havedeclared it, however, you can assign a value to it by using an assignment or movestatement.
The following subsections describe how to declare definition, template, referral
structures, and structure items.

Declaring Definition StructuresUsing Structures
StructuresA definition structure describes a structure layout and allocates storage for it.  To
declare a single occurrence of a definition structure, specify:
The keyword STRUCT
The structure identifier , usually preceded by an indirection symbol (. or .EXT)
A semicolon
The structure layout  (enclosed in a BEGIN-END construct)
You can, for example, declare a definition structure named INVENTORY like this:
STRUCT .inventory;              !Declare definition structure
BEGIN                         !Begin structure layout  INT item;  FIXED(2) price;  INT quantity;  END;                          !End structure layout
Specifying Structure
OccurrencesA definition structure that contains multiple occurrences is also known as an array of
structures.  For multiple occurrences, specify the lower and upper bounds  in the
structure declaration.  These bounds represent the indexes of the first and laststructure occurrences you want allocated.  The bounds must be INT constantexpressions in the range –32,768 through 32,767, separated by a colon and enclosed inbrackets.  The default bounds are [0:0] (one structure occurrence).
For example, to declare an array of definition structures that consists of four
occurrences of the structure, specify structure bounds such as [0:3]:
STRUCT .inventory[0:3];         !Declare definition structure
BEGIN                         !Begin structure layout  INT item;  FIXED(2) price;  INT quantity;  END;                          !End structure layout
The size of one occurrence of a structure must not exceed 32,767 bytes.  In the
preceding example, the size of each structure occurrence is 12 bytes.  The size of theentire structure, including all four occurrences, is 48 bytes.
Using Indirection You should use indirection for most global and local structures, because storage areas
for direct global and local variables are limited.  You access indirect structures byidentifier as you do direct structures.
Do not use indirection for sublocal structures, because sublocal storage has no
secondary area.

Declaring Definition StructuresUsing Structures
standard indirection symbol (.):
STRUCT .std_structure;          !Declare standard indirect
BEGIN                         ! definition structure  INT a;                        ! (global or local scope)  INT b;  END;
For very large structures, you should use extended indirection.  When you declare one
or more extended indirect structures (or arrays), the compiler allocates the automaticextended data segment.  If you also must allocate an explicit extended data segment,follow the instructions given in Appendix B, “Managing Addressing.”
To declare an extended indirect structure, precede the structure identifier with the
extended indirection symbol (.EXT):
STRUCT .EXT ext_structure;      !Declare extended indirect
BEGIN                         ! definition structure  INT a;                        ! (global or local scope)  INT b;  END;
Allocating Definition
StructuresThe compiler allocates storage for direct and indirect structures as shown for arrays in
Figures 7-1 and 7-2 in Section 7, “Using Arrays.”  That information is summarized herefor structures.
At the global and local levels, you can declare direct or indirect structures.  At the
sublocal level, you can declare direct structures only.
Direct Structures
For each directly addressed structure, the compiler allocates space in the global, local,
and sublocal primary areas of the user data segment.
Standard Indirect Structures
For each standard indirect structure, the compiler allocates space as follows:1. It allocates a word of storage in the global (or local) primary area of the user data
segment for an implicit standard structure pointer.
2. Next, it allocates storage for the structure in the global (or local) secondary area of
the user data segment.
3. Finally, it initializes the implicit pointer (provided in Step 1) with the 16-bit word
address of the zeroth structure occurrence.

Declaring Definition StructuresUsing Structures
For each extended indirect structure, the compiler allocates space as follows:1. It allocates two words of storage in the global (or local) primary area of the user
data segment for the implicit extended structure pointer.
2. Next, it allocates storage for the structure in the automatic extended data segment.3. Finally, it initializes the implicit pointer (provided in Step 1) with the 32-bit byte
address of the zeroth structure occurrence.
Word Boundaries
The compiler starts the allocation of each structure occurrence on a word boundary,
even if each occurrence contains an odd number of bytes.
For example, the compiler starts structure occurrences A[0] and A[1] on a word
boundary as follows.  (Slashes in the diagram represent compiler-allocated pad bytes.)
STRUCT a_struct[0:1];
BEGIN   INT x;  STRING s;  END;
A_STRUCT[0]
A_STRUCT[1]
380X
S / / /
X
S/ / /
Amount of Allocation
The compiler determines the amount of storage to allocate for the structure data from
the size and number of structure occurrences.  The compiler allocates storage only forthe structure occurrences specified in the bounds of the declaration.
For example, if you declare simple variables A and B, and then declare structure S
with bounds of [1:2], the compiler allocates storage for A, B, S[1], and S[2] as follows.In this case, the zeroth occurrence of S is located at the address of simple variable A:
INT a;
INT b;
STRUCT my_struct[1:2];
BEGIN   INT s_c;  STRING s_d;  END;
381MY_STRUCT[0]
MY_STRUCT[1]MY_STRUCT[2]A
B
S_C
S_D / / /
S_C
S_D / / /
Note When your code later refers to a structure occurrence, the compiler does no bounds checking.  If you
refer to a structure occurrence outside the bounds specified in the declaration, you access data at anaddress outside of the structure.

Declaring Definition StructuresUsing Structures
of StructuresThe zeroth occurrence of a structure must be addressable.  If it is not addressable, the
compiler issues an address range violation error.  (In the following diagrams,parentheses enclose the zeroth occurrence to indicate that it is not addressable.)
Addressability in the User Data Segment
The zeroth occurrence of a direct structure must fit within the lower 32K-word area of
the user data segment, even if the zeroth occurrence is not allocated.
The global area has G-plus addressing.  If a global structure is located at G[0], its lower
bound must be a 0 or negative value.  Avoid the following practice:
G[0]
G[1]ASTR[1]
ASTR[2]
382( ASTR[0] )STRUCT astr[1:2];
BEGIN  INT x;   END;
The sublocal area has S-minus addressing.  If a sublocal structure is located at S[0], its
upper bound must be a 0 or larger value.  Avoid the following practice:
383S[-2]
S[-1]
S[0]BSTR[-3]
BSTR[-1]BSTR[-2]
( BSTR[0] )SUBPROC s;
BEGIN   STRUCT bstr[-3:-1];    BEGIN     INT x;     END;   END;
Addressability in the Extended Segment
The zeroth occurrence of an extended indirect structure must reside within the
extended data segment, even if the zeroth occurrence is not allocated.  If an extendedindirect structure is located at the beginning of the extended data segment, the lowerbound must be a 0 or negative value.  Avoid the following practice:
384%2000000User data segment
G[0]ptr to XSTR
Automatic extended
data segmentXSTR[1]
XSTR[2]( XSTR[0] )STRUCT .EXT xstr[1:2];
BEGIN    INT x;    END;

Declaring Template StructuresUsing Structures
Structures(A template structure declares a structure layout but allocates no storage for it.  You
use the template in subsequent structure, substructure, or structure pointerdeclarations.
To declare a template structure, specify:
The keyword STRUCT
The structure identifier  (with no indirection symbol)
An asterisk enclosed in parentheses
A semicolon
The structure layout  (enclosed in a BEGIN-END construct)
For example, you can declare a template structure named STOCK like this:
STRUCT stock ( *);                !Declare template structure
BEGIN                          !Begin structure layout  INT item;  FIXED(2) price;  INT quantity;  END;                           !End structure layout
A template structure has meaning only when you refer to it in the subsequent
declaration of a referral structure (described next), a referral substructure, or astructure pointer.  The subsequent declaration allocates space for a structure whoselayout is the same as the template layout.

Declaring Referral StructuresUsing Structures
StructuresA referral structure allocates storage for a structure whose layout is the same as that of
a specified structure or structure pointer.
To declare a single occurrence (copy) of a referral structure, specify:
The keyword STRUCT
The structure identifier , usually preceded by an indirection symbol (. or .EXT)
A referral  that provides the structure layout—enclose the identifier of an existing
definition structure, template structure, or structure pointer in parentheses
For example, you can declare referral structure NEW_STRUCT to use the layout of
OLD_STRUCT:
STRUCT .new_struct (old_struct); !Declare referral structure
Specifying Structure
OccurrencesA referral structure that contains multiple occurrences is an array of structures.  To
indicate multiple occurrences, specify the lower and upper bounds  in the structure
declaration.  These bounds represent the indexes of the first and last structureoccurrences you want allocated.  Specify the bounds as INT constant expressions in therange –32,768 through 32,767, separated by a colon and enclosed in brackets.  Thedefault bounds are [0:0] (one structure occurrence).
For example, to declare an array of referral structures that consists of 50 occurrences of
the structure, specify structure bounds such as [0:49].  The following example declares:
A template structure named RECORD
A referral structure named CUSTOMER that uses the layout of RECORD for 50occurrences:
STRUCT record ( *);               !Declare template structure
BEGIN  STRING name[0:19];  STRING addr[0:29];  INT acct;  END;
STRUCT .customer (record) [0:49];
```
                                 !Declare referral structure
```
The size of one occurrence of a structure must not exceed 32,767 bytes.  In the
preceding example, the size of each structure occurrence is 52 bytes.  The size of theentire structure, including all 50 occurrences, is 2,600 bytes.
Using Indirection You should use indirection for most global and local structures, because storage areas
for direct global and local variables are limited.  You access indirect structures byidentifier as you do direct structures.
Do not use indirection for sublocal structures, because sublocal storage has no
secondary area.

Declaring Simple Variables and Arrays in StructuresUsing Structures
standard indirection symbol (.), as shown in the preceding example.
For very large structures, you should use extended indirection.  When you declare one
or more extended indirect structures (or arrays), the compiler allocates the automaticextended data segment.  If you also must allocate an explicit extended data segment,follow the instructions given in Appendix B, “Managing Addressing.”
To declare an extended indirect structure, precede the structure identifier with the
extended indirection symbol (.EXT):
STRUCT record ( *);               !Declare template structure
BEGIN  STRING name[0:19];  STRING addr[0:29];  INT acct;  END;
STRUCT .EXT customer (record) [0:49];
```
                                 !Declare extended indirect                                 ! referral structure
```
Allocating Referral
StructuresThe compiler allocates storage for each referral structure based on the following
characteristics:
The addressing mode and number of occurrences specified in the new declaration
The layout of the previous declaration
In all other ways, allocation of referral structures is the same as for definition
structures, as described earlier in this section.
Addressability of
StructuresThe zeroth occurrence of a structure must always be addressable, as described for
definition structures.
Declaring Simple
Variables and Arrays
in StructuresYou declare simple variables and arrays inside and outside a structure in the same
way, except that inside a structure:
You cannot initialize simple variables or arrays.
You cannot declare indirect arrays or read-only arrays.
You can specify bounds of [ n:n-1]; the array is addressable but uses no memory.
For example, you can declare simple variables and arrays in a structure like this:
STRUCT .record;               !Declare definition structure
BEGIN  STRING name[0:19];          !Declare array  STRING addr[0:29];          !Declare array  INT acct;                   !Declare simple variable  END;
A structure that contains arrays is also known as an array of arrays.

Declaring Simple Variables and Arrays in StructuresUsing Structures
That Use No MemoryIf you declare within a structure an array that has bounds of [ n:n-1], the compiler
places the identifier of the array in the symbol table but allocates no storage for thearray.  You can then apply the array’s data type to subsequent items in the samestructure.
For example, suppose you declare within a structure an INT(32) array that has bounds
of [0:-1], followed by a FIXED variable.  If you then assign 0 to the first element of theINT(32) array, you set the two high-order words of the FIXED variable to 0:
0ARRAY
VARSTRUCT x;
BEGIN    INT(32) array[0:-1];   FIXED(0) var;    END;
x.array[0] := 0D;
Allocating Simple Variables
and Arrays in StructuresThe data type of simple variables and arrays declared within a structure determines
the storage unit that the compiler allocates for the variable or array:
Data Type Storage UnitSTRING Byte
INT Word
INT(32) or REAL DoublewordREAL(64) or FIXED QuadruplewordUNSIGNED Bit sequence of specified width
Alignment of Simple
Variables and ArraysThe compiler aligns and pads simple variables and arrays in structures as follows:
STRING items are byte aligned.
All other items are word aligned.
If a word-aligned item follows a STRING item that ends on an odd byte, the
compiler allocates a pad byte after the STRING item.

Declaring Simple Variables and Arrays in StructuresUsing Structures
VAR2) and STRING arrays (A, B, and C) on byte boundaries.  The compiler allocates apad byte following array C because VAR4 must be word aligned.
STRUCT .padding;
BEGIN   STRING var1;  STRING var2;   INT var3;     STRING a[0:2];   STRING b[0:1];   STRING c[0:3];    INT var4;   END;
386VAR1
VAR3
A[0]
A[2] B[0]
B[1]
C[1] C[2]
C[3]
VAR4VAR2
C[0]
/ / /A[1]
Allocating UNSIGNED Structure Items
The compiler packs the bits of UNSIGNED simple variables and arrays declared inside
a structure in the same way as those declared outside a structure.
For example, the compiler allocates two bits for Y on a word boundary within
structure Z and then then allocates four bits for X in the same word unit.  The compileralso allocates ten pad bits following X because V must be word aligned.
STRUCT .EXT z;
BEGIN        UNSIGNED(2) y;   UNSIGNED(4) x;    INT v;     END;
387X
VY / / /

Declaring SubstructuresUsing Structures
SubstructuresA substructure is a structure embedded within another structure or substructure.  In
general, substructures have the following characteristics:
They must be directly addressed.
They have byte addresses, not word addresses.
They can be nested to a maximum of 64 levels.
They can have bounds of [n: n-1].  Such substructures are addressable but use no
memory.
You can declare definition or referral substructures.
Declaring Definition
SubstructuresA definition substructure declares a layout and allocates storage for it.  To declare a
definition substructure, specify:
The keyword STRUCT
The substructure identifier  (with no indirection symbol)
Optional substructure bounds —the default bounds are [0:0] (one occurrence)
A semicolon
The substructure layout  (the same BEGIN-END construct as for structures)
The substructure layout can contain declarations for simple variables, arrays,
substructures, filler bits, filler bytes, redefinitions, simple pointers, and structurepointers.  The size of one substructure occurrence is the size of the layout, either in oddor even bytes.  The total layout for one occurrence of the encompassing structure mustnot exceed 32,767 bytes.
For example, within definition structure D, you can declare definition substructure
DB.  The length of DB is two bytes;  the length of D is six bytes:
STRUCT .EXT d; !Declare structure D
BEGIN            STRING da;    STRUCT db;   !Declare substructure DB    BEGIN       STRING db1;    STRING db2;    END;       !End DB  !Implicit byte filler  INT dc;  END;         !End D
388DA
DCDB2DB1
/ / /

Declaring SubstructuresUsing Structures
You can nest substructures in a structure to simulate a multidimensional array.The following structure simulates a two-dimensional array.  The structure represents
two warehouses.  The two substructures represent 50 items and ten employees in eachwarehouse.  The substructures are both nested at the second level but contain differentkinds of records:
LITERAL last = 49;               !Declare number of last itemSTRUCT .warehouse[0:1];          !Declare structure WAREHOUSE
BEGIN  STRUCT inventory[0:last];      !Declare substructure    BEGIN                        ! INVENTORY    INT item_number;    INT price;    INT on_hand;    END;                         !End INVENTORY  STRUCT employee[0:9];          !Declare substructure    BEGIN                        ! EMPLOYEE    STRING name[0:31];    STRING telephone[0:6];    END;                         !End EMPLOYEE  END;                           !End WAREHOUSE
The following structure simulates a five-dimensional array.  The structure represents a
corporation that contains three branches.  Each branch contains four divisions.  Eachdivision contains up to six departments.  Each department contains up to six groups.Each group contains up to 20 employees.
STRUCT .corp;                    !Declare structure CORP
BEGIN  STRUCT branch[0:2];            !Declare substructure BRANCH    BEGIN    STRUCT div[0:3];             !Declare substructure DIV      BEGIN      STRUCT dept[0:5];          !Declare substructure DEPT        BEGIN        STRUCT group[0:5];       !Declare substructure GROUP          BEGIN          STRUCT employee[0:19]; !Declare substructure            BEGIN                ! EMPLOYEE            STRING name[0:31];            STRING telephone[0:6];            END;                 !End EMPLOYEE          END;                   !End GROUP        END;                     !End DEPT      END;                       !End DIV    END;                         !End BRANCH  END;                           !End CORP

Declaring SubstructuresUsing Structures
The compiler allocates storage for each substructure when it allocates storage for the
encompassing structure.  The compiler aligns a definition substructure on a byte orword boundary.
Byte Alignment.   A definition substructure is byte aligned if the first item it contains
begins on a byte boundary.
In the following example, definition substructure SUB follows a STRING item (X);  the
first item in SUB is also a STRING item (AA).  Thus, each occurrence of SUB begins ona byte boundary.  After the last occurrence of SUB, the compiler allocates a pad byte,because the next variable, Y, is an INT variable and must begin on a word boundary:
STRUCT struct_one;
BEGIN          STRING x;          STRUCT sub[0:2];   !Byte-aligned SUB     BEGIN          STRING aa;         INT b;          STRING c;       END;             !End SUB     INT y;                    END;
389X
B
C
B
C
B
C
YAA
AA
/ / /AA
Word Alignment.   A definition substructure is word aligned if the first item it contains is
word aligned, including arrays that have bounds of [ n:n-1].  If a word-aligned
substructure has more than one occurrence and contains an odd number of bytes, thecompiler allocates a pad byte after each occurrence.
In the following example, definition substructure SUB starts with INT item A_A.  The
compiler starts each occurrence of SUB on a word boundary, allocating a pad byte ineach unused byte:
STRUCT struct_two;
BEGIN             STRING x;                STRUCT sub [0:1]; !Word-aligned SUB    BEGIN               INT a_a;           INT b;             STRING c;          END;            !End SUB   END;
390X
A_A
B
C/ / /
A_A
B
C/ / /
/ / /SUB[0]
SUB[1]

Declaring SubstructuresUsing Structures
SubstructuresA referral substructure uses the layout of a previously declared structure.  To declare a
referral substructure, specify:
The keyword STRUCT
The substructure identifier  (with no indirection symbol)
A referral  that provides a layout—enclose in parentheses the identifier of an
existing structure (except the encompassing structure) or structure pointer
Optional substructure bounds —the default bounds are [0:0] (one occurrence)
In the following example, referral substructure REF_SUB uses the body of structure
STRUCT_TWO from the preceding example:
STRUCT .EXT struct_three;
BEGIN  INT a;  STRUCT ref_sub (struct_two) [0:2];    !Declare REF_SUB  END;
Allocating Referral SubstructuresThe compiler allocates storage for a referral substructure when it allocates storage for
the encompassing structure.  The compiler allocates the storage based on:
The addressing mode and number of occurrences specified in the new declaration
The layout of the previous declaration
A referral substructure always begins on a word boundary.  If the substructure
contains an odd number of bytes, the compiler appends a pad byte to each occurrenceof the substructure.
The following example shows how the compiler aligns referral substructure ABC on a
word boundary, allocating a pad byte in each unused byte:
STRUCT template (*);
BEGIN                STRING a[0:2];      INT    b;          STRING c;          END;
STRUCT .indirect_structure;
BEGIN                 INT    header[0:1];    STRING abyte;                 STRUCT abc (template) [0:1];            !Referral substructure   END;
391ABYTE / / /HEADER[0]
HEADER[1]
A[0] A[1]
A[2]
B
C / / // / /
A[0] A[1]
A[2]
B
C / / // / /ABC[0]
ABC[1]

Declaring FillersUsing Structures
You cannot access filler locations.
You can use filler items to allocate space within a structure when the structure layout
must match a structure layout defined by another program.  The new structuredeclaration need only include data items used by your program.  You can use filleritems for the unused data.
You can use filler declarations to produce clearer source code.  For example, you can:
Document pad bytes or bits that would otherwise be inserted by the compiler
Provide place holders for unused space in the structure
The compiler allocates space for each byte or bit you specify in a filler declaration.  If
the alignment of the next data item requires additional pad bytes or bits, the compilerallocates those also.
Declaring Filler Bytes You declare filler bytes within a structure by specifying the number  of filler bytes as a
constant expression in the range 0 through 32,767 as follows:
FILLER 5;
You can use filler byte declarations to document unused bytes in a structure:
LITERAL last = 11;          !Last occurrenceSTRUCT .x[1:last];
BEGIN  STRING byte[0:2];  FILLER 1;                 !Document word-alignment pad byte  INT word1;  INT word2;  INT(32) integer32;  FILLER 30;                !Place holder for unused space  END;
Declaring Filler Bits You declare filler bits within a structure by specifying the number  of filler bits as a
constant expression in the range 0 through 255 as follows:
BIT_FILLER 5;
You can use filler bit declarations to document unused bits in a structure:
STRUCT .flags;
BEGIN  UNSIGNED(1) flag1;  UNSIGNED(1) flag2;  UNSIGNED(2) state;        !State = 0, 1, 2, or 3  BIT_FILLER 12;  END;

Declaring Simple Pointers in StructuresUsing Structures
Pointers in StructuresYou can declare simple pointers within a structure.  A simple pointer is a variable in
which you store the memory address, usually of a simple variable or array, which youcan access with this pointer.  The compiler allocates space for the pointer but not forthe data to which the pointer points.
Simple pointers can be standard or extended:
Standard (16-bit) pointers can access addresses in the current user data segment.
Extended (32-bit) pointers can access addresses in any segment, normally the
automatic extended data segment.
To declare a simple pointer inside a structure, specify:
Any data type  except UNSIGNED
The simple pointer identifier , preceded by an indirection symbol (. or .EXT)
For example, you can declare STD_POINTER and EXT_POINTER inside
MY_STRUCT:
STRUCT my_struct;
BEGIN  FIXED .std_pointer;         !Standard simple pointer  STRING .EXT ext_pointer;    !Extended simple pointer  END;
The data type determines how much data a simple pointer can access at a time, as
listed in Table 8-3.
Table 8-3.  Data Accessed by Simple Pointers
Data Type Accessed DataSTRING Byte
INT Word
INT(32) DoublewordREAL DoublewordREAL(64) QuadruplewordFIXED Quadrupleword

Declaring Simple Pointers in StructuresUsing Structures
Pointers Can ContainThe addressing mode and data type of a simple pointer determines the kind of address
the pointer can contain, as described in Table 8-4.
Table 8-4.  Addresses in Simple Pointers
Addressing Mode Data Type Kind of Addresses
Standard STRING 16-bit byte address in the lower 32K-word area of the user data
segment.
Standard Any except
STRING16-bit word address anywhere in the user data segment.
Extended STRING 32-bit byte address, normally in the automatic extended data
segment.
Extended Any except
STRING32-bit even-byte address, normally in the automatic extended
data segment.  (If you specify an odd-byte address, the resultsare undefined.)
Allocating Simple
Pointers in StructuresThe compiler allocates storage for simple pointers declared within structures when it
allocates the encompassing structure.  It allocates one word for each standard pointerand one doubleword for each extended pointer.  The storage area depends on thescope and addressing mode of the encompassing structure.
The compiler does not allocate space for the data to which the pointer points.  You can
store addresses of previously declared items in pointers as described in “AssigningAddresses to Pointers in Structures” later in this section.  Otherwise, you must managethe allocation of the data to which the pointer points, as described in Appendix B,“Managing Addressing.”

Declaring Structure Pointers in StructuresUsing Structures
Pointers in StructuresYou can declare structure pointers within a structure or substructure.  A structure
pointer is a variable in which you store the memory address of a structure, which youcan access with this structure pointer.  The compiler allocates space for the pointer butnot for the data to which the pointer points.
Structure pointers can be standard or extended:
Standard (16-bit) pointers can access addresses in the current user data segment.
Extended (32-bit) pointers can access addresses in any segment, normally the
automatic extended data segment.
To declare a structure pointer, specify:
STRING or INT attribute as described in Table 8-5
The structure pointer identifier , preceded by an indirection symbol (. or .EXT)
A referral  that provides the structure layout—enclose in parentheses the identifier
of an existing structure or structure pointer or of the encompassing structure
The following example declares STRUCT_A and STRUCT_B.   STRUCT_B contains a
declaration for STRUCT_PTR, whose layout is the same as the layout of  STRUCT_A:
STRUCT struct_a;                  !Declare STRUCT_A
BEGIN  INT a;  INT b;  END;
STRUCT struct_b;                  !Declare STRUCT_B
BEGIN  INT .EXT struct_ptr (struct_a); !Declare STRUCT_PTR  STRING a;  END;

Declaring Structure Pointers in StructuresUsing Structures
Pointers Can ContainThe addressing mode and STRING or INT attribute of a structure pointer determine
the kind of addresses the pointer can contain, as described in Table 8-5.
Table 8-5.  Addresses in Structure Pointers
Addressing
ModeSTRING or
INT Attribute Kind of Addresses
Standard STRING *16-bit byte address of a substructure, STRING simple variable, or
STRING array declared in a structure located in the lower 32K-wordarea of the user data segment
Standard INT  **16-bit word address of any structure data item located anywhere in
the user data segment
Extended STRING *32-bit byte address of any structure data item located in any
segment, normally the automatic extended data segment
Extended INT **32-bit byte address of any structure data item located in any
segment, normally the automatic extended data segment
*If the pointer is the source  in a move statement or group comparison expression that omits a
count-unit , the count-unit  is BYTES.
**If the pointer is the source  in a move statement or group comparison expression that omits a
count-unit , the count-unit  is WORDS.
Allocating Structure
Pointers in StructuresThe compiler allocates storage for structure pointers declared within structures when
it allocates the encompassing structure.  It allocates one word for each standardpointer and one doubleword for each extended pointer.  The storage area depends onthe scope and addressing mode of the encompassing structure.
The compiler does not allocate space for the data to which the pointer points.  You can
store addresses of previously declared items in pointers as described in “AssigningAddresses to Pointers in Structures” later in this section.  Otherwise, you must managethe allocation of the data to which the pointer points, as described in Appendix B,“Managing Addressing.”

Declaring RedefinitionsUsing Structures
RedefinitionsA redefinition declares a new identifier and sometimes a new description for a
previously declared item in the same structure.  The new item or the previous item canbe a simple variable, array, pointer, or substructure.
The new item must be at the same BEGIN-END level in a structure as the previous
item.  The new item must also be of the same length or shorter than the previous item.
The subsections that follow describe how you declare and access redefinitions.  Some
examples include diagrams that show how a redefinition relates to the previous item.In each diagram:
The shaded box represents the previous item (the allocated item).
The unshaded box represents the new item (the redefinition).
Unless otherwise noted, the diagrams refer to memory locations in the primary area of
the user data segment.  Here is an example diagram:
393A[2]
A[4]B[1]B[3]A[3]
B[0]B[2]
/ / /C[1]
DA[0] A[1] C[0] STRUCT array_redefinition;
BEGIN               STRING a[0:4];      STRING b[0:3];     INT c[0:1] = a;   STRING d = b;    END;
Simple Variables or
Arrays as RedefinitionsTo declare a new simple variable or array that redefines a previous item within the
same structure, specify:
Any data type  (except UNSIGNED)
The identifier  of the new simple variable or array
For an array, its bounds —if you omit the bounds, the default bounds are [0:0] (one
element)
An equal sign (=)
The identifier of a previous item  at the same BEGIN-END level of a structure—the
previous item can be a simple variable, array, pointer, or substructure
For example, you can declare NEW_VAR to redefine OLD_VAR as follows:
STRUCT simple_variable_redefinition;
BEGIN  INT old_var;  STRING new_var = old_var;                !Redefinition  END;

Declaring RedefinitionsUsing Structures
STRUCT dw_template ( *);
BEGIN  INT(32) .dw_mem;  INT dw_addr = dw_mem;                    !Redefinition  END;
Even if the lower bound of the new array is not zero, the new specified lower bound is
always associated with the zeroth element of the previous array.  In the followingexample, new INT(32) array B[1:2] redefines previous INT array A[0:3]:
392A[-2]
.
..A[-1]
A[0]A[1]A[2]A[3] B[1]
B[2]STRUCT .array_redefinition;
BEGIN                     INT a[-2:3];           INT(32) b[1:2] = a;   END;
Data Type Restrictions
The new item can be any data type except UNSIGNED.You can redefine the data type of a STRING array only if the array is aligned on a
word boundary.  For example, you can redefine the data type of STRING array A,because A is aligned on a word boundary.  You cannot redefine the data type ofSTRING array B because B is aligned on a byte boundary, but you can declare anotherSTRING item (such as D) to redefine B:
393A[2]
A[4]B[1]B[3]A[3]
B[0]B[2]
/ / /C[1]
DA[0] A[1] C[0] STRUCT array_redefinition;
BEGIN               STRING a[0:4];      STRING b[0:3];     INT c[0:1] = a;   STRING d = b;    END;
Byte and Word Addressing
In a redefinition, the new variable and the previous (nonpointer) variable both must
have a byte address or both must have a word address.  If the previous variable is apointer, the data it points to must be word or byte addressed to match the newvariable.

Declaring RedefinitionsUsing Structures
as RedefinitionsTo declare a definition substructure that redefines a previously declared item within
the same structure, specify:
The keyword STRUCT
The identifier  of the new substructure
Optional bounds —if you omit the bounds, the default bounds are [0:0] (one
occurrence)
An equal sign (=)
The identifier of a previous item  at the same BEGIN-END level of the encompassing
structure—the previous item can be a simple variable, array, pointer, orsubstructure
A semicolon
The substructure layout  (the same BEGIN-END construct as for structures)
If the previous item is a substructure and you omit the bounds or if either bound is 0,
the new substructure and the previous substructure occupy the same space and havethe same offset from the beginning of the structure.
For example, you can declare new substructure INITIALS to redefine substructure
WHOLE_NAME as follows:
STRUCT .name_record;
BEGIN  STRUCT whole_name;   !Declare WHOLE_NAME    BEGIN    STRING first_name[0:10];    STRING middle_name[0:10];    STRING last_name[0:15];    END;  STRUCT initials = whole_name;    BEGIN              !Redefine WHOLE_NAME as INITIALS    STRING first_initial;    FILLER 10;    STRING middle_initial;    FILLER 10;    STRING last_initial;    FILLER 15;    END;  END;

Declaring RedefinitionsUsing Structures
variable V to redefine substructure SS as follows:
STRUCT .st;
BEGIN  INT a[0:1];           !Declare array A  STRUCT ss = a;        !Redefine A as substructure SS    BEGIN    INT x;    INT y;    END;  INT(32) v = ss;       !Redefine SS as V  END;
Size of Substructure Redefinitions
The new substructure must be of the same size or smaller than the previous item:
394NUM STR / / /SUB1 SUB2STRUCT str;
BEGIN  STRUCT sub1;         !Declare SUB1    BEGIN    INT num;    END;  STRUCT sub2 = sub1;  !Redefine SUB1 as SUB2    BEGIN                  STRING str;    END;     END;
If the new substructure is larger than the previous item, the compiler issues a warning:
STRUCT str2;
BEGIN  STRUCT sub1;         !Declare SUB1    BEGIN    STRING str1;    END;  STRUCT sub2 = sub1;  !Redefine SUB1 as SUB2, which is    BEGIN              ! larger; compiler issues warning    INT int1;    END;        END;
STR1 / / / INT1
395SUB1 SUB2

Declaring RedefinitionsUsing Structures
The new substructure must have the same byte or word alignment as the previous
substructure.  That is, if the previous substructure starts on an odd byte, the first itemin the new substructure must be a STRING item.
The following substructures (B and C) both begin on an odd-byte boundary:
STRUCT a;
BEGIN  STRING x;  STRUCT b;        !B starts on odd byte    BEGIN    STRING y;    END;  STRUCT c = b;    !Redefine B as C, also on odd byte    BEGIN    STRING z;      END;   END;
XY
396 / / / ZC B
Referral Substructures
as RedefinitionsTo declare a referral substructure that redefines a previously declared item within the
same structure, specify:
The keyword STRUCT
The identifier  of the new substructure
A referral  that provides a layout—enclose in parentheses the identifier of an
existing structure (except the encompassing structure) or structure pointer
Optional bounds —if you omit the bounds, the default bounds are [0:0] (one
occurrence)
An equal sign (=)
The identifier of a previous item  at the same BEGIN-END level of the structure—the
previous item can be a simple variable, array, pointer, or substructure
A semicolon
If the previous item is a substructure and you omit the bounds or if either bound is 0,
the new substructure and the previous substructure occupy the same space and havethe same offset from the beginning of the structure.

Declaring RedefinitionsUsing Structures
structure layout:
STRUCT temp( *);              !Declare template structure
BEGIN  STRING a[0:2];  INT    b;  STRING c;  END;
STRUCT .ind_struct;          !Declare definition structure
BEGIN  INT    header[0:1];  STRING abyte;  STRUCT abc(temp) [0:1];    !Declare ABC  STRUCT xyz(temp) [0:1] = abc;                             !Redefine ABC as XYZ  END;
Simple Pointers
as RedefinitionsTo declare a simple pointer that redefines a previously declared item within the same
structure, specify:
Any data type  except UNSIGNED
The identifier  of the new pointer, preceded by an indirection symbol (. or .EXT)
An equal sign (=)
The identifier of a previous item  at the same BEGIN-END level of the structure—a
simple variable, array, pointer, or substructure
For example, you can declare new simple pointer EXT_POINTER to redefine simple
variable VAR as follows:
STRUCT my_struct;
BEGIN  STRING var[0:5];  STRING .EXT ext_pointer = var;             !Redefinition  END;
Structure Pointers
as RedefinitionsTo declare a structure pointer that redefines a previously declared item within the
same structure, specify:
STRING or INT attribute, as described in Table 8-5 earlier in this section
The identifier  of the new pointer, preceded by an indirection symbol (. or .EXT)
A referral  that provides the structure layout—enclose in parentheses the identifier
of an existing structure or structure pointer or of the encompassing structure
An equal sign (=)
The identifier of a previous item  at the same BEGIN-END level of the structure—a
simple variable, array, pointer, or substructure

Accessing Structure ItemsUsing Structures
redefine simple variables as follows:
STRUCT record;
BEGIN  FIXED(0) data;  INT std_link_addr;  INT .std_link(record) = std_link_addr;     !Redefinition  INT ext_link_addr;  INT .EXT ext_link(record) = ext_link_addr; !Redefinition  END;
Accessing
Structure ItemsYou access an item in a definition or referral structure by using the item’s fully
qualified identifier in a statement.  Structure items you can access are simple variables,arrays, substructures, pointers, and redefinitions.  For example, you can:
Assign a value to a structure item by using an assignment statement
Copy substructure values within a structure by using a move statement
Qualifying Identifiers To access a structure item, you must specify its fully qualified identifier and indexes if
any.  A fully qualified identifier includes all levels of nesting.  For example, the fullyqualified identifier for ARRAY_Z declared in SUBSTRUCT_Y in STRUCT_X is:
struct_x.substruct_y[0].array_z[0]
The following example shows how nesting affects qualified identifiers.  The two
structures both contain three substructures.  In both cases, SUB_3 contains ITEM_X:
STRUCT .struct_a;             STRUCT .struct_b;
BEGIN                         BEGIN  STRUCT sub_1;                 STRUCT sub_1;    BEGIN                         BEGIN    INT a;                        STRUCT sub_2;    END; !End SUB_1                 BEGIN  STRUCT sub_2;                     STRUCT sub_3;    BEGIN                             BEGIN    INT b;                            INT a;    END; !End SUB_2                   INT b;  STRUCT sub_3;                       INT item_x ;
```
    BEGIN                             END; !End SUB_3    INT item_x ;                     END; !End SUB_2
    END;  !End SUB_3              END; !End SUB_1  END; !End STRUCT_A            END; !End STRUCT_A
```
For STRUCT_A, the fully qualified identifier for ITEM_X is:
struct_a.sub_3.item_x
For STRUCT_B, the fully qualified identifier for ITEM_X is:
struct_b.sub_1.sub_2.sub_3.item_x
You can use a DEFINE declaration to associate alternate names for structure items, as
described in Section 5, “LITERALs and DEFINEs,” in the TAL Reference Manual.

Accessing Structure ItemsUsing Structures
to the various levels in the qualified identifier of the structure item.  For example, youcan access an array element in a particular structure and substructure occurrence byappending indexes as follows:
my_struct[1].my_substruct[0].my_array[4]
Each index represents an offset from the zeroth occurrence of a structure or
substructure and the zeroth element of the array, respectively, regardless of thedeclared lower bounds.
The indexed item determines the size of the index offset, as listed in Table 8-6:
Table 8-6.  Indexing Structures
Indexed Item Data Type Size of Index OffsetStructure or structure pointer Not applicable Total bytes in one structure occurrence
Substructure Not applicable Total bytes in one substructure
occurrence
Simple variable or array STRING ByteSimple variable or array INT WordSimple variable or array INT(32) or REAL DoublewordSimple variable or array REAL(64) or FIXED Quadrupleword
Indexing Standard Indirect Structures
The index for standard indirect structures must be a signed INT arithmetic expression
in the range –32,768 through 32,767.  The offset of a structure item is from the zerothstructure occurrence (not the current structure occurrence).  Here are examples ofsigned INT arithmetic expressions:
indexindex + 2index – 19 * index

Accessing Structure ItemsUsing Structures
STRUCT .std_struct[0:99]; !Standard indirect structure
BEGIN  INT var;                !Simple variable  STRING array[0:25];     !Array  STRUCT substr[0:9];     !Substructure    BEGIN    STRING array[0:25];   !Array    END;  END;
INT index := 5;           !Simple variablePROC x MAIN;              !Declare procedure X
BEGIN  std_struct[index].var := 35;                          !Access STD_STRUCT[5].VAR
std_struct[index+2].array[0] := "A";
```
                          !Access STD_STRUCT[7].ARRAY[0]
```
std_struct[index+2].array[25] := "Z";
```
                          !Access STD_STRUCT[7].ARRAY[25]
```
std_struct[9*index].substr[index-1].array[index-5] := "a";
```
                          !Access                          ! STD_STRUCT[45].SUBSTR[4].ARRAY[0]  END;                    !End procedure X
```

Accessing Structure ItemsUsing Structures
The index for extended indirect structures must be a signed INT or INT(32) arithmetic
expression, depending on the size of the offset of the structure item you want toaccess.  The offset of a structure item is from the zeroth structure occurrence (not thecurrent structure occurrence).
C-Series System.   If you are writing a program to run on a C-series system, you can
determine whether to use an INT index or an INT(32) index (which is slower) asfollows:
1. Compute the lower and upper byte or word offsets of the structure item whose
extended indirect structure is being indexed.  (A byte-addressed structure item isat a byte offset.  A word-addressed structure item is at a word offset.)
2. If the offsets are inside the signed INT range (–32,768 through 32,767), use a signed
INT index.  Usually, offsets are within the signed INT range.
3. If the offsets are outside the signed INT range, use an INT(32) index.  To convert
an INT index to an INT(32) index, use $DBL, a standard function.
Whenever you increase the structure size or number of occurrences, you must repeat
the preceding sequence.
To access a structure item whose offset is inside the signed INT range, you can use an
INT index as follows:
STRUCT .EXT xstruct[0:9];      !Declare extended indirect
BEGIN                        ! structure; upper byte offset  STRING array[0:9];           ! is within INT range  END;
INT index;                     !Declare INT index
STRING var;
PROC my_proc MAIN;
BEGIN  !Code to initialize INDEX  var := xstruct[index].array[0];  END;                         !Generate correct offset
In the preceding example, if the default NOINHIBITXX directive is in effect, the
compiler generates efficient addressing (by using XX instructions described in theSystem Description Manual  for your system).
Conversely, INHIBITXX suppresses efficient addressing of extended indirect
declarations located between G[0] and G[63] of the user data segment—except whenthe extended indirect declarations are declared in a BLOCK declaration with theAT (0) or BELOW (64) option.  (The BLOCK declaration is described in Section 14,“Compiling Programs.”)

Accessing Structure ItemsUsing Structures
through 32,767), you must use an INT(32) index.  To convert an INT index to anINT(32) index, you can use the $DBL standard function:
STRUCT .EXT xstruct[0:9999];
BEGIN  STRING array[0:9];           !Upper byte offset > 32,767;  END;                         ! INT(32) index required
INT index;PROC my_proc MAIN;
BEGIN  !Some code here to initialize INDEX
xstruct[$DBL(index)].array[0] := 1;
```
                               !Generate correct offset  END;                         ! because INDEX is an INT(32)                               ! expression
```
In the preceding example, the upper-byte offset of ARRAY is larger than 32,767,
computed as follows:
9999 * 10 + 9 = 99999
Upper bound of array
Size of structure in bytes
Upper bound of structureSize of offset to ARRAY[9]

Accessing Structure ItemsUsing Structures
index into extended indirect structures, you can either:
Determine when to use a signed INT or INT(32) index as described for C-seriesprograms in the preceding subsection.
Use the INT32INDEX directive, which is easier and safer, albeit slightly lessefficient.
INT32INDEX generates INT(32) indexes from INT indexes and computes the correct
offset for the indexed structure item.  INT32INDEX overrides the INHIBITXX orNOINHIBITXX directive, whichever is in effect.
NOINT32INDEX, the default, generates incorrect offsets for structure items whose
offsets are outside the signed INT range.  NOINT32INDEX does not overrideINHIBITXX or NOINHIBITXX.
Specify INT32INDEX or NOINT32INDEX immediately before the declarations to
which it applies.  The specified directive then applies to those declarations throughoutthe compilation.  The following D-series example shows how INT32INDEX generatescorrect offsets and NOINT32INDEX generates incorrect offsets:
?INT32INDEX                !Assign INT32INDEX attribute
```
                           ! to subsequent declaration
```
STRUCT .EXT xstruct[0:9999];
BEGIN                    !XSTRUCT has INT32INDEX  STRING array[0:9];       ! attribute  END;
INT index;PROC my_proc MAIN;
BEGIN?NOINT32INDEX              !Assign NOINT32INDEX attribute to                           ! subsequent declaration
STRUCT .EXT xstruct2 (xstruct) := @xstruct[0];
```
                           !XSTRUCT2 has NOINT32INDEX                           ! attribute
```
xstruct[index].array[0]:= 1;
```
                           !Generate correct offset even                           ! when offset is greater than                           ! 32,767, because XSTRUCT                           ! has INT32INDEX attribute
```
xstruct2[index].array[0] := 1;
```
                           !Generate incorrect offset if                           ! offset is greater than 32,767,                           ! because XSTRUCT2 has  END;                     ! NOINT32INDEX attribute
```

Accessing Structure ItemsUsing Structures
The allowed offset of a standard indirect structure item is greater than that of an
extended indirect structure item.  The following example declares a standard indirectstructure item accessed by an index that is greater than that allowed for an extendedindirect structure item:
LITERAL ub = 32759;STRUCT .t[0:ub];           !Standard indirect structure
BEGIN  STRING x, y;  END;
PROC m MAIN;
BEGIN  INT index;  FOR index := 0 TO ub DO    t[index].x := t[index].y := 0;  END;
If you change the preceding standard indirect structure to an extended indirect
structure, you must also change the index that is applied to the structure item to anINT(32) index:
LITERAL ub = 32759;STRUCT .EXT t[0:ub];       !Extended indirect structure
BEGIN  STRING x, y;  END;
PROC m MAIN;
BEGIN  INT index;  FOR index := 0 TO ub DO    BEGIN    t[index].x := t[index].y := 0;                           !Compiler generates incorrect code
```
    t[$DBL(index)].x := t[$DBL(index)].y := 0;
                           !Compiler generates correct code    END;  END;
```

Accessing Structure ItemsUsing Structures
Structure ItemsYou assign a value to a structure item by using its fully qualified identifier in an
assignment statement.  For example, the assignment statement for assigning anexpression to simple variable VAR declared in SUBSTRUCT_A in STRUCT_B is:
struct_b.substruct_a.var := any_expression;
Here are examples.  You can assign a value to VAR3 in DEF_STRUCT:
STRUCT .def_struct;             !Declare definition structure
BEGIN  FIXED  var1;  STRING var2;  INT    var3;  END;
PROC a MAIN;
BEGIN  def_struct.var3 := 45;        !Assign 45 to DEF_STRUCT.VAR3  END;
You can assign a value to BEAN[2] in REF_STRUCT:
STRUCT template_struct ( *);     !Declare template structure
BEGIN  REAL deal;  STRING bean[0:2];  END;
STRUCT .ref_struct (template_struct);
```
                                !Declare referral structure
```
PROC b MAIN;
BEGIN  ref_struct.bean[2] := 92;     !Assign 92 to  END;                          ! REF_STRUCT.BEAN[2]
You can assign a value to ARRAY[5] in SUBST[3] in STRUCT:
STRUCT .struc;                  !Declare definition structure
BEGIN  INT foo;  STRUCT subst[0:99];    BEGIN    REAL var;    INT array[0:9];    END;  END;
PROC c MAIN;
BEGIN  struc.subst[3].array[5] := 8; !Assign 8 to  END;                          ! STRUC.SUBST[3].ARRAY[5]

Accessing Structure ItemsUsing Structures
Pointers in StructuresYou can assign to pointers the kinds of addresses listed in Tables 8-4 and 8-5 earlier in
this section.  To assign an address to a pointer within a structure, specify the fullyqualified pointer identifier in an assignment statement.  Prefix the structure identifierwith @.  For example, the assignment statement to assign an address to PTR_Xdeclared in SUBSTRUCT_A in STRUCT_B is:
@struct_b.substruct_a.ptr_x := arith_expression;
In the preceding example, @ applies to PTR_X, the most qualified item.  On the left
side of the assignment operator, @ changes the address contained in the pointer, notthe value of the item to which the pointer points.
You can also prefix @ to a variable on the right side of the assignment operator.  If the
variable is a pointer, @ returns the address contained in the pointer.  If the variable isnot a pointer, @ returns the address of the variable itself.
The following example shows @ used on both sides of the assignment operator.  This
example assigns the address of ARRAY to STD_PTR within a structure.  Also, the$XADR function converts the standard address of ARRAY to an extended address,which is then assigned to an extended simple pointer:
INT .array[0:99];             !Declare ARRAYSTRUCT .st;                   !Declare ST
BEGIN  INT .std_ptr;               !Declare STD_PTR  INT .EXT ext_ptr;           !Declare EXT_PTR  END;
PROC e MAIN;
BEGIN  @st.std_ptr := @array[0];   !Assign standard address of                              ! ARRAY[0] to ST.STD_PTR
@st.ext_ptr := $XADR(array[0]);
```
                              !Assign extended address of  END;                        ! ARRAY[0] to ST.EXT_PTR
```

Accessing Structure ItemsUsing Structures
in another structure:
STRUCT .s1;                      !Declare S1
BEGIN  INT var1;  INT var2;  END;
STRUCT .s2;                      !Declare S2
BEGIN  INT .std_ptr (s1);             !Declare STD_PTR  INT .EXT ext_ptr (s1);         !Declare EXT_PTR  END;
PROC g MAIN;
BEGIN  @s2.std_ptr := @s1[0];         !Assign standard address                                 ! of S1 to S2.STD_PTR
@s2.ext_ptr := $XADR(s1);      !Assign extended address
END;                           ! of S1 to S2.EXT_PTR
Accessing Data Through
Pointers in StructuresAfter you declare a pointer inside a structure and assign an address to it, you can use
assignment statements to access the data to which the pointer points:
INT .array[0:99];                !Declare ARRAY
STRUCT .st;                      !Declare ST  BEGIN  INT .std_ptr;                  !Declare STD_PTR  INT .EXT ext_ptr;              !Declare EXT_PTR  END;
PROC h MAIN;
BEGIN  @st.std_ptr := @array[0];      !Assign word address of                                 ! ARRAY[0] to St.STD_PTR
@st.ext_ptr := $XADR(array[1]);!Assign extended address of
```
                                 ! ARRAY[1] to ST.EXT_PTR
```
array[2] := st.std_ptr;        !Assign content of
```
                                 ! ARRAY[0] to ARRAY[2]
```
st.ext_ptr := array[3];        !Assign content of ARRAY[3]
END;                           ! to ARRAY[1]

Accessing Structure ItemsUsing Structures
pointers declared in S2 point:
INT .a[0:99];                    !Declare array A
STRUCT .s3;                      !Declare S3  BEGIN  INT b[0:99];                   !Declare array B  END;STRUCT .s2;                      !Declare S2  BEGIN  INT .std_ptr (s3);             !Declare STD_PTR  INT .EXT ext_ptr (s3);         !Declare EXT_PTR  END;
PROC i MAIN;
BEGIN  @s2.std_ptr := @s3;            !Assign standard address                                 ! of S3 to S2.STD_PTR
@s2.ext_ptr := $XADR(s3);      !Assign extended address
```
                                 ! of S3 to S2.EXT_PTR
```
a[1] := s2.std_ptr.b[1];       !Assign content of
```
                                 ! S3.B[1] to A[1]
```
s2.ext_ptr.b[2] := a[2];       !Assign content of A[2]
END;                           ! to S3.B[2]

Accessing Structure ItemsUsing Structures
pointers declared in structures:
STRUCT template ( *);        !Declare template structure
BEGIN  STRING b[0:2];  INT    e;  END;
STRUCT .link_list;          !Declare definition structure
BEGIN  INT .fwd_ptr (link_list); !Declare structure pointer and                            ! redefine simple variable  STRING .EXT ptr_to_ext_item(template);                            !Declare structure pointer  INT(32) .b;               !Declare simple pointer  STRUCT item(template);    !Declare referral substructure  END;
INT .new_item := %100000;   !Declare simple pointer to
```
                            ! first list itemPROC m MAIN;  BEGIN  @link_list.fwd_ptr := @new_item;                            !Put address into first forward                            ! pointer  @new_item := @new_item '+' ($LEN(link_list) + 1 ) / 2;  @link_list.fwd_ptr.fwd_ptr := @new_item;                            !Put address into second forward  END;                      ! pointer
```
In the preceding example:
@LINK_LIST.FWD_PTR refers to the content of the first forward standard simple
pointer.
@LINK_LIST.FWD_PTR.PTR_TO_EXT_ITEM refers to the content of the extendedsimple pointer in the second LINK_LIST.
@LINK_LIST.FWD_PTR.PTR_TO_EXT_ITEM.B refers to the address of B in thesecond instance of LINK_LIST in extended memory.

Accessing Structure ItemsUsing Structures
copy:
Structure occurrences between structures
Structure occurrences within a structure
Substructure occurrences between structures
Structure items
To start copying from the lower occurrence, use the left-to-right move operator (':=').
To start copying from the upper occurrence, use the right-to-left move operator ('=:').
Copying Structure Occurrences Between Structures
To copy structure occurrences from one structure to another, specify in a move
statement:
A destination  structure and a source  structure
The FOR clause including the ELEMENTS qualifier
For example, you can copy three occurrences of a source structure to a destination
structure as follows:
LITERAL copies = 3;              !Number of occurrencesSTRUCT .s_struct[0:copies - 1];  !Source structure
BEGIN  INT a;  INT b;  INT c;  END;
STRUCT .d_struct (s_struct) [0:copies - 1];
```
                                 !Destination structure
```
PROC j;
BEGIN  d_struct ':=' s_struct FOR copies ELEMENTS;                                 !Move statement copies three  END;                           ! structure occurrences
If you do not specify ELEMENTS, the equivalent move statement is:
d_struct ':=' s_struct FOR copies
```
                     * (($LEN(s_struct) + 1) '>>' 1) WORDS;
```
which is the code that the compiler generates in this case.  The standard function $LEN
returns the length in bytes of one occurrence of S_STRUCT.

Accessing Structure ItemsUsing Structures
To copy occurrences within a structure, specify in a move statement:
The same structure for destination  and source
The FOR clause including the ELEMENTS qualifier
For example, you can copy the data in each occurrence of a structure one occurrence to
the right, beginning with occurrence [8], thus freeing occurrence [0] for new data.
LITERAL last = 9;       !Last occurrenceSTRUCT t_struct( *);     !Template structure
BEGIN  INT i;  INT j;  END;
STRUCT .s_struct (t_struct) [0:last];
```
                        !Source and destination structurePROC k;  BEGIN  s_struct[last] '=:' s_struct[last-1] FOR last ELEMENTS;                        !Move nine structure occurrences  END;
```
Copying Substructure Occurrences Between Structures
To copy occurrences of a substructure between structures, specify in a move statement:
The fully qualified identifiers of the destination and source substructures
The FOR clause including the ELEMENTS qualifier
You can copy three substructure occurrences from one structure to another as follows:
LITERAL copies = 3;     !Number of occurrencesSTRUCT .s_struct;
BEGIN  STRUCT s_sub[0:copies - 1];    BEGIN               !Source S_SUB is in S_STRUCT    INT a;    INT b;    END;  END;
STRUCT .d_struct (s_struct);
```
                        !Destination S_SUB is in D_STRUCT
```
PROC m;
BEGIN  d_struct.s_sub ':=' s_struct.s_sub FOR copies ELEMENTS;                        !Byte move of three  END;                  ! substructure occurrences

Accessing Structure ItemsUsing Structures
You can use a move statement to copy structure items within and between structures
and substructures.  Structure items you can copy are simple variables, arrays, andpointers declared within structures or substructures.
For example, to copy an array from one structure to another structure, specify in a
move statement:
The fully qualified identifiers of the destination and source arrays
The FOR clause with or without the BYTES or WORDS qualifier
The FOR clause copies the specified number of bytes, words, doublewords, or
quadruplewords depending on the data type of the source array.  To copy bytes orwords regardless of source data type, include the BYTES or WORDS qualifier in theFOR clause.
The following example shows how you can copy an array from one structure to
another, first in quadrupleword units, then in word units:
STRUCT .s_struct;
BEGIN  FIXED array[0:2];     !Source ARRAY is in S_STRUCT  END;
STRUCT .d_struct (s_struct);
```
                        !Destination ARRAY is in D_STRUCT
```
PROC m;
BEGIN  d_struct.array ':=' s_struct.array FOR 3;                        !Copy three quadruplewords as                        ! dictated by FIXED data type
d_struct.array ':=' s_struct.array FOR 6 WORDS;
```
                        !Copy six words as dictated by  END;                  ! the WORDS qualifier
```

Accessing Structure ItemsUsing Structures
You can copy structure occurrences using structure pointers:
LITERAL copies := 3;STRUCT a_struct;        !Definition structure
BEGIN  INT a;  STRING b;  END;
STRUCT b_struct (a_struct) [0:copies - 1];
```
                        !Referral structure
```
INT .EXT ptr0(a_struct) := $XADR (a_struct);
```
                        !Assign address of A_STRUCT to                        ! extended INT pointer PTR0
```
STRING .EXT ptr1(a_struct) := $XADR (b_struct);
```
                        !Assign address of B_STRUCT to                        ! extended STRING pointer PTR1PROC n;  BEGIN  ptr1 ':=' ptr0 FOR copies ELEMENTS;                        !Word move from A_STRUCT to B_STRUCT
```
ptr0 ':=' ptr1 FOR copies ELEMENTS;
```
                        !Byte move from B_STRUCT to A_STRUCT  END;
```

Using Standard Functions With StructuresUsing Structures
Functions With
StructuresYou can use the following standard functions with structures.  These functions return
information such as the length of a structure occurrence or the offset of a structureitem within a structure:
Standard Function Effect$BITLENGTH Returns the length, in bits, of one occurrence of a structure or substructure
$BITOFFSET Returns an item’s offset, in bits, from the zeroth occurrence of the
encompassing structure
$LEN Returns the length, in bytes, of one occurrence of an item$OFFSET Returns an item’s offset, in bytes, from the zeroth occurrence of the
encompassing structure
$OCCURS Returns the number of occurrences of a structure, substructure, or array, but
not of a template structure
$TYPE Returns the type of an item
The following example reads structured data from a disk file.  In the FOR statement,
$OCCURS returns 6 (the number of occurrences in JOB_DATA), and $LEN returns 24(the length in bytes of one occurrence of JOB_DATA):
INT record_num;                      !Number of recordsSTRUCT emp_data( *);                  !Template structure
BEGIN  INT number;  INT dept;  STRING ssn[0:11];  FIXED(2) salary;  END;
PROC p MAIN;                         !Main procedure
BEGIN  INT diskfile, num_read;  STRUCT .job_data (emp_data) [0:5]; !Referral structure  !Some code  FOR record_num := 0 TO $OCCURS (job_data) - 1 DO                                     !FOR statement
```
    CALL READ(diskfile,              !CALL statement
              job_data[record_num],  !Buffer              $LEN (job_data),       !Maximum bytes to read              num_read);             !Count of bytes read  !More code  END;
```
In the preceding example, the FOR statement calls the READ system procedure once
for each occurrence of structure JOB_DATA.  For information on  the READ procedure,
see the Guardian Procedure Calls Reference Manual .