# Appendix C: Improving Performance

inherent in this characteristic, it generates efficient object code for the target computer.If optimum run-time speed is important, however, you can maximize efficiency byfollowing the guidelines given in this appendix.
General Guidelines The following guidelines describe general practices for achieving efficient code:
Code programs as cleanly and clearly as possible.  Provide structured source codeand adequate documentation in the source listing.
Debug the programs to ensure that they work properly.
Analyze the programs using performance analysis tools to determine whereinefficiencies occur.
Based on the analysis, change procedures that require modification. Providecomments that describe the changes and why you made them.
The following guidelines apply to addressing, indexing, and arithmetic operations.
Addressing Guidelines You can use direct and indirect addressing in various ways.
Direct Addressing Although direct addressing is limited in the amount of memory it can reference, it is
more efficient than indirect addressing.  Thus, you should use direct addressingwhenever possible.
For example, suppose a procedure expects a reference parameter that is used heavily
in calculations within that procedure before it returns a value to the caller.  In theprocedure, move the value in the indirectly addressed parameter to a local directlyaddressed storage area and then use that copy in the calculations.  At the end of theprocedure, store the result in the original parameter, which is returned.  Althoughinitially a slight overhead results from copying from parameter to local variable backto parameter, overall execution speed is improved because:
Indirect addressing is used only twice (once in parameter passing and once inreturning the value).
All other references use direct addressing.
Indirect Addressing Indirect arrays, indirect structures, and pointers you declare provide equivalent
operation.  The advantage of indirect arrays and indirect structures is that the compilerprovides a pointer for the array or structure, allocates the data or structure, andinitializes the pointer to the beginning of the array or structure.  To use pointers youdeclare, you must initialize the pointer and manage allocation of the data to which thepointer points.
Extended Addressing The compiler emits shorter instruction sequences if it can place INT and STRING
extended pointers in locations G[0] through G[63] or L[1] through L[63], so you shoulddeclare these pointers before you declare other global and local declarations.

Indexing GuidelinesImproving Performance
STORE StatementsSTACK and STORE statements do not improve the efficiency of access to data items.
These statements are provided primarily for moving operands to and from the registerstack when working with the CODE statement.
Indexing Guidelines The compiler saves index values in index registers so you can refer to them in laterstatements.  For instance, for the following operation, the compiler saves the value of Iin an index register:
x[i] := 5;
You can then use I in a reference such as Y[I] .
Multiple references to the same index value (using the same data type) promote
efficiency.
For indexed items in structures, the compiler optimizes references only to adjacent
items within the same substructure.
An index on a 16-bit variable is always a signed INT expression.  For a STRING
variable, an index can access ranges from 32K bytes below to 32K bytes above thezeroth structure occurrence.  For any variable except a STRING variable, an index canaccess ranges from 32K words below to 32K words above the zeroth structureoccurrence.
Indexing indirect references is no less efficient than not indexing indirect references,
because the hardware requires no extra time to add indexes to address values.
For an INT or STRING extended pointer located below G[63] or L[63] (decimal), a 16-
bit index is more efficient than a 32-bit index.  A 16-bit index results in a shorterinstruction sequence using the LWXX, SWXX, LBXX, and SBXX instructions.  (Theseinstructions are described in the System Description Manual  for your system.)
For all other extended pointers, a 16-bit index is slightly more efficient than a 32-bit
index.  If, however, the offset of a structure item declared in an extended indirectstructure is outside the signed INT range (–32,768 through 32,767), you must use a 32-bit index.
In a program written for a D-series system, you can use the INT32INDEX directive
when you index an extended indirect structure item.  INT32INDEX suppresses the[NO]INHIBITXX directive and generates a 32-bit index from a 16-bit index.  If you useINT32INDEX, you need not calculate the offset of an extended structure item todetermine whether to use a 16-bit or a 32--bit index.  INT32INDEX always generatescorrect offsets but is slightly less efficient than using a 32-bit index.   For moreinformation, see “Indexing Structures” in Section 8, “Using Structures.”
Using a USE register for the 16-bit index of an extended pointer does not provide
further efficiency.  The compiler must still load the index value from the USE registerinto register A for use with the LWXX, SWXX, LBXX, and SBXX instructions.  For theless efficient extended access, the compiler loads the 16-bit index from the USE registerinto register A, then converts it to a 32-bit index.

Arithmetic GuidelinesImproving Performance
several smaller expressions that are equivalent to the single complex expression.  Theexcessive memory references are triggered by register stack overflow, which isespecially likely if indexes are involved.  Use of an index might cause part of thecomputation to be pushed on the stack and later popped off.  Doubleword orquadrupleword operands fill the register stack quickly.
For quadrupleword operations, do not nest index calculations in larger arithmetic
expressions because register stack overflow is likely to result.  Use a separatestatement for the index calculations, saving the results in a temporary area.  Theexpression can then reference this area.
The IF and CASE forms of arithmetic expressions do not generate efficient machine
code, especially when used to test complex conditions.  To evaluate a complexcondition, include separate IF or CASE statements that perform proper assignments inall possible branches of the condition.