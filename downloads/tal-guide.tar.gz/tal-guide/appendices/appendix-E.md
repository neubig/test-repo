# Appendix E: File Names and TACL

Commands
Topics include:
Disk file names
TACL DEFINE commands
TACL PARAM commands
TACL ASSIGN commands
TACL ASSIGN SSV commands
For information on process or device file names, see the Guardian Programmer’s Guide.
Disk File Names A disk file name identifies a file that contains data or a program.  A disk file name
reflects the specified file’s location on a Tandem system.  The location of a disk file ona Tandem system is analogous to the location of a form in a file cabinet.  To find theform, you must know:
Which file cabinet it is in
Which drawer it is in
Which folder it is in
Which form it is
Analogously, to find a disk file on a Tandem system, you must know:
Which node (system) it is on
Which volume it is on
Which subvolume it is on
Which disk file it is
In general, disk file names:
Cannot contain spaces
Can contain ASCII characters only
Are not case-sensitive;  the following names are equivalent:
myfile
MyFileMYFILE
Language functions and system procedures that return file names might return
them in uppercase (even if the file name was originally in lowercase).  Check thedescription of the function or procedure that you are using.

Disk File NamesFile Names and TACL Commands
by a period:
A D-series node name or a C-series system name
A volume name
A subvolume name
A file ID
Here is an example of a disk file name:
\mynode.$myvol.mysubvol.myfile
You can name your own subvolumes and file IDs, but nodes (systems) and volumes
are named by the system manager.
All parts of the file name except the file ID are optional except as noted in the
following discussion.  If you omit any part of the file name, the system uses values asdescribed in “Partial File Names” later in this appendix.
Node or System Name
The node or system name, such as \MYNODE, is the name of the node or system
where the file resides.  If specified, the node or system name must begin with abackslash (\) followed by one to seven alphanumeric characters.  The characterfollowing the backslash must be an alphabetic character.
Volume Name
The volume name, such as $MYVOL, is the name of the disk volume where the file
resides.  If specified, the volume name must begin with a dollar sign ($), followed byone to six or one to seven alphanumeric characters as follows.  The character followingthe dollar sign must be an alphabetic character.
On a D-series system, the volume name can contain one to seven alphanumeric
characters.
On a C-series system, the volume name can contain:
One to six alphanumeric characters if you include the system name
One to seven alphanumeric characters if you omit the system name
On a C-series system, if you specify the system name, you must also specify the
volume name.  If you omit the system name, specifying the volume name is optional.
Subvolume Name
The subvolume name, such as MYSUBVOL, is the name of the set of files, on the disk
volume, within which the file resides.  The subvolume name can contain from one toeight alphanumeric characters, the first of which must be alphabetic.
On a D-series system, if you specify the volume name, you must also specify the
subvolume name.  If you omit the volume name, specifying the subvolume name isoptional.

Disk File NamesFile Names and TACL Commands
The file ID, such as MYFILE, is the identifier of the file in the subvolume.  The file ID
can contain from one to eight alphanumeric characters, the first of which must bealphabetic.
The file ID is required.
Partial File Names A partial file name contains at least the file ID, but does not contain all the file-name
parts.  When you specify a partial file name, the operating system or other process fillsin the missing file-name parts by using your current default values.  Following are theoptional file-name parts and their default values:
File-Name Part Default
node (system) Node (system) on which your program is executing
volume Current default volume
subvolume Current default subvolume
Following are all the partial file names you can specify for a disk file named
\BRANCH.$DIV.DEPT.EMP:
Omitted File-Name Parts Partial File Name D-Series System C-Series SystemNode (system) $div.dept.emp Yes Yes
Node (system), volume dept.emp Yes Yes
Node (system), volume,
subvolumeemp Yes Yes
Volume \branch.dept.emp Yes No
Volume, subvolume \branch.emp Yes NoSubvolume \branch.$div.emp No YesNode (system), subvolume $div.emp No Yes
You can change your current default values in various ways:
You can change the volume and subvolume with the VOLUME command of, for
example, the Binder, Inspect, and TACL products.
In some cases, you can specify node (system), volume, and subvolume names byissuing TACL ASSIGN SSV commands, described later in this appendix.
Logical File Names You can use a logical file name in place of the disk file name.  A logical file name is an
alternate name you specify in a TACL DEFINE or TACL ASSIGN command, describedlater in this appendix.

TACL CommandsFile Names and TACL Commands
between your program  and the operating system.  The D-series operating system usesthe internal form only if your program has not been converted to use D-series features.
For information on converting external file names to internal file names in a program,
see the Guardian Programmer’s Guide and the Guardian Procedure  Calls Reference Manual.
TACL Commands You can send information to the compiler by using the following TACL commands:
DEFINE
PARAM
ASSIGN
These commands are summarized in the remainder of this appendix.  For complete
information on these commands, see the following manuals:
TACL Reference Manual  (syntactic information)
TACL Programmer's Guide  (programmatic information)
Guardian User’s Guide  (interactive information)
Guardian Programmer’s Guide   (programmatic information)
TACL DEFINE
CommandsBy issuing TACL DEFINE commands before starting the compiler, you can:
Substitute an actual file name for a logical file name used in the source file
Specify spooler attributes
Specify file attributes on a labeled tape
Specify process defaults, such as default volume and subvolume
Substituting File Names You can substitute a file name for a logical (or TACL DEFINE) name being passed by a
nonprivileged program to a system procedure.  To substitute a file name, issue thefollowing TACL commands:
TACL Command PurposeSET DEFMODE ON Enable DEFINE processing
SET DEFINE CLASS Set the initial attribute of a DEFINE command to CLASS MAP
SET DEFINE Set the working attributesADD DEFINE Specify a file name to substitute for a DEFINE name

TACL CommandsFile Names and TACL Commands
Are not case-sensitive
Consist of 2 to 24 characters
Begin with an equals sign (=) followed by an alphabetic character
Continue with any combination of letters, digits, hyphens (-), underscores (_), and
circumflexes (^)
Some examples of valid DEFINE names are:
=A
=The_chosen_file=Long-but-not-too-long=The-File-of-The-Week
DEFINE names that begin with an equals sign followed by an underscore (=_) are
reserved by Tandem.  For example, do not use DEFINE names such as =_DEFAULT.
Setting DEFINE
CLASS AttributesTo create a DEFINE message or set its attributes, you must set a CLASS attribute for
the DEFINE.  The CLASS attributes are MAP, TAPE, SORT/SUBSORT, SPOOL, andDEFAULTS.  Each attribute has an initial setting based on whether the attribute isrequired, optional, or default.
MAP DEFINE
When you log on, the default CLASS attribute is MAP, which requires a file name.  A
MAP DEFINE substitutes a file name for a DEFINE name used in the source file.  Forexample, suppose that your current CLASS attribute is MAP and your source fileincludes the DEFINE name =MULTI in a SOURCE directive:
?SOURCE =multi
Before running the compiler, you can associate file name \BRIG.$ULLX.CABLE.PORT
with  =MULTI:
ADD DEFINE =multi, FILE \brig.$ullx.cable.port
During compilation, the compiler passes the DEFINE name to a system procedure,
which makes the file available to the compiler.  If the system procedure cannot makethe file available, the open operation fails.
TAPE DEFINE (D-Series Systems Only)
The TAPE DEFINE lets you specify attributes for labeled magnetic tapes.  For instance,
it lets you specify attributes such as block length, recording density, record format andlength, number of reels, and labeling.
SPOOL DEFINE
The SPOOL DEFINE lets you specify spooler settings or attributes, such as number of
copies, form name, location, owner, report name, and priority.

TACL PARAM CommandsFile Names and TACL Commands
In the DEFAULTS class, a permanently built-in DEFINE named =_DEFAULTS has the
following attributes, which are active regardless of any DEFMODE setting:
Attribute Required PurposeVOLUME Yes Contains the default node, volume, and subvolume names for the
current process as set by the TACL VOLUME, SYSTEM, and LOGONcommands
SWAP No Contains the node and volume name in which the operating system is to
store swap files
CATALOG No Contains a substitute name for a catalog as described in the NonStop
SQL Reference Manual
TACL PARAM
CommandsCompilers accept TACL PARAM commands that you issue before starting the
compilers.  PARAM commands are BINSERV, SAMECPU, SWAPVOL, andSYMSERV.
PARAM BINSERV
CommandThe PARAM BINSERV command lets you specify which BINSERV process you want
to use.  You can specify a file name or a TACL DEFINE name.
For example, you can specify the BINSERV file on a particular node, volume, and
subvolume as follows:
PARAM BINSERV \mynode.$myvol.mysubvol.BINSERV
If the specified node is not the one the TAL compiler runs on, the compiler ignores the
command.  If you omit the volume and subvolume, the compiler uses the currentdefault volume and subvolume.  If you omit the file ID,   the compiler uses the file ID
BINSERV.  If you specify a TACL DEFINE name, it must refer to a disk file of classMAP.
If you use this command, the error file PDTERROR must be on the same subvolume as
BINSERV.  If you omit this command, the compiler uses the BINSERV process on itsown volume and subvolume.
PARAM SAMECPU
CommandThe PARAM SAMECPU command causes the compiler, BINSERV, and SYMSERV to
all to run in the same processor if you specify any number but 0.  For example:
PARAM SAMECPU 32767
TAL /CPU 6/
Specifying 0 means the compiler, BINSERV, and SYMSERV need not run on the same
processor.  For example:
PARAM SAMECPU 0

TACL PARAM CommandsFile Names and TACL Commands
CommandThe PARAM SWAPVOL command lets you specify the volume that the compiler,
BINSERV, and SYMSERV use for temporary files.  For example:
PARAM SWAPVOL $myvol
The compiler ignores any node specification and allocates temporary files on its own
node.  If you omit the volume, the compiler uses the default volume for temporaryfiles; BINSERV and SYMSERV use the volume that is to receive the object file.
Use this command when:
The volumes normally used for temporary files might not have sufficient space.
The default volume or the volume to receive the object file is on a different node
from the compiler.
PARAM SYMSERV
CommandThe PARAM SYMSERV command lets you specify which SYMSERV process you want
to use.  You can specify a file name or a TACL DEFINE name.
For example, to specify the SYMSERV file on a particular volume and subvolume:
PARAM SYMSERV \mynode.$myvol.mysubvol.SYMSERV
If the node is not the one the compiler runs on, the compiler ignores the command.  If
you omit the volume or subvolume, the compiler uses the current default volume orsubvolume.  If you omit the file name, the compiler uses the name SYMSERV.  If youspecify a TACL DEFINE name, the name must refer to a disk file of class MAP.
If you omit this command, the compiler uses the volume and subvolume specified in
the PARAM BINSERV command.  If you omit both PARAM SYMSERV and PARAMBINSERV commands, the compiler uses the SYMSERV process on the compiler’svolume and subvolume.
Using PARAM Commands You can specify one or more PARAM commands before starting the compiler.  For
example, you can specify that:
The compiler use the BINSERV process located on MYSUBVOL
PARAM BINSERV mysubvol
The compiler, BINSERV, and SYMSERV all run in the same processor
PARAM SAMECPU 1
The compiler, BINSERV, and SYMSERV allocate temporary files on volume
$JUNK
PARAM SWAPVOL $junk
Then you can issue the TAL compilation command:
TAL /IN mysource/ myprog

TACL ASSIGN CommandsFile Names and TACL Commands
CommandsYou can issue the TACL ASSIGN command before starting the compiler to substitute
actual file names for logical file names used in the source file.  The TACL productstores the file-name mapping until the compiler requests it.
ASSIGN commands fall into two categories:
Ordinary ASSIGN commands
ASSIGN SSV commands
Ordinary ASSIGN
CommandThe ordinary ASSIGN command equates a file name with a logical file name used in
ERRORFILE, SAVEGLOBALS, SEARCH, SOURCE, and USEGLOBALS directives.The compiler accepts only the first 75 ordinary ASSIGN messages.
In each ASSIGN command, specify a logical identifier followed by a comma and the
file name or a TACL DEFINE name:
ASSIGN dog, \a.$b.c.dog
ASSIGN cat, =mycat
If the file name is incomplete, the TACL product completes it from your current
default node, volume, and subvolume.  For example, if your current defaults are\X.$Y.Z, the TACL product completes the incomplete file names in ASSIGNcommands as follows:
Incomplete File Names Complete File NamesASSIGN qq, cat ASSIGN qq, \x.$y.z.cat
ASSIGN ss, b.dog ASSIGN ss, \x.$y.b.dogASSIGN tt, $a.b.rat ASSIGN tt, \x.$a.b.rat.
If you use a TACL DEFINE name in place of a file name, the TACL product qualifies
the file name specified in the ADD DEFINE command when it processes the ASSIGNcommand.  Even if you specify new node, volume, and subvolume defaults betweenthe ADD DEFINE command and the ASSIGN command, the ASSIGN mapping stillreflects the ADD DEFINE settings.
Processing ASSIGN File Names
If you issue the following commands:
ASSIGN aa, $a.b.cat
ASSIGN bb, $a.b.dogASSIGN cc, =my_zebraADD DEFINE =my_zebra, CLASS MAP, FILE $a.b.zebra
TAL /IN mysource, OUT $s/ obj
the compiler equates SOURCE directives in MYSOURCE to files as follows:
?SOURCE aa              !Equates to ?SOURCE $a.b.cat
?SOURCE cc              !Equates to ?SOURCE $a.b.zebra?SOURCE bb              !Equates to ?SOURCE $a.b.dog
You can name new source files at each compilation without changing the contents of
the source file.

TACL ASSIGN CommandsFile Names and TACL Commands
and subvolume to take files from.  The compiler uses ASSIGN SSV information toresolve incomplete file names in the SEARCH, SOURCE, and USEGLOBALSdirectives.
For each ASSIGN SSV command, append to the SSV keyword a value in the range 0
through 49.  Values in the range 0 through 9 can appear with or without a leading 0.
For example, if you specify:
ASSIGN SSV1, oldfiles
and the compiler encounters the directive:
?SOURCE myutil
the compiler looks for OLDFILES.MYUTIL.If you then specify:
ASSIGN SSV1, newfiles
and run the compiler again, it looks for NEWFILES.MYUTIL.If you omit the node or volume, the TACL product uses the current default node or
volume.  If you omit the subvolume, the compiler ignores the command.  TACLDEFINE names are not allowed.
The ASSIGN SSV command also lets you specify the order in which subvolumes are
searched.  You can specify ASSIGN SSV commands in any order.  If the same SSVvalue appears more than once, the TACL product stores only the last command havingthat value.
For example, if you issue the following commands, the TACL product stores only two
of the messages :
Assign SSV Command StoredASSIGN SSV28, $a.b Yes
ASSIGN SSV7, $c.d No
ASSIGN SSV7, $e.f No
ASSIGN SSV07, $g.h Yes
The compiler stores ASSIGN SSV messages in its SSV table in ascending order.

TACL ASSIGN CommandsFile Names and TACL Commands
For each file name the compiler processes, the compiler scans the SSVs in ascending
order from SSV0 until it finds a subvolume that holds the file.
For example, if you issue the following ASSIGN commands before running the
compiler:
ASSIGN SSV7,  $aa.b3
ASSIGN SSV10, $aa.grplipASSIGN SSV8,  mylibASSIGN SSV20, $cc.divlibASSIGN trig,  $sp.math.xtrig
and the compiler encounters the following SOURCE directive:
?SOURCE unpack
the compiler first looks for an ASSIGN message having the logical name UNPACK.  If
there is none, the compiler looks for the file in subvolumes in the following order:
$aa.b3.unpack                            (SSV7)
$
default-volume .mylib.unpack             (SSV8)
$aa.grplib.unpack                        (SSV10)$cc.divlib.unpack                        (SSV20)$
default-volume.default-subvolume .unpack
The compiler uses the first file it finds.  If it finds none named UNPACK, it issues an
error message.
When the compiler encounters the following directive:
?SOURCE trig
it tries only $SP.MATH.XTRIG; if it does not find that exact file, it issues an error
message.