# Appendix B: Managing Addressing

Extended pointer format
Accessing the upper 32K-word area of the user data segment
Creating and accessing an extended data segment
Accessing a code segment
The coding practices covered in this appendix predate automatic extended segment
management and are described here in support of existing programs.
Extended
Pointer FormatYou can use an extended pointer to access the current user data segment, the system
data segment, or the current user code segment.  You must use an extended pointer toaccess an extended data segment.
Figure B-1 shows the format of extended pointers.
Figure B-1.  Format of Extended Pointer
012345678910111213141516171819202122232425262728293031High-order address word Low-order address word
A B Segment Page Word Byte
Table B-1 explains the meanings of the bits in shown in Figure B-1.
Table B-1.  Extended Pointer Format
Bits Meaning Values<0> Absolute Mode specifier (A) 0 for nonprivileged use; 1 for privileged use
<1> Reserved (B) 0
<2:14> Segment specifier 0:1027 (relative extended address)
0:8191 (absolute extended address)
<15:20> Page specifier 0:63<21:30> Word specifier 0:1023<31> Byte specifier 0 in left byte; 1 in right byte

Accessing the Upper 32K-Word AreaManaging Addressing
accessed by the pointer:
Segment Specifier Segment0 Current user data segment
1 System data segment if in privileged mode
User data segment if in nonprivileged mode
2 Current code segment3 Current user code segment (read access only)4–
n Base address for the current extended data segment
An extended pointer, having 32 bits, can access byte addresses anywhere in a segment.
(The page, word, and byte fields together require 17 address bits.)  All extendedaddresses are byte addresses.
Accessing the Upper
32K-Word AreaYou can use the upper 32K-word area of the current user data segment if you are not
using the CRE.
To use the upper 32K-word area, you must use the DATAPAGES directive.  For
example, you can specify 33 pages for the user data segment.
DATAPAGES 33
To access the upper 32K-word area, you must declare a pointer and store an
appropriate address in it.  To access word addresses (but not byte addresses) in theupper 32K-word area, you can use a standard (16-bit) pointer.  To access byteaddresses in that area, you must use an extended (32-bit) pointer.
Storing Addresses
in Simple PointersTo store an address in a simple pointer, you can initialize the pointer when you
declare it, or you can assign an address to it in an assignment statement.
Initializing Simple Pointers
When you declare a simple pointer, you can initialize it with a standard (16-bit)
address or an extended (32-bit) address.  For example, you can initialize a simplepointer with the first word address in the upper 32K-word area as follows:
INT .std_ptr := %100000;       !First 16-bit word address
```
                               ! in upper 32K-word area
```
You can initialize an extended simple pointer with the first extended byte address in
the upper 32K-word area as follows:
INT .EXT top_ptr := %200000D;  !First 32-bit byte address
```
                               ! in upper 32K-word area
```

Accessing the Upper 32K-Word AreaManaging Addressing
standard simple pointer to a 32-bit address with which to initialize an extended simplepointer:
INT .std_ptr := %100000;   !Declare INT standard simple
```
                           ! pointer
```
INT .EXT ext_ptr := $XADR(std_ptr);
```
                           !Declare extended simple pointer                           ! initialize it with 32-bit                           ! address returned by $XADR for                           ! INT item pointed to by STD_PTR
```
Assigning Addresses to Simple Pointers
Once you have declared a pointer, you can use assignment statements to assign an
address to the pointer.
You can assign to a standard simple pointer the first standard word address in the
upper 32K-word area of the current user data segment:
INT .std_ptr;              !Declare standard simple pointer@std_ptr := %100000;       !Assign first word address
```
                           ! in upper 32K-word area
```
You can assign to an extended simple pointer the first extended byte address in the
upper 32K-word area of the current user data segment:
INT .EXT top_ptr;          !Declare extended simple pointer@top_ptr := %200000D;      !Assign first byte address
```
                           ! in upper 32K-word area
```
You can use the $XADR standard function to return the extended address of an INT
item to which a standard simple pointer points and then assign the 32-bit address toan extended simple pointer:
INT .EXT ext_ptr;          !Declare extended simple pointerINT .std_ptr := %100000;   !Declare INT standard simple
```
                           ! pointer
```
@ext_ptr := $XADR(std_ptr);!Assign 32-bit address of
```
                           ! INT item returned by $XADR
```

Accessing the Upper 32K-Word AreaManaging Addressing
in Structure PointersYou can store an address in a structure pointer either by initializing the pointer at
declaration or by assigning an address to it after declaration.
Initializing Structure Pointers
You can declare an extended structure pointer named EXT_STRUCT_PTR, specify a
referral named MY_STRUCT and then initialize the pointer with the first byte addressof the upper 32K-word area of the current user data segment as follows:
INT .EXT ext_struct_ptr (my_struct) := %200000D;
```
                           !First byte address in upper                           ! 32K-word area
```
To associate an INT standard structure pointer with a template structure and initialize
the structure pointer with the first word address in the upper 32K-word area of thecurrent user data segment, specify:
STRUCT names ( *);          !Declare template structure
BEGIN  INT array[0:11];  END;
INT .struc_ptr (names) := %100000;
```
                           !Declare structure pointer;                           ! initialize it with first word                           ! address in upper 32K-word area
```
To associate an extended structure pointer with the structure pointer declared in the
preceding example and initialize the new structure pointer with the first byte addressin the upper 32K-word area of the current user data segment, specify:
STRING .EXT ex_strc_ptr (struc_ptr) := %200000D;
```
                           !Declare extended structure                           ! pointer; initialize it with                           ! first byte address in                           ! upper 32K-word area
```
Assigning Addresses to Structure Pointers
Once you have declared a structure pointer, you can use an assignment statement to
assign an address to the structure pointer.
You can associate an INT structure pointer with a template structure and then assign
the first word address in the upper 32K-word area of the current user data segment tothe structure pointer:
STRUCT names ( *);          !Declare template structure
BEGIN  INT array[0:11];  END;
INT .struc_ptr (names);    !Declare STRUC_PTR@struc_ptr := %100000;     !Assign first word address in
```
                           ! upper 32K-word area
```

Accessing the Upper 32K-Word AreaManaging Addressing
the preceding example and then assign the first byte address in the upper 32K-wordarea of the current user data segment to the new structure pointer:
STRING .EXT ex_strc_ptr (struc_ptr);
```
                           !Declare EXT_STRC_PTR
```
@ex_strc_ptr := %200000D;  !Assign first byte address in
```
                           ! upper 32K-word area
```
Managing Data Allocation
in Upper 32K-Word AreaWhen you declare pointers, the compiler allocates storage for the pointers, but you
must manage allocation for the data at the address contained in each pointer.  Youmust remember which addresses you have used and the length of the item pointed toby each pointer.  When you initialize subsequent pointers, you must allow enoughspace for the previous items.  You can then use an assignment or move statement tocopy data to the address contained in the pointer.
For example, you manage standard allocation in the user data segment as follows:
PROC std;
BEGIN  STRING .EXT byte_ptr := %200000D;                           !Initialize extended pointer with                           ! first byte address in upper                           ! 32K-word area for a 46-byte                           ! string constant
STRING .EXT str_ptr := @byte_ptr + 46D;
```
                           !Initialize extended pointer with                           ! first free byte address in upper                           ! 32K-word area  byte_ptr ':='         "This is a sample string to be scanned for an X";                           !Move statement copies 46-byte                           ! string constant to the byte                           ! address stored in BYTE_PTR  !Lots of code  END;
```
Assigning Data to Simple Pointers
You can assign a value to the 32-bit byte address contained in an extended simple
pointer:
INT .EXT ep := %200000D;   !Declare EP and initialize it
```
                           ! with address of first byte                           ! in upper 32K-word area
```
ep := 5;                   !Assign 5 to word location at
```
                           ! address %200000D
```

Accessing the Upper 32K-Word AreaManaging Addressing
simple pointer.  You can then assign one of the values in the constant list to an arrayelement by appending an index to the pointer to access that particular value:
INT var[0:4];              !Declare array
INT .ptr := %100000;       !Declare simple pointer
var[2] := 5;               !Assign 5 to VAR[2]ptr ':=' [1, 2, 3];        !Copy constant list to location
```
                           ! at address %100000
```
var[3] := ptr[2];          !Assign 3 to VAR[3]
Copying Data to Structure Pointers
You can use INT structure pointers to copy data to word-addressed structure items in
the upper 32K-word area of the current user data segment.  To copy data, you use amove statement:
?DATAPAGES 64              !Get maximum upper 32K-word areaSTRUCT names ( *);          !Declare template structure
BEGIN  INT new_name[0:7];  END;
INT .name_ptr1(names) := %100000;
```
                           !Point to beginning of upper                           ! 32K-word areaINT .name_ptr2(names) := %100010;                           !Point to next free space in upper                           ! 32K-word areaPROC main_proc MAIN;  BEGIN  !Lots of code  name_ptr1.new_name[0] ':=' "Athersohn, Jutha";  name_ptr2.new_name[0] ':=' "Zyrphn, Rhod Wen";                           !Move statement copies data  !Lots of code            ! to word-addressed structure  END;                     ! items
```

Accessing the Upper 32K-Word AreaManaging Addressing
structure items in the upper 32K-word area of the current data user segment:
STRUCT name_rec ( *);       !Declare template structure
BEGIN  STRING name[0:25];  END;
INT .EXT ext_ptr(name_rec) := %200000D;
```
                           !Point to beginning                           ! of upper 32K-word area
```
ext_ptr.name[0] ':=' "Anasta L. Malatorious";
```
                           !Move statement copies data                           ! to byte-addressed structure                           ! items
```
Managing Large
Blocks of MemoryThe DEFINEPOOL, GETPOOL, and PUTPOOL system procedures can help you
manage large blocks of memory and build proper addresses:
LITERAL head_size = 19D;
INT .EXT poolhead := %200000D;          !Pool headerINT .EXT pool := %200000D + head_size;  !Points into upper                                        ! 32K-word areaINT .EXT block;
status := DEFINEPOOL (poolhead, pool, head_size);
@block := GETPOOL (poolhead, 1024D);!Lots of processingCALL PUTPOOL (poolhead, block);
The DEFINEPOOL, GETPOOL, and SEGMENT_USE_ procedures return both a
condition code and a value.  If you assign a returned value to a variable, the conditioncode setting is lost.  For more information on system procedures, see the Guardian
Procedure Calls Reference Manual  and the Guardian Programmer’s Guide .

Accessing the Upper 32K-Word AreaManaging Addressing
32K-Word BoundaryAlthough an index for standard indirect structures must fall within the signed INT
range, a word offset (from the zeroth structure occurrence) can be in the range –65,535through 65,535.  The following example shows how you can access such offsets:
STRUCT x ( *);
BEGIN  INT i, j;  END;
PROC m MAIN;
BEGIN  INT .y (x) := %70000;         !Y[0:18430] spans the                                ! 32K-word boundary  USE i;  FOR i := 0 TO 18430 DO    y[i].i := y[i].j := 0;  DROP i;  END;
Note If you use an array of structure occurrences that spans the 32K-word boundary, your program must
handle the data stack overflow condition.  The compiler issues an error only when the data stackoverflows the 32K-word boundary.
A byte offset, as opposed to a word offset, can be in the range –65,535 through 65,535 ifthe structure occurrences are either all in the lower 32K words or all in the upper 32Kwords of the user data segment.  Otherwise, the byte offset is incorrect.
If the structure is in the upper 32K words of the user data segment, you must use
$XADR and extended (32-bit) addressing.  Here is an example:
STRUCT x ( *);
BEGIN  STRING s[0:1];  END;
PROC m MAIN:
BEGIN  INT .y (x) := %100000;        !Y[0:32767} is in the                                ! upper 32K-word area  INT .EXT z (x) := $XADR (y);  INT i;
FOR i := 0 TO 32767 DO
```
    z.s[1] := z.s[0] := 0;  END;
```

Accessing the User Code SegmentManaging Addressing
Code SegmentYou can access the user code segment by storing a 32-bit byte address in an extended
pointer.  To build the address, use:
The $DBLL standard function, which returns an INT(32) value from two INTvalues.  The first INT value becomes the upper half of the INT(32) value, and thesecond value becomes the lower half.
An unsigned bit-shift operation ('<<' 1), which converts a word address to a byteaddress.
Initializing Simple Pointers You can initialize an extended simple pointer with a 32-bit byte address for read-only
access.  The address can point to the seventh word or fourteenth byte of the currentuser code segment:
INT .EXT ext_ptr := ($DBLL (3, 7)) '<<' 1;  !Declare and
```
                             ! initialize extended simple                             ! pointer with 32-bit byte                             ! address in user code segment
```
Assigning Addresses to
Simple PointersYou can assign an address for read-only access in the current user code segment as
follows:
INT .EXT ext_ptr;            !Declare extended simple
```
                             ! pointer@ext_ptr := ($DBLL (3, 7)) '<<' 1;                             !Assign current code                             ! segment address
```

Using Extended Data SegmentsManaging Addressing
SegmentsIn addition to the user data segment, you can store data in:
The automatic extended data segment
One or more explicit extended data segments
You should use only the automatic extended data segment if possible.  You should not
mix the two approaches.  If you must use explicit segments and the automaticsegment, however, follow guidelines 4 and 10 in “Using Explicit Extended Segments”that follows.
Using the Automatic
Extended SegmentWhen you declare extended indirect arrays or structures, the system automatically
creates and manages an extended data segment for you.  You have automatic access,however, to only one extended data segment.
To declare extended indirect arrays or structures, you specify the .EXT indirection
symbol.  To access the array, you use its name in a statement.  Declaring and accessingextended indirect arrays and structures is shown throughout this manual, particularlyin Sections 7 and 8.
Using Explicit
Extended SegmentsYour program can allocate and deallocate extended data segments explicitly.  Since the
advent of the automatic extended data segment, however, programs usually need notuse explicit extended data segments.  The information in this subsection is provided insupport of existing programs.
To create and use an explicit extended segment, you call system procedures.  You can
allocate and manage as many extended segments as you need, but you can use onlyone extended segment at a time.  You can access data in an explicit extended segmentonly by using extended pointers.   The compiler allocates memory space for theextended pointers you declare.  You  must manage allocation of the data yourself.
Here are guidelines for using explicit extended segments:1. First declare an extended pointer for the base address of the explicit extended
segment.
2. To allocate an explicit extended segment and obtain the segment base address, call
SEGMENT_ALLOCATE_.
3. To make the explicit extended segment the current segment, call
SEGMENT_USE_.
4. If the automatic extended segment is already in place, SEGMENT_USE_ returns
the automatic extended segment’s  number.  Save this number so you can lateraccess the automatic segment again.
5. You must keep track of addresses stored in extended pointers.  When storing
addresses in subsequent pointers, you must allow space for preceding data items.
6. To refer to data in the current segment, call READX or WRITEX .7. To move data between extended segments, call MOVEX.

Using Extended Data SegmentsManaging Addressing
PUTPOOL.
9. To determine the size of a segment, call SEGMENT_GETINFO_.10. To access data in the automatic extended segment, call SEGMENT_USE_ and
restore the segment number that you saved at step 4.
11. To delete an explicit segment that you no longer need, call
SEGMENT_DEALLOCATE_.
For information on using these system procedures, see the Guardian Programmer's
Guide  and the Guardian Procedure Calls Reference Manual.
If you do not restore the automatic extended segment before you manipulate data in it,
any of the following actions can result:
An assignment statement is beyond the segment’s memory limit and causes a trap.
All assignments within range occur in the hardware base and limit registers of theautomatic extended segment.  Data in the currently active extended segment isoverwritten.  The error is undetected until you discover the discrepancy at a latertime.
You get the wrong data from valid addresses in the explicit extended datasegment.
Storing the Base Address
The base address of the explicit extended segment defines the first storage location
that is available for allocating data.
When you call SEGMENT_ALLOCATE_, it returns the base address, as shown in the
following example.
D-Series Extended Segment Allocation Program
Example B-1 shows a D-series version of an extended segment allocation program.

Using Extended Data SegmentsManaging Addressing
?INSPECT, SYMBOLS
?SOURCE $SYSTEM.SYSTEM.EXTDECS0 (?            SEGMENT_ALLOCATE_, SEGMENT_USE_)
PROC alloc_xsegment MAIN;
BEGIN  DEFINE error = ! ...! #;     !Error handling routine
INT .EXT px;                 !Extended pointer for base
```
                               ! address of extended segment
```
INT s;
!Lots of code
s := SEGMENT_ALLOCATE_ (0, 4096D, , , , , px);
```
                               !Allocate extended segment 0;                               ! assign status value to S;                               ! request 2 pages of extended                               ! memory; obtain base address
```
IF s <> 0 THEN error;        !Continue if segment 0 is
```
                               !allocated; else return error
```
s := SEGMENT_USE_ (0, , px); !Make segment 0 the current
```
                               ! extended segment
```
IF s <> 0 THEN error;        !Continue if segment 0 is
```
                               !current; else return error
```
px := 5;                     !Assign 5 to first word of
```
                               ! segment 0
```
s := SEGMENT_ALLOCATE_ (1, 4096D, , , , , px);
```
                               !Allocate extended segment 1;                               ! assign status value to S;                               ! request 2 pages of extended                               ! memory; obtain base address
```
IF s <> 0 THEN error;        !Continue if segment 1 is
```
                               !allocated; else return error
```
s := SEGMENT_USE_ (1, , px); !Make segment 1 the current
```
                               ! extended segment
```
IF s <> 0 THEN error;        !Continue if segment 1 is
```
                               ! current; else return error
```
px := 2;                     !Assign 2 to first word of
```
                               ! segment 1  !Lots more code  END;
```

Using Extended Data SegmentsManaging Addressing
When you declare a pointer, the compiler allocates storage for the pointer itself but
does not allocate storage for data at the address that is contained in the pointer.  Youmust manage such allocation yourself.  You must remember which addresses youhave used and the length of the data item pointed to by each pointer.  When youinitialize subsequent pointers, you must allow space for the preceding data items.
All data items in an extended data segment are byte addressed.  You can manage data
allocation in an extended segment as follows:
?SOURCE $SYSTEM.SYSTEM.EXTDECS0 (
?            SEGMENT_ALLOCATE_, SEGMENT_USE_)
PROC xsegment MAIN;
BEGIN  DEFINE error = ! ...! #;     !Error handling routine
!Extended pointer declarations:
INT .EXT x;                  !For a 435-word array  INT .EXT y;                  !For a 1000-word array  INT .EXT z;                  !For a 94-word array
INT s;
!Lots of code  s := SEGMENT_ALLOCATE_ (0, 4096D, , , , , x);                               !Allocate extended segment 0;                               ! assign status value to S;                               ! request 2 pages of extended                               ! memory; obtain base address
IF s <> 0 THEN error;        !Continue if segment 0 is
```
                               !allocated; else return error
```
s := SEGMENT_USE_ (0, , x);  !Make segment 0 the current
```
                               ! extended segment
```
IF s <> 0 THEN error;        !Continue if segment 0 is
```
                               !current; else return error
```
@y := @x + 870D;             !Assign pointer Y to
```
                               ! first free space after                               ! area pointed to by X
```
@z := @y + 2000D;            !Assign pointer Z to the
```
    .                          ! first free space after                               ! area pointed to by Y  !Lots of code  END;
```

Using Extended Data SegmentsManaging Addressing
After you declare a pointer and store an address in the pointer, you can use an
assignment or move statement to place an item at the location pointed to by thepointer.
For example, you can declare a structure, declare and initialize an INT extended
structure pointer, and then access byte-addressed structure items in the currentextended data segment.  In this case, a move statement copies a character string into anarray in the structure:
?SOURCE $SYSTEM.SYSTEM.EXTDECS0 (
?            SEGMENT_ALLOCATE_, SEGMENT_USE_)
PROC xsegment MAIN;
BEGIN  DEFINE error = ! ...! #;     !Error handling routine
STRUCT name_rec ( *);         !Declare template structure
```
    BEGIN    STRING name[0:25];    END;
```
INT .EXT ext_seg(name_rec);  !Pointer for base address
```
                               ! of extended segment
```
INT s;
!Lots of code  s := SEGMENT_ALLOCATE_ (0, 4096D, , , , , ext_seg);                               !Allocate extended segment 0;                               ! assign status value to S;                               ! request 2 pages of extended                               ! memory; store base address                               ! in EXT_SEG
IF s <> 0 THEN error;        !Continue if segment 0 is
```
                               !allocated; else return error
```
s := SEGMENT_USE_ (0, , ext_seg);
```
                               !Make segment 0 the current                               ! extended segment
```
IF s <> 0 THEN error;        !Continue if segment 0 is
```
                               !current; else return error
```
ext_seg.name[0] ':=' "Octavius Q. Pumpernickle";
```
                               !Copy data into array  END;
```

Using Extended Data SegmentsManaging Addressing
You cannot use a move statement to copy data between extended segments.  You can
use a move statement to copy data from an extended segment to the user data segmentand then from there to another extended segment, or you can use  the MOVEX systemprocedure.
Managing Large Blocks of Memory
To manage large blocks of memory, you can call the following system procedures:
DEFINEPOOL Defines the bounds of a memory pool in an extended data
segment or in the user data segment.
GETPOOL Obtains a block of storage from a memory pool.PUTPOOL Returns a block of storage to a memory pool.
Each of the procedures returns a condition code and a value.  If you assign a returned
value to a variable, the condition code is lost.
The following example shows how to use memory pools to manage data storage in
extended data segments.  As shown in the example, you should store –1 or–1D in nilpointers , not 0D because 0D points to the first word in the user data segment.

Using Extended Data SegmentsManaging Addressing
Example B-2 shows D-series extended segment management program.
Example B-2.  D-Series Extended Segment Management Program (Page 1 of 3)
?INSPECT, SYMBOLS
?NOCODE?PAGE "dummy page directive"
?PUSHLIST, NOLIST SOURCE $SYSTEM.SYSTEM.EXTDECS0 (
?  PROCESS_DEBUG_, DEFINEPOOL, GETPOOL, PUTPOOL,?  SEGMENT_ALLOCATE_, SEGMENT_USE_, SEGMENT_DEALLOCATE_)
?POPLISTLITERAL dealloc_flags = 1;      !For SEGMENT_DEALLOCATE_
```
                                ! laterLITERAL seg_id_zero = 0;        !User extended data segmentLITERAL seg_id_two  = 2;        !IDs need not be contiguousLITERAL seg_id_zero_len = 2048D;LITERAL seg_id_two_len  = 4096D;INT    .EXT word_ptr := -1D;    !Nil pointerSTRING .EXT byte_ptr := -1D;    !Nil pointer
```
INT .EXT pool_head := -1D;      !Pointer for 19-word pool
```
                                ! header in extended segment
```
INT .EXT pool_ptr := -1D;       !Pointer for first byte after
```
                                ! pool header
```
INT .EXT block_ptr1 := -1D;     !Pool block general pointer
INT .EXT block_ptr2 := -1D;     !Pool block general pointerSTRING .byte_array[-1:100];     !Byte array for local scanSTRING .EXT ba_ptr := -1D;      !Extended pointer to byte                                ! array for extended move
STRING .offset_ptr := -1;
INT offset_x := 0;
LITERAL str_len = 47;           !Length of string to move
LITERAL array_len = 102;        !Length of byte array
INT status := 1000;             !Beyond maximum error range
INT old_seg_num := -1;          !Not a valid user extended                                ! data segment IDINT error;                      !Outcome of system procedure

Using Extended Data SegmentsManaging Addressing
PROC ext_addr_example MAIN;
BEGIN  status := SEGMENT_ALLOCATE_ (          seg_id_zero, seg_id_zero_len, , , , , byte_ptr);  IF status <> 0 THEN CALL PROCESS_DEBUG_;
status := SEGMENT_ALLOCATE_
```
          (seg_id_two, seg_id_two_len, , , , , block_ptr1);  IF status <> 0 THEN CALL PROCESS_DEBUG_;
```
status := SEGMENT_USE_ (seg_id_zero, , byte_ptr);
IF status <> 0 THEN CALL PROCESS_DEBUG_;
byte_ptr ':='
```
           "This is a sample string to be scanned for an X.";                                !Put character string into                                ! current extended segment
```
byte_array ':=' byte_ptr FOR str_len BYTES;
```
                                !Extended move of string                                ! to user stack
```
byte_array[-1]  := 0;         !Delimit the scan area
byte_array[100] := 0;         ! with zeros
SCAN byte_array[0] UNTIL "X" -> @offset_ptr;
IF $CARRY THEN CALL PROCESS_DEBUG_;                                !Scan on stack; if scan                                ! stopped by 0, call debugger
offset_x := @offset_ptr '-' @byte_array[0];

Using Extended Data SegmentsManaging Addressing
!USE new extended data segment for more manipulations.
status := SEGMENT_USE_ (seg_id_two, , block_ptr1);
IF status <> 0 THEN CALL PROCESS_DEBUG_;
@pool_ptr := @pool_head + %47D;
```
                                !Store first byte address                                ! after pool header
```
status := DEFINEPOOL (pool_head, pool_ptr, 4000D);
IF status <> 0 THEN CALL PROCESS_DEBUG_;
@block_ptr1 := GETPOOL (pool_head , 101D);
```
                                !For content of BYTE_ARRAY  IF <> THEN CALL PROCESS_DEBUG_;
```
block_ptr1 ':=' byte_array[-1] FOR array_len BYTES;
```
                                !Move BYTE_ARRAY to first                                ! pool in extended segment
```
@block_ptr2 := GETPOOL (pool_head, 1000D);
```
                                !Get second pool in current                                ! extended segment  IF <> THEN CALL PROCESS_DEBUG_;
```
block_ptr2 ':=' [8, 16, 32, 40, 48, 56, 64, 128];
```
                                !Move constant list into                                ! this pool in extended                                ! segment
```
CALL PUTPOOL (pool_head, block_ptr1);
```
                                !Give first pool back  IF <> THEN CALL PROCESS_DEBUG_;
```
CALL PUTPOOL (pool_head, block_ptr2);
```
                                !Give second pool back  IF <> THEN CALL PROCESS_DEBUG_;
```
CALL SEGMENT_DEALLOCATE_ (seg_id_two, dealloc_flags);  CALL SEGMENT_DEALLOCATE_ (seg_id_zero, dealloc_flags);  END;

Using Extended Data SegmentsManaging Addressing
Segment ExamplesOn a C-series system, you call ALLOCATESEGMENT and USESEGMENT to create
and use an explicit extended data segment.  ALLOCATESEGMENT does not returnthe base address of the extended segment.  The first segment address you can use inthe explicit extended segment is 4D '<<' 17 or %2000000D.   The following declarationsare equivalent:
STRING .EXT ptr := 4D '<<' 17;
STRING .EXT ptr := %2000000D;
Figure B-2 shows the format of the base address.
Figure B-2.  Format of Extended Segment Base Address
012345678910111213141516171819202122232425262728293031% 2 0 0000 0
1 1
'<<' 17
A B Segment Page Word Byte (%4)

Using Extended Data SegmentsManaging Addressing
Example B-3 shows a C-series version of the previous D-series extended segment
allocation program.  This example is not portable to future software platforms:
Example B-3.  C-Series Extended Segment Allocation Program
?INSPECT, SYMBOLS
?SOURCE $SYSTEM.SYSTEM.EXTDECS0 (?            ALLOCATESEGMENT, USESEGMENT)
PROC alloc_xsegment MAIN;
BEGIN  DEFINE error = ! ...! #;     !Error handling routine  INT .EXT px := %2000000D;    !Initialize extended pointer                               ! to start of extended segment  INT s;  !Lots of code  s := ALLOCATESEGMENT (0, 4096D);                               !Allocate extended segment 0;                               ! assign status value to S;                               ! request 2 pages (4K bytes)                               ! of extended memory
IF s <> 0 THEN  error;       !Continue if segment 0 is
```
                               ! allocated else return error
```
CALL USESEGMENT (0);         !Make segment 0 the current
```
                               ! extended segment
```
px := 5;                     !Assign 5 to first word of
```
                               ! segment 0
```
s := ALLOCATESEGMENT (1, 4096D);
```
                               !Allocate extended segment 1;                               ! assign status value to S;                               ! request 2 pages (4K bytes)                               ! of extended memory
```
IF s <> 0 THEN  error;       !Continue if segment 1 is
```
                               ! allocated else return error
```
CALL USESEGMENT (1);         !Make segment 1 the current
```
                               ! extended segment
```
px := 2;                     !Assign 2 to first word of
```
                               ! extended segment 1  !Lots more code
```
END;

Using Extended Data SegmentsManaging Addressing
When you declare a pointer, the compiler allocates storage for the pointer itself but
does not allocate storage for data at the address that is contained in the pointer.  Youmust manage such allocation yourself.  You must remember which addresses youhave used and the length of the data item pointed to by each pointer.  When youinitialize subsequent pointers, you must allow space for the preceding data items.
An extended data segment begins at the extended byte address %2000000D.  All data
items in an extended data segment are byte addressed.  You can manage dataallocation in an extended segment as follows:
INT .EXT x := %2000000D;     !Initialize extended simple
```
                             ! pointer with first byte                             ! address in extended segment                             ! for 435-word array
```
INT .EXT y := @x + 870D;     !Initialize extended simple
```
                             ! pointer with first free                             ! byte address after array                             ! pointed to by X for                             ! 1000-word array
```
INT .EXT z := @y + 2000D;    !Initialize extended simple
```
                             ! pointer with first free                             ! byte address after array                             ! pointed to by Y for                             ! 94-word array
```

Using Extended Data SegmentsManaging Addressing
Example B-4  shows a C-series version of the previous D-series extended segment
management program.  This example is  not portable to future software platforms.
Example B-4.  C-Series Extended Segment Management Program  (Page 1 of 3)
?INSPECT, SYMBOLS
?NOCODE?PAGE "dummy page directive"
LITERAL dealloc_flags = 1;      !For DEALLOCATESEGMENT later
LITERAL seg_id_zero = 0;        !User extended data segmentLITERAL seg_id_two  = 2;        !IDs need not be contiguousLITERAL seg_id_zero_len = 2048D;LITERAL seg_id_two_len  = 4096D;INT    .EXT word_ptr := -1D;    !Nil pointerSTRING .EXT byte_ptr := -1D;    !Nil pointerINT .EXT pool_head := %2000000D;                                !Beginning of 19-word pool                                ! header in extended segmentINT .EXT pool_ptr  := %2000046D;                                !First byte after pool headerINT .EXT block_ptr1 := -1D;     !Pool block general pointerINT .EXT block_ptr2 := -1D;     !Pool block general pointerSTRING .byte_array[-1:100];     !Byte array for local scanSTRING .EXT ba_ptr := -1D;      !Extended pointer to byte                                ! array for extended move
STRING .offset_ptr := -1;
INT offset_x := 0;
LITERAL str_len = 47;           !Length of string to move
LITERAL array_len = 102;        !Length of byte array
INT status := 1000;             !Beyond maximum error range
INT old_seg_num := -1;          !Not a valid user extended                                ! data segment IDINT error;                      !Outcome of system procedure
?PUSHLIST, NOLIST SOURCE $SYSTEM.SYSTEM.EXTDECS0 (
?  DEBUG, DEFINEPOOL, GETPOOL, PUTPOOL,?  ALLOCATESEGMENT, USESEGMENT, DEALLOCATESEGMENT)
?POPLIST

Using Extended Data SegmentsManaging Addressing
PROC ext_addr_example MAIN;
BEGIN  status := ALLOCATESEGMENT (seg_id_zero, seg_id_zero_len);  IF status <> 0 THEN CALL DEBUG;
status := ALLOCATESEGMENT (seg_id_two, seg_id_two_len);
IF status <> 0 THEN CALL DEBUG;
CALL USESEGMENT (seg_id_zero);
IF <> THEN CALL DEBUG;
@byte_ptr := %2000000D;       !Set extended pointer to
```
                                ! first byte of current                                ! extended segment
```
byte_ptr ':='
```
           "This is a sample string to be scanned for an X.";                                !Put character string into                                ! current extended segment
```
byte_array ':=' byte_ptr FOR str_len BYTES;
```
                                !Extended move of string                                ! to user stack
```
byte_array[-1]  := 0;         !Delimit the scan area
byte_array[100] := 0;         ! with zeros
SCAN byte_array[0] UNTIL "X" -> @offset_ptr;
IF $CARRY THEN CALL DEBUG;                                !Scan on stack; if scan                                ! stopped by 0, call debugger
offset_x := @offset_ptr '-' @byte_array[0];

Using Extended Data SegmentsManaging Addressing
!USE new extended data segment for more manipulations.
CALL USESEGMENT (seg_id_two);
IF <> THEN CALL DEBUG;
status := DEFINEPOOL (pool_head, pool_ptr, 4000D);
IF status <> 0 THEN CALL DEBUG;
@block_ptr1 := GETPOOL (pool_head , 101D);
```
                                !For content of BYTE_ARRAY  IF <> THEN CALL DEBUG;
```
block_ptr1 ':=' byte_array[-1] FOR array_len BYTES;
```
                                !Move BYTE_ARRAY to first                                ! pool in extended segment
```
!You cannot use a move statement to copy data directly from
! an extended segment to another extended segment.  You can! use a move statement to copy data from an extended segment! to the user data segment and then from there to another! extended segment, or you can use the MOVEX system procedure! described in the
Guardian Procedure Calls Reference Manual.
@block_ptr2 := GETPOOL (pool_head, 1000D);                                !Get second pool in current                                ! extended segment  IF <> THEN CALL DEBUG;
block_ptr2 ':=' [8, 16, 32, 40, 48, 56, 64, 128];
```
                                !Move constant list into                                ! this pool in extended                                ! segment
```
CALL PUTPOOL (pool_head, block_ptr1);
```
                                !Give first pool back  IF <> THEN CALL DEBUG;
```
CALL PUTPOOL (pool_head, block_ptr2);
```
                                !Give second pool back  IF <> THEN CALL DEBUG;
```
CALL DEALLOCATESEGMENT (seg_id_two, dealloc_flags);  CALL DEALLOCATESEGMENT (seg_id_zero, dealloc_flags);  END;