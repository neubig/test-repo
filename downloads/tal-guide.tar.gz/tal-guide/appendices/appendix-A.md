# Appendix A: Sample Programs

String-display sample program
String-entry sample program
Binary-to-ASCII conversion sample program
Modular programming example
String-Display
ProgramsExample A-1 shows the source code for a string-display program that displays
"Hello, World" on the terminal.
Example A-1.  C- or D-Series String-Display Program
!Global data declarations:
INT .out_file_name[0:11];
?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (CLOSE,
?  INITIALIZER, OPEN, WRITEX)   !Include system procedures,                                ! but suppress their listings?POPLIST                        !Resume listing
PROC startup_proc (rucb, passthru, message, msglen, match)
```
      VARIABLE;                 !Declare STARTUP_PROC    INT .rucb, .passthru, .message, msglen, match;  BEGIN  out_file_name ':=' message[21] FOR 12 WORDS;                                !Move statement  END;                          !End STARTUP_PROC
```
PROC myproc MAIN;               !Declare MYPROC
BEGIN  INT out_file_number;  STRING .EXT buffer[0:79];     !Array for output message  INT length;                   !Length of output message
CALL INITIALIZER ( ! rucb !, ! passthru !, startup_proc,
```
     ! paramsproc !, ! assignproc !, ! flags ! );                                !Get OUT file name  CALL OPEN (out_file_name , out_file_number);                                !Open OUT file; get number  buffer ':=' "Hello, World";   !Move statement  length := 12;                 !Assignment statement  CALL WRITEX (out_file_number, buffer, length);                                !Write message to OUT file  CALL CLOSE (out_file_number); !Close OUT file  END;                          !End MYPROC
```

String-Display ProgramsSample Programs
Example A-2.  C-Series String-Display Program )
?NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (CLOSE, INITIALIZER,
?  MYTERM, OPEN, WRITE)         !Include system procedures,                                ! but suppress their listings?LIST                           !Resume listing
PROC myproc MAIN;               !Declare MYPROC procedure
BEGIN  !Data declarations  INT termname[0:11];           !Terminal name  INT filename;                 !File number for terminal  STRING buffer[0:79];          !Array for output message  INT length;                   !Variable for message length
CALL INITIALIZER;             !Process startup
```
                                ! initialization  CALL MYTERM (termname);       !Get terminal name  CALL OPEN (termname, filenum); !Open terminal; get number  buffer ':=' "Hello, World";   !Move statement  length := 12;                 !Assignment statement  CALL WRITE (filenum, buffer, length);                                !Write message to terminal)  CALL CLOSE (filenum);         !Close terminal  END;                          !End MYPROC
```

String-Entry ProgramSample Programs
loop iteration, the program:
1. Displays  "ENTER STRING" and accepts a character string of up to 68 characters.
2. Scans the input string for an asterisk.  If an asterisk occurs, the program displays a
circumflex at the position of the first asterisk.
Example A-3 shows the D-series source code for the string-entry program.
Example A-3.  D-Series String-Entry Program
LITERAL maxlength = 68;         !Maximum length of BUFFER
INT termnum,                    !File number of home terminal    left_side,                  !BUFFER address of first                                ! character after prompt    num_xferred,                !Number of bytes transferred    count,                      !General-purpose variable    asterisk;                   !Location of asteriskSTRING .buffer[0:maxlength],    !Input-output buffer   .blanks[0:79] := 80 * [" "]; !Blanks for initialization?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS0 (?  PROCESS_GETINFO_, FILE_OPEN_, WRITEREADX, WRITEX)?POPLIST
PROC main_proc MAIN;            !Declare MAIN_PROC
BEGIN  CALL PROCESS_GETINFO_ (                 ,,,,,buffer:maxlength+1, num_xferred);  CALL FILE_OPEN_(buffer:num_xferred, termnum);  WHILE 1 DO                    !Infinite loop    BEGIN    buffer ':=' "ENTER STRING" -> left_side;    CALL WRITEREADX (termnum, buffer, left_side '–' @buffer,                   maxlength, num_xferred);    buffer[num_xferred] := 0;   !Delimit the input    SCAN buffer UNTIL "*" -> asterisk;                                !Scan for asterisk    IF NOT $CARRY THEN          !Asterisk found      BEGIN      buffer ':=' blanks FOR         (count := asterisk '-' @buffer +                 (left_side '-' @buffer)) BYTES;      buffer[count] := "^";      CALL WRITEX (termnum, buffer, count+1);      END;                      !End of IF    END;                        !End of WHILE  END;                          !End of MAIN_PROC

String-Entry ProgramSample Programs
Example A-4.  C-Series String-Entry Program
LITERAL maxlength = 68;         !Maximum length of BUFFER
INT termnum,                    !File number of home terminal    left_side,                  !BUFFER address of first                                ! character after prompt    num_xferred,                !Number of bytes transferred    count,                      !General-purpose variable    asterisk;                   !Location of asteriskINT .ibuffer[0:maxlength/2];STRING .buffer := @ibuffer '<<' 1, !Input-output buffer   .blanks[0:79] := 80 * [" "]; !Blanks for initialization?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS0 (?  MYTERM, OPEN, WRITEREADX, WRITEX)?POPLIST
PROC main_proc MAIN;            !Declare MAIN_PROC
BEGIN  CALL MYTERM (ibuffer);  CALL OPEN (ibuffer, termnum);  WHILE 1 DO                    !Infinite loop    BEGIN    buffer ':=' "ENTER STRING" -> left_side;    CALL WRITEREADX (termnum, buffer, left_side '–' @buffer,                   maxlength, num_xferred);    buffer[num_xferred] := 0;   !Delimit the input    SCAN buffer UNTIL "*" -> asterisk;                                !Scan for asterisk    IF NOT $CARRY THEN          !Asterisk found      BEGIN      buffer ':=' blanks FOR         (count := asterisk '-' @buffer +                 (left_side '-' @buffer)) BYTES;      buffer[count] := "^";      CALL WRITEX (termnum, buffer, count+1);      END;                      !End of IF    END;                        !End of WHILE  END;                          !End of MAIN_PROC

Binary-to-ASCII Conversion ProgramSample Programs
Conversion ProgramThis binary-to-ASCII conversion program performs a conversion function typical of
many algorithms in TAL.  The program converts a binary INT value to an ASCII (base10) value with a maximum length of six characters including the sign, then returns theconverted character string and its length to the calling procedure.
Significant items in Example A-5 are keyed to the following discussion:Item Discussion!1! Comments preceding the procedure declaration describe the purpose of the
procedure.  For complex procedures, you can also summarize the input-outputcharacteristics and the main features of the algorithm.
!2! The formal parameter specifications define the parameters of the procedure.
Input parameters V and RJUST are value parameters, and output parameterSTG is a reference parameter.
!3! This local declaration reserves six bytes of memory for the buffer in which the
number is converted.  The declaration also initializes the first five bytes in thebuffer to blanks (using a repetition factor of 5) and sets the last byte to anASCII 0.  Thus, an input of 0 results in an output of five blanks and a 0, ratherthan six blank characters.
!4! This IF statement deals with a negative INT binary number.  When it
encounters a negative number, it sets the negative value flag to 1 and takes theabsolute value of the number passed.
!5! This WHILE loop performs the conversion, character by character, writing each
byte to the buffer from right to left.
!6! This assignment statement converts the binary INT value to an ASCII (base 10)
value.  It illustrates an arithmetic expression that uses the standard procedure$UDBL.  The statement performs a residue modulo 10 operation, then adds anASCII 0 to the value of each byte to fit in the numeric range.
!7! This IF statement uses the assignment form of an arithmetic expression as the
condition.
!8! This IF statement moves the resulting character string from the buffer into the
user’s target string.
!9! The RETURN statement returns to the calling procedure the number of
characters moved.

Binary-to-ASCII Conversion ProgramSample Programs
!1!  !INT PROC ASCII converts a binary INT value to an ASCII
```
     ! (base 10) value of up to six characters (including the     ! sign) and returns the ASCII value and its length.
     INT PROC ascii (v, rjust, stg);
```
!2!      INT     v;          !INT value to convert         INT     rjust;      !Right justify result flag         STRING .stg;        !Target string       BEGIN!3!    STRING   .b[0:5] := [5*[" "],"0"];       INT       n;          !String length       INT       sgn := 0;   !Nonzero if V is negative       INT       k := 5;     !Index for converted digit
!4!    IF v < 0 THEN         !Value is negative
```
         BEGIN         sgn := 1;           !Set negative value flag         v := -v;            !Take absolute value         END;
```
!5!    WHILE v DO            !While a value is left . . .
```
         BEGIN               ! (equivalent to V <> 0)!6!      b[k] := $UDBL(v) '\' 10 + "0";                             !Convert a character         v := v / 10;        !Compute remainder         k := k - 1;         !Count converted character         END;
       IF sgn THEN           !Number is negative
         BEGIN         b[k] := "-";        !Insert the sign         k := k - 1;         !Count it as a character         END;
```
!7!    IF NOT (n:=5-k) THEN  !Check for an underflow
```
         n := 1;             !Return 1 character in that case
```
!8!    IF rjust THEN         !Move string to target
```
         stg[n-1] '=:' b[5] FOR n BYTES                             !Reverse move if right justified       ELSE         stg ':=' b[6-n] FOR n BYTES;                             !Otherwise forward move
```
!9!    RETURN n;             !Return string’s length
```
       END !ascii! ;
```

Modular Programming ExampleSample Programs
ExampleThis modular programming example illustrates how you can divide the code for a
program into separately compilable modules.  The program converts records in theinput file to a different format and length by reordering fields and adding fields torecords.  The example includes:
A brief description of program characteristics
Partial listings of module code
Load maps for the program file
Compilation statistics (compile and bind) for the program file
Selected listings show the handling of data and program structure. The content of
global data blocks appear only in the module that declares them.  In modules thatreference such blocks, NOLIST prevents the listing of the content of the blocks.
Compilation maps and statistics are not shown for each module.  Load maps show
global-data-block entries that do not exist after compilation, such as LITERALs.  Themainline load map does not refer to these blocks.
Modular Structure The program consists of five modules, shown in Examples A-6a through A-6e.  Each
module performs a single operation.  The structure of the modules and theirprocedures allows changes to one operation without the need to recompile the others.
Information is accessible across modules on an as-needed basis.  They share named
global data blocks and pass information as parameters and local data such as a simplepointer to the locally declared record buffer.  The named global data blockDEFAULT_VOL contains shared run-time data.  Other named blocks declare structuretemplates for record definitions and LITERAL declarations, which use no memory.
Procedures within a module share global data in private blocks.The following table summarizes the blocks used by each module.  (The symbol (P)
denotes a private block.)
Module Name Blocks Defined Blocks Referenced
TPR_CONVERT RECORD_DEFS MSG_LITERALS
INITIALIZATION_MODULE DEFAULT_VOL
MESSAGE_MODULE MSG_LITERALS
MESSAGE_MODULE (P)DEFAULT_VOL
IN_FILE_HANDLER IN_DATA
IN_FILE_HANDLER (P)MSG_LITERALS
DEFAULT_VOL
OUT_FILE_HANDLER OUT_DATA
OUT_FILE_HANDLER (P)DEFAULT_VOL
MSG_LITERALS

Modular Programming ExampleSample Programs
Source file names end with the character S.
Object file names correspond to source file names and end with O.  For instance,
the object file built from the source file INS is named INO.
Section names ending with D belong to a specific module.  For instance, IND is thesection that contains LITERAL declarations for INS.  Other section names are usedto provide a direct means for other source programs to copy
individual procedures
when they need them.  The section names beginning with END_OF_ are usedsolely to mark the ends of actual sections.
File names ending with P each contains external declarations of the procedures inthe module with the corresponding identifier.  A module that calls an externalprocedure includes a SOURCE directive for the P file.  For instance, the source forMESSAGE_MODULE is file MSGS, and source file MSGP declares each externalprocedure in MSGS.  The modules that call MESSAGE_MODULE specify MSGP ina SOURCE directive.
If any external declarations change, you must recompile both the P file and any
module that calls a changed external procedure.  The P file enables compile-timeconsistency checking between procedure declarations and the corresponding externaldeclarations.
A module also uses a P file for its external procedure declarations.  Module
xxxS uses a
SOURCE directive to specify xxxP, which contains external declarations for its
procedures.  (Otherwise, the consistency check is possible only during a later binding.)

Modular Programming ExampleSample Programs
Modular ProgramTo compile each source file into an object file, you can issue the following compilation
commands  You need do all these steps only once:
TAL /IN inits/ inito
TAL /IN ins/ inoTAL /IN outs/ outoTAL /IN msgs/ msgoTAL /IN converts/ converto
To bind the modular object files into a single object file, you can issue the following
Binder commands.  In this example, BINDS is the Binder IN file and the last five linesrepresent the content of BINDS:
BIND / IN binds /ADD * FROM converto
SELECT SEARCH (ino, outo, msgo, inito)SELECT SEARCH $SYSTEM.SYSTEM.TALLIBBUILD convert !EXIT
You can then update the code or private data in a module such as INITS by issuing the
following commands:
TAL /IN inits/ inito
BIND / IN binds /
When you update a shared data block in a module, you must recompile all modules
that reference the updated data block.  Similarly, when you update the declarations ofa shared procedure, you must recompile all modules that reference the updatedprocedure.
Source Modules The following source modules for the modular program illustrate how you can break a
program into manageable modules.  The source code for these modules are shown inthe remainder of this section:
Example Module Name Source File NameA-6a.   Mainline Module TPR_CONVERT CONVERTS
A-6b.   Initialization Module INITIALIZATION_MODULE INITS
A-6c.   Input File Module IN_FILE_HANDLER INSA-6d.   Output File Module OUT_FILE_HANDLER OUTSA-6e.   Message Module MESSAGE_MODULE MSGS

Modular Programming ExampleSample Programs
Example A-6a shows the mainline module, which contains the MAIN procedure.  The
record-definition structures are not listed because they are translations of the DataDefinition Language (DDL) source code into TAL.
Example A-6a.  D-Series Mainline Module (Page 1 of 2)
!File name CONVERTS
NAME tpr_convert;
?PUSHLIST, NOLIST, SOURCE recdefs      !BLOCK RECORD_DEFS
?POPLIST?PUSHLIST, NOLIST, SOURCE msgs (msglit)?POPLIST                               !BLOCK MSG_LITERALS              !Following are external procedure declarations:?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (?                                              PROCESS_STOP_)?POPLIST?PUSHLIST, NOLIST, SOURCE inp          !IN_FILE_HANDLER?POPLIST?PUSHLIST, NOLIST, SOURCE outp         !OUT_FILE_HANDLER?POPLIST?PUSHLIST, NOLIST, SOURCE msgp         !MESSAGE_MODULE?POPLIST?PUSHLIST, NOLIST, SOURCE initp        !INITIALIZATION_MODULE?POPLIST
?SECTION out_init
PROC out_init (out_rec:out_rec_len);   !Initialize    STRING .EXT out_rec (out_rec_def); ! output record    INT out_rec_len;  BEGIN  IF out_rec_len '<>' 0 THEN    out_rec ':=' [" "] & out_rec FOR out_rec_len '-' 1 BYTES;  END;
?SECTION record_convert
PROC record_convert (in_rec, out_rec);    STRUCT .EXT in_rec (in_rec_def);   !Convert between    STRUCT .EXT out_rec (out_rec_def); ! two records  BEGIN  INT i;  STRING .EXT ch_ptr;  i := 0;  @ch_ptr := @in_rec.name;             !Copy last name

Modular Programming ExampleSample Programs
WHILE (i < $OCCURS(in_rec.name)) AND (ch_ptr <> ",") DO
```
    BEGIN    @ch_ptr := @ch_ptr[1];    i := i + 1;    END;  out_rec.name.last_name ':=' in_rec.name FOR i BYTES;
```
IF ch_ptr = ',' THEN                 !Copy first name
```
    BEGIN    @ch_ptr := @ch_ptr[1];             !Advance past comma    out_rec.name.first_name ':=' ch_ptr FOR      $OCCURS(in_rec.name) '-' i '-' 1 BYTES;    END;  out_rec.address ':=' in_rec.address  !Copy address    FOR $OCCURS(in_rec.address) BYTES;  END;
```
?SECTION convert
PROC convert;  BEGIN  INT     record_count := 0;  STRUCT .in_buffer  (in_rec_def);  STRUCT .out_buffer (out_rec_def);  WHILE (read_in (in_buffer:$LEN(in_rec_def))) <> 1 !EOF! DO    BEGIN                               !Read record,                                        ! return EOF    CALL out_init (out_buffer:$LEN(out_rec_def));                                        !Initialize output    CALL record_convert (in_buffer, out_buffer);    CALL write_out (out_buffer:$LEN(out_rec_def));    record_count := record_count + 1;    END;  !Of WHILE loop  !EOF  CALL msg (msg_eof, record_count);  END;  !Of CONVERT
?SECTION end_of_code_sections
PROC tprconv MAIN;  BEGIN  CALL file_init;                   !In INITIALIZATION_MODULE  CALL convert;  CALL close_all;  END;?NOMAP

Modular Programming ExampleSample Programs
Example A-6b shows the source code for the initialization module.  This module
defines a primary global data block, DEFAULT_VOL, which is accessible to allprocedures in the modules that declare the block for reference.
Example A-6b.  D-Series Initialization Module (Page 1 of 2)
!File name INITS
NAME initialization_module;
?SECTION default
BLOCK default_vol;                !Default volume, subvolume  LITERAL file_name_max_len = 256;  INT def_vol_subvol_len;  STRING .def_vol_subvol[0:file_name_max_len - 1];  END BLOCK;?SECTION end_of_data_sections
```
              !Following are external procedure declarations:
```
?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (?                                   OLDFILENAME_TO_FILENAME_)?POPLIST?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (?                                                INITIALIZER)?POPLIST?PUSHLIST, NOLIST, SOURCE outp              !OUT_FILE_HANDLER?POPLIST?PUSHLIST, NOLIST, SOURCE inp                !IN_FILE_HANDLER?POPLIST?PUSHLIST, NOLIST, SOURCE msgp                !MESSAGE_MODULE?POPLIST?PUSHLIST, NOLIST, SOURCE initp        !INITIALIZATION_MODULE?POPLIST                           ! (for consistency checks)

Modular Programming ExampleSample Programs
?SECTION startup
PROC startup (rucb, passthru, message, meslen, match)  VARIABLE;    INT .rucb, .passthru, .message, meslen, match;  BEGIN  INT .def_vol_subvol_internal_fmt[0:11] := [ 12 * ["  "] ];  def_vol_subvol_internal_fmt ':=' message[1] FOR 8 WORDS;  CALL OLDFILENAME_TO_FILENAME_(def_vol_subvol_internal_fmt,                            def_vol_subvol:file_name_max_len,                            def_vol_subvol_len);  END;
?SECTION file_init
PROC file_init;  BEGIN  CALL INITIALIZER (,,startup);  CALL msg_init;  CALL in_file_init;  CALL out_file_init;  END;
?SECTION close_all
PROC close_all;  BEGIN  CALL in_close;  CALL out_close;  CALL msg_close;  END;?SECTION end_of_code_sections?NOMAP

Modular Programming ExampleSample Programs
Example A-6c shows the source code for the input file module, which contains all
procedures that manipulate the input file.  If you make I/O changes, only this moduleneeds to be recompiled.  The initialization module, for example, calls a procedure inthis module.  This module declares a private global data block, which is accessible onlyto the procedures in this module.
Example A-6c.  D-Series Input File Module (Page 1 of 3)
!File name INS
NAME in_file_handler;
?PUSHLIST, NOLIST, SOURCE recdefs          !BLOCK RECORD_DEFS
?POPLIST?PUSHLIST, NOLIST, SOURCE inits (default)  !BLOCK DEFAULT_VOL?POPLIST?PUSHLIST, NOLIST, SOURCE msgs (msglit)   !BLOCK MSG_LITERALS?POPLIST
BLOCK PRIVATE;
INT in_file;                             !Input file number  END BLOCK;
```
              !Following are external procedure declarations:
```
?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (?                                 FILE_CLOSE_, FILE_GETINFO_)?POPLIST?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (?                              FILE_OPEN_, FILENAME_RESOLVE_)?POPLIST?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (?                                       PROCESS_STOP_, READX)?POPLIST?PUSHLIST, NOLIST, SOURCE msgp               ! MESSAGE_MODULE?POPLIST?PUSHLIST, NOLIST, SOURCE inp               ! IN_FILE_HANDLER?POPLIST                              ! (consistency checks)

Modular Programming ExampleSample Programs
?SECTION in_file_init
PROC in_file_init;  BEGIN  INT in_file_name_len := 6;  STRING .in_file_name[0:file_name_max_len - 1] :=                                                [ "INFILE" ];  INT status;  status := FILENAME_RESOLVE_              (in_file_name:in_file_name_len,               in_file_name:file_name_max_len,               in_file_name_len,               !options!,               !override_name:override_name_len!,               !search:search_len!,               def_vol_subvol:def_vol_subvol_len);  IF status = 0 !OK! THEN    BEGIN    status := FILE_OPEN_(in_file_name:in_file_name_len,                          in_file);    IF in_file = -1 !unable to open file! THEN      BEGIN      CALL msg (msg_in_open, status);      CALL PROCESS_STOP_ (!phandle!,                          !specifier!,                          !options!,                          3 !Completion code ABEND!,                          !...!);      END;    END   !STATUS = 0  ELSE    BEGIN    CALL msg (msg_in_name, 0);    CALL PROCESS_STOP_ (!phandle!,                        !specifier!,                        !options!,                        3 !Completion code ABEND!,                        !...!);    END;  !STATUS <> 0  END;  !Of procedure IN_FILE_INIT

Modular Programming ExampleSample Programs
?SECTION read_in
INT PROC read_in (rec:rec_len);    STRING .EXT rec;    INT rec_len;  BEGIN  INT error;
CALL READX (in_file, rec, rec_len);
IF < THEN    BEGIN    error := FILE_GETINFO_ (in_file);    CALL msg (msg_read, error);    CALL PROCESS_STOP_ (!phandle!,                        !specifier!,                        !options!,                        3 !Completion code ABEND!,                        !...!);    END  ELSE    IF > THEN RETURN 1  ELSE    RETURN 0;
?SECTION in_close
PROC in_close;  BEGIN  CALL FILE_CLOSE_ (in_file);  END;?SECTION end_of_code_sections?NOMAP

Modular Programming ExampleSample Programs
Example A-6d shows the source code for the output file module.  This module declares
a private global data block, which is accessible only to procedures in this module.Some code that is parallel to code in the input file handler is not listed.
Example A-6d.  D-Series Output File Module (Page 1 of 3)
!File name OUTS
NAME out_file_handler;
?PUSHLIST, NOLIST, SOURCE recdefs          !BLOCK RECORD_DEFS
?POPLIST?PUSHLIST, NOLIST, SOURCE inits (default)  !BLOCK DEFAULT_VOL?POPLIST?PUSHLIST, NOLIST, SOURCE msgs (msglit)   !BLOCK MSG_LITERALS?POPLIST
BLOCK PRIVATE;
INT out_file;  END BLOCK;
```
               !Following are external procedure declarations
```
?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (?                                 FILE_CLOSE_, FILE_GETINFO_)?POPLIST?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (?                              FILE_OPEN_, FILENAME_RESOLVE_)?POPLIST?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (?                                      PROCESS_STOP_, WRITEX)?POPLIST?PUSHLIST, NOLIST, SOURCE msgp?POPLIST
?SECTION out_file_init
PROC out_file_init;  BEGIN  INT out_file_name_len := 7;  STRING .out_file_name[0:file_name_max_len - 1]                                            := [ "OUTFILE" ];  INT status;  status := FILENAME_RESOLVE_                         (out_file_name:out_file_name_len,                         out_file_name:file_name_max_len,                         out_file_name_len,                         !options!,                         !override_name:override_name_len!,                         !search:search_len!,                         def_vol_subvol:def_vol_subvol_len);

Modular Programming ExampleSample Programs
IF status = 0 !FEOK! THEN
```
    BEGIN    status := FILE_OPEN_ (out_file_name:out_file_name_len,                          out_file);    IF out_file = -1 !unable to open file! THEN      BEGIN      CALL msg (msg_out_open, status);      CALL PROCESS_STOP_ (!phandle!,                          !specifier!,                          !options!,                          3 !Completion code ABEND!,                          !...!);      END;    END   !Of THEN clause  ELSE    BEGIN    CALL msg (msg_out_name, 0);    CALL PROCESS_STOP_   (!phandle!,                          !specifier!,                          !options!,                          3 !Completion code ABEND!,                          !...!);    END;   !Of ELSE clause  END;
```
?SECTION write_out
PROC write_out (rec:rec_len);    STRING .EXT rec;    INT rec_len;  BEGIN  INT error;  CALL WRITEX (out_file, rec, rec_len);  IF < THEN    BEGIN    error := FILE_GETINFO_ (out_file);    CALL msg (msg_write, error);    CALL PROCESS_STOP_   (!phandle!,                          !specifier!,                          !options!,                          3 !Completion code ABEND!,                          !...!);    END;  END;  !Of WRITE_OUT

Modular Programming ExampleSample Programs
?SECTION out_close
PROC out_close;  BEGIN  CALL FILE_CLOSE_ (out_file);  END;?SECTION end_of_code_sections?NOMAP
Message Module
Example A-6e shows the message module listing.  The terminal number in the private
global data block is is accessible only to procedures in this module.
Example A-6e.  D-Series Message Module (Page 1 of  3)
!File name MSGS
NAME message_module;
?SECTION msglit                   !Define BLOCK MSG_LITERALS
BLOCK msg_literals;  LITERAL    msg_eof      = 0,    msg_in_open  = 1,    msg_in_name  = 2,    msg_read     = 3,    msg_out_open = 4,    msg_out_name = 5,    msg_write    = 6;  END BLOCK;?SECTION end_of_data_sections
BLOCK PRIVATE;
LITERAL term_name_max_len = 256;  INT term_file_number;  LITERAL msg_buf_end = 79;  END BLOCK;
```
               !Following are external procedure declarations
```
?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (?                                    FILE_CLOSE_, FILE_OPEN_)?POPLIST?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (?                                   NUMOUT, PROCESS_GETINFO_)?POPLIST?PUSHLIST, NOLIST, SOURCE $SYSTEM.SYSTEM.EXTDECS (WRITEX)?POPLIST

Modular Programming ExampleSample Programs
?SECTION msg_init
PROC msg_init;  BEGIN  INT term_name_len;  STRING .term_name[0:term_name_max_len - 1];  CALL PROCESS_GETINFO_(!process_handle!,                        !file_name:max_len!,                        !file_name_len!,                        !priority!,                        !moms_phandle!,                        term_name:term_name_max_len,                        term_name_len,                        !...! );  CALL FILE_OPEN_(term_name:term_name_len, term_file_number);  END;
?SECTION msg
PROC msg (number, altnum);  INT number, altnum;  BEGIN  STRING .buffer[0:msg_buf_end];  STRING .bufptr := @buffer;  CASE number OF    BEGIN    msg_eof ->      buffer ':='  " *** End of File "         -> @bufptr;    msg_in_open ->      buffer ':='  " *** In file open failed " -> @bufptr;    msg_in_name ->      buffer ':='  " *** Bad in file name "    -> @bufptr;    msg_read ->      buffer ':='  " *** Read error "          -> @bufptr;    msg_out_open ->      buffer ':='  " *** Out file open failed "-> @bufptr;    msg_out_name ->      buffer ':='  " *** Bad out file name "   -> @bufptr;    msg_write ->      buffer ':='  " *** Write error "         -> @bufptr;    OTHERWISE ->      ;    END;
```
    IF altnum <> 0 THEN
      BEGIN      CALL NUMOUT (bufptr, altnum, 10, 5);      @bufptr := @bufptr + 5;      END;
```

Modular Programming ExampleSample Programs
CALL WRITEX (term_file_number, buffer,
```
                                       @bufptr '-' @buffer);  END;  !Of MSG
```
?SECTION msg_close
PROC msg_close;  BEGIN  CALL FILE_CLOSE_ (term_file_number);  END;?SECTION end_of_data_sections?NOMAP
Compilation Maps
and StatisticsThe following compilation maps and statistics are shown for the preceding modular
programming example:
Entry-point load map
Data-block load map
Statistics for the mainline compilation
Entry-Point Load Map
Figure A-1 shows the entry-point load map for the modular programming example:
Figure A-1.  Entry-Point Load Map for Modular Program
ENTRY POINT MAP BY NAME
SP    PEP    Base      Limit     Entry    Attr  Name             Date          Time     Lang   Source File00    012    000737    000742    000737         CLOSE_ALL        1992-04-13    13:54    TAL    \XX.$VOL.PRG.INITS
00    004    000266    000331    000266         CONVERT          1992-04-13    13:54    TAL    \XX.$VOL.PRG.CONVERTS00    011    000721    000736    000721         FILE_INIT        1992-04-13    13:54    TAL    \XX.$VOL.PRG.INITS00    017    001133    001140    001133         IN_CLOSE         1992-04-13    12:59    TAL    \XX.$VOL.PRG.INS00    015    000767    001050    000773         IN_FILE_INIT     1992-04-13    12:59    TAL    \XX.$VOL.PRG.INS00    010    000421    000720    000421         MSG              1992-04-13    12:59    TAL    \XX.$VOL.PRG.MSGS00    021    001147    001154    001147         MSG_CLOSE        1992-04-13    12:59    TAL    \XX.$VOL.PRG.MSGS00    014    000751    000766    000751         MSG_INIT         1992-04-13    12:59    TAL    \XX.$VOL.PRG.MSGS00    020    001141    001146    001141         OUT_CLOSE        1992-04-13    12:59    TAL    \XX.$VOL.PRG.OUTS00    016    001051    001132    001055         OUT_FILE_INIT    1992-04-13    12:59    TAL    \XX.$VOL.PRG.OUTS00    002    000022    000111    000022         OUT_INIT         1992-04-13    13:54    TAL    \XX.$VOL.PRG.CONVERTS00    006    000340    000372    000340         READ_IN          1992-04-13    12:59    TAL    \XX.$VOL.PRG.INS00    003    000122    000265    000122         RECORD_CONVERT   1992-04-13    13:54    TAL    \XX.$VOL.PRG.CONVERTS00    013    000743    000750    000743    V    STARTUP          1992-04-13    13:52    TAL    \XX.PRG.INITS00    005    000332    000337    000332    M    TPRCONV          1992-04-13    13:54    TAL    \XX.$VOL.PRG.CONVERTS00    007    000373    000420    000373         WRITE_OUT        1992-04-13    12:59    TAL    \XX.$VOL.PRG.OUTS

Modular Programming ExampleSample Programs
Figure A-2 shows the data-block load map for the modular programming example:
Figure A-2.  Data-Block Load Map for Modular Program
DATA BLOCK MAP BY NAME
Base Limit Type Mode Name Date Time Lang Source File000005 000204 COMMON WORD .DEFAULT_VOL 1992-04-13 12:59 TAL \XX.$VOL.PRG.INITS
000003 000012 COMMON WORD DEFAULT_VOL 1992-04-13 12:59 TAL \XX.$VOL.PRG.INITS000000 000000 COMMON WORD IN_FILE_HANDLER 1992-04-13 12:59 TAL \XX.$VOL.PRG.INS000002 000002 COMMON WORD MESSAGE_MODULE 1992-04-13 12:58 TAL \XX.$VOL.PRG.MSGS000000 COMMON WORD MSG_LITERALS 1992-04-13 12:58 TAL \XX.$VOL.PRG.INP000001 000001 COMMON WORD OUT_FILE_HANDLER 1992-04-13 12:59 TAL \XX.$VOL.PRG.OUTS000000 COMMON WORD RECORD_DEFS 1992-04-13 12:59 TAL \XX.$VOL.PRG.MSGS
Mainline Compilation Statistics
Figure A-3 shows the mainline compilation statistics for the mainline module of the
modular programming example:
Figure A-3.  Compilation Statistics for Mainline Module
BINDER - OBJECT FILE BINDER - T9621D20 - (01JUN93) SYSTEM \XX
Object file \XX.$VOL.PRG.CONVERTO
TIMESTAMP  1993-04-13 17:44:49
```
         1  Code page         1  Data page
         0  Resident code pages         0  Extended data pages
         0  Top of stack location in words
         1  Code segment
         0  Binder Warnings
         0  Binder Errors
```
TAL - Transaction Application Language - T9250D20 - (01JUN93)
Number of compiler errors = 0Number of unsuppressed compiler warnings = 0Number of warnings suppressed by NOWARN = 0Maximum symbol table space used was = 19944 bytesNumber of source lines = 5646Compile cpu time - 00:00:01Total elapsed time - 00:00:19