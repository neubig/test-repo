# Index

Index
096254 Tandem Computers Incorporated Index–116-bit (standard) addressing  4-7
16-bit (standard) pointers  9-132-bit (extended) addressing  4-732-bit (extended) pointers  9-1
A
Accelerated object files  xxviii
Actual parameters
See  Parameters
Addition operator
signed  5-16unsigned  5-18
Address conversions
bit-shift operations  5-30byte-to-word
simple pointer initialization  9-4structure pointer initialization  9-14
reference parameters  11-35standard-to-extended
simple pointer assignment  9-8simple pointer initialization  9-5structure pointer assignment  9-17structure pointer initialization  9-16
word-to-byte
simple pointer assignment  9-8simple pointer initialization  9-4structure pointer initialization  9-14
Addressability
arrays  7-11definition structures  8-6referral structures  8-9
Addresses
as value parameters  11-26in simple pointers  9-3in simple pointers in structures  8-18in structure pointers  9-13in structure pointers in structures  8-20of arrays, assigning  7-13of procedures (PEP number)  11-52of variables  5-27

Index
Index–2 096254 Tandem Computers IncorporatedAddressing
definition structures  8-3performance guidelines  C-1referral structures  8-8template structures  8-7
Addressing modes
byte  4-5direct  4-6extended (32-bit) indirect  4-7indexing  4-7indirect  4-6standard (16-bit) indirect  4-7word  4-5
Aliases, data types   5-6Ampersand (&)
concatenated move (copy) operations  7-18prefix, template block name
allocation  14-17description  14-16listing  15-14
AND operator  5-22Arithmetic expressions
description  5-15in conditional expressions  5-21performance guidelines  C-3
Arithmetic operators
signed  5-16unsigned  5-18
Arrays
accessing  7-12addressability  7-11as reference parameters  11-30as structure items  8-9assignments  7-13by data type  7-4concatenating  7-18copying  7-14declaring  7-1indexing  7-12indirection  7-2initializing  7-2

Index
096254 Tandem Computers Incorporated Index–3Arrays (continued)
multidimensional
simulated by structures  8-13TAL and C guidelines  17-23
of arrays  8-9of structures
definition structures  8-3referral structures  8-8TAL and C guidelines  17-23
redefinitions  8-21scanning  7-19storage allocation  7-8TAL and C guidelines  17-19
ASCII character set  D-1ASSERT statement  12-17ASSIGN command, TACL product  E-8ASSIGN message, saving  17-44ASSIGN SSV command, TACL product  E-9Assignment expression  13-2Assignment statement
arrays  7-13simple pointers  9-7simple variables  6-4structure items  8-34structure pointers  9-16
Asterisk
See  *
AT keyword, BLOCK declaration  14-15
B
%B prefix,  binary constants  5-7
Banner, compiler listing  15-2BEGIN-END construct
compound statements  3-16count in compiler listing  15-4procedures  3-16structures  3-16subprocedures  3-16
BEGINCOMPILATION directive  14-23BELOW keyword, BLOCK declaration  14-15Binary number base  5-7

Index
Index–4 096254 Tandem Computers IncorporatedBinary-to-ASCII conversion program  A-5
Binder  14-5Binding object files
during compilation  14-6modular sample program  A-9overview  14-5run-time  14-6stand-alone Binder  14-6TAL and C for CRE  17-51
BINSERV
action of  14-1and SEARCH directive  14-12binding object files  14-6resolving external references  14-13specifying which one  E-6
Bit extractions  5-28Bit fields
bit-extraction operations  5-28manipulating in TAL and C  17-28UNSIGNED and C packed  17-29UNSIGNED data type  5-6
Bit operations
extractions  5-28shifts  5-29TAL and C guidelines  17-28
Bit shifts
description  5-29division by powers of 2  5-30multiplication by powers of 2  5-30user code segment access  B-9word-byte address conversions  5-30
Bitwise logical operators  5-20BIT_FILLER declaration  8-16BLOCK declarations
description  14-14in CREDECS declarations file  17-43in program structure  3-5in RTLDECS declarations file  17-43mixed-language programming  17-1

Index
096254 Tandem Computers Incorporated Index–5BLOCK declarations (continued)
modular sample program
named block  A-12private block  A-19
storage allocation  14-19
Boolean operators  5-22Bounds, upper and lower
arrays  7-1definition structures  8-3referral structures  8-8
Branch table form, labeled CASE statement  12-6BREAK command, Inspect product  16-5BREAK key, stopping programs  16-3Breakpoints, setting  16-5Built-in functions
See  Standard functions
BY keyword, FOR statement  12-12Byte  5-6Byte addressing  4-5BYTES keyword
group comparison expression  13-6move statement  7-15
C
C language
calling TAL  17-13TAL  and C guidelines  17-9
C LANGUAGE attribute, TAL procedures  17-2C-series system  xxviiiCALL statement  12-19Calling procedures
C calling TAL  17-13TAL calling C  17-12TAL calling TAL  12-19
Calling subprocedures  12-19$CARRY function  5-26Carry indicator, testing  5-26CASE expressions
description  13-3performance guidelines  C-3

Index
Index–6 096254 Tandem Computers IncorporatedCASE statement, labeled
branch table form  12-6conditional test form  12-6description  12-5modular sample program  A-20with CHECK directive  12-7with OPTIMIZE directive  12-7
CCE (condition code equal to)  5-25CCG (condition code greater than)  5-25CCL (condition code less than)  5-25char variables, TAL and C mixed programming  17-19Character set  D-1Character strings
format  5-10initializing with  6-2interlanguage correspondence  F-3maximum length  5-10
CHECK directive, with labeled CASE statement  12-7Circumflex (^) in identifiers  5-2CISC systems  xxviiiCLEAR command, Inspect product  16-8CLUDECS (CRE external declarations file)  17-43CLULIB (Common Language Utility library file of CRE)  17-43COBOL environment, ENV directive  17-39COBOL LANGUAGE attribute, TAL procedures  17-2Code segments
procedures in  11-1process environment  4-1
Code space
description  4-1items in arithmetic expressions  5-15
Code-address field, compiler listing  15-3Comments
format  3-14omitted parameters  3-14skipping over code  3-15
COMMON keyword, ENV
directive  17-39
Common Run-Time Environment
See  CRE
Comparing arrays  7-23Compilation command  14-2

Index
096254 Tandem Computers Incorporated Index–7Compilation statistics, compiler
listing  15-16
Compilation units
description  14-2naming  14-14order of components  3-3scope of identifiers  3-3structuring  3-1
Compiler
processes integrated with  14-1starting  14-2
Compiler directives
See  Directives
Compiler listing
banner  15-2compilation statistics  15-16compiler messages  15-2cross-references  15-11directives in  15-2innerlisting  15-7maps
file name map  15-10global map  15-9load map  15-13local map  15-6sublocal map  15-6
octal code  15-9page header  15-1procedure instruction mnemonics  15-9
source code  15-3address field  15-3BEGIN-END counter  15-4edit-file line numbers  15-3lexical-level counter  15-4
statement instruction
mnemonics  15-7
Compiling source files
command options  14-2getting started  2-4modular sample program  A-9
Completion codes from compiler  14-5Complex types, interlanguage correspondence  F-3

Index
Index–8 096254 Tandem Computers IncorporatedCompound statements  3-16
Concatenated move (copy)
operations  7-18
Condition code indicator, testing  5-25Conditional compilation
asterisk in listing  15-5directives (DEFINETOG, IF, ENDIF, IFNOT)  3-15
Conditional expressions
assigning  5-24description  5-21
Conditional statements  12-1Conditional test form, labeled CASE statement  12-6Constant expressions  5-1Constant lists
copying into arrays  7-14group comparison expressions  13-5initializing arrays  7-3move statement  7-14
Constants
arithmetic expressions  5-15group comparison expressions  13-5kinds of
character strings  5-10LITERALs  5-11numbers  5-7
move statement  7-15
Continuation directive lines  14-7Copying data
arrays  7-14simple pointers  9-9structure pointers  9-19structures  8-39
CPU, specifying for compiler  E-6CRE guidelines
advantages of using CRE  17-37coding guidelines  17-37data blocks of  17-39ENV directive  17-39errors in CRE math routines  17-49extended stack, support of  17-49HEAP directive  17-41initializing the CRE  17-44

Index
096254 Tandem Computers Incorporated Index–9CRE guidelines (continued)
object files, stopping  17-45run-time environment, specifying  17-39sample program  17-50spooling  17-47standard files, accessing  17-46user heap, accessing  17-41$RECEIVE, accessing  17-48
CREDECS (CRE external declarations file)
including in program  17-43sample program  17-50
CRELIB (CRE library file)  17-43#CRE_GLOBALS  (CRE control block)  17-39#CRE_HEAP  (CRE run-time heap)  17-39CRE_TERMINATOR_  17-45Cross-references
collecting with CROSSREF directive  14-26compiler listing  15-11
CROSSREF directive
and USEGLOBALS directive  14-23description  14-26
D
D suffix,  nonhexadecimal INT(32) numbers  5-8
%D suffix,  hexadecimal INT(32) numbers  5-8D-series system  xxviiiData access
arrays  7-12operands in expressions  5-27pointers in structures  8-36read-only arrays  7-24simple pointers  9-9structure pointers  9-18structures  8-27
Data blocks
CRE  17-39relocatable  14-14
Data declarations  3-4
See also  Variables
blocked  3-5global  3-5

Index
Index–10 096254 Tandem Computers IncorporatedData declarations (continued)
local  3-8sublocal  3-12unblocked  3-5
Data Definition Language (DDL)
and byte-aligned structures  17-21and type correspondence  F-1
Data sets
arrays  7-1structures  8-1
Data space  4-2Data types
compatibility with C data types  17-10description  5-4format  5-4interlanguage correspondence  F-2of Boolean operands  5-22of expressions  5-6of logical arithmetic operands  5-20of signed arithmetic operands  5-16of signed relational results  5-23of special expressions  13-1of unsigned arithmetic operands  5-19of unsigned relational results  5-23storage units  5-6
DATAPAGES directive, upper 32K-word area  B-2$DBL
structure pointers  9-22structures  8-30
$DBLL, accessing user code segment  B-9DDL
See  Data Definition Language
Debug product  16-4Debugging programs
debuggers  16-4displaying values  16-5sample session  16-6setting breakpoints  16-5stepping through  16-5
Decimal number base  5-7

Index
096254 Tandem Computers Incorporated Index–11Declarations
arrays  7-1BLOCKs  14-14equivalenced variables  10-1functions  11-8labels  11-48LITERALs  5-11NAME  14-14procedures  11-2simple pointers  9-2simple variables  6-1structure pointers  9-12structures  8-3subprocedures  11-15
DEFAULT DEFINE  E-6DEFINE command, TACL product  E-4DEFINEPOOL system procedure
extended data segment  B-16upper 32K-word area  B-7
DEFINETOG directive  3-15Definition structures
addressability  8-6as reference parameters  11-31declaring  8-3equivalenced  10-10storage allocation  8-4
Definition substructures
declaring  8-12redefinitions  8-23storage allocation  8-14
Dereferencing operator  5-27Direct addressing  4-6Directive lines  14-7Directive stacks, pushing and popping  14-8Directives
BEGINCOMPILATION  14-23compiler listing  15-2CROSSREF  14-26DATAPAGES  B-2DEFINETOG  3-15ENDIF  3-15ENV  17-39

Index
Index–12 096254 Tandem Computers IncorporatedDirectives (continued)
file names  14-9HEAP  17-41IF  3-15IFNOT  3-15overview of  3-18SAVEGLOBALS  14-23SEARCH  14-12, 14-23SOURCE  14-10specifying in compilation command  14-4specifying in source files  14-7USEGLOBALS  14-23
Disk file names  E-1DISPLAY command, Inspect product  16-5Displaying program values  16-5Division by powers of two  5-30Division operator
signed  5-16unsigned  5-18unsigned modulo  5-18
DO keyword
DO statement  12-10FOR statement  12-12WHILE statement  12-8
DO statement  12-10Documenting source code
See  Comments
Doubleword  5-6DOWNTO keyword, FOR statement  12-12DROP statement with FOR statement  12-15
E
E register  4-5
E suffix, REAL numbers  5-9Edit-file line numbers, compiler listing  15-3ELEMENTS keyword
group comparison expression  13-7move statement  7-16
Ellipsis (...) in labeled CASE statement  12-5

Index
096254 Tandem Computers Incorporated Index–13ELSE keyword
IF expression  13-4IF statement  12-2
ENDIF directive  3-15Entry points
entry-point identifiers
procedures  3-7subprocedures  3-11
procedure identifiers  3-7recorded in PEP and XEP tables  11-1subprocedure identifiers  3-11
Enumeration variables in C  17-27ENV directive  17-39Environment register  4-5Equivalenced variables
definition structures  10-10indexing  10-19kinds of  10-1referral structures  10-14simple pointers  10-6simple variables  10-2structure pointers  10-16
Error handling
ASSERT statement  12-17ASSERTION directive  12-17CRE math routine errors  17-49file-system errors  5-25hardware indicators, testing  5-25sample program
input file module  A-15output file module  A-18
Errors, run-time  16-3ESE instruction, EXTENSIBLE procedures  11-47Executing programs and object files
See  Running object files
Exponents
REAL numbers  5-9REAL(64) numbers  5-9

Index
Index–14 096254 Tandem Computers IncorporatedExpressions
arithmetic expression  5-15assignment expression  13-2Boolean operations  5-22CASE expression  13-3conditional expression  5-21constant expression  5-1data types  5-6description  5-1fixed-point, scaling of  5-17group comparison expression  13-5IF expression  13-4logical operations  5-20precedence of operators  5-13relational operations  5-23
.EXT (extended indirection symbol)
arrays  7-1definition structures  8-3referral structures  8-8simple pointers  9-2structure pointers  9-12
EXTDECS (system external declarations file)  14-11Extended data segments  4-2
automatic
allocation  4-10organization of  4-4TAL and C guidelines  17-33
explicit
accessing data  B-14creating  B-10managing  B-13, B-21TAL and C guidelines  17-33
size of  4-4
Extended indirection
description  4-7TAL and C guidelines  17-18
Extended pointers
accessing data
simple pointers  9-10structure pointers  9-22
accessing explicit extended data segments  B-10, B-14accessing user code segment  B-9

Index
096254 Tandem Computers Incorporated Index–15Extended pointers (continued)
declaring
simple pointers  9-2structure pointers  9-12
description  9-1format  B-1performance guidelines  C-1
Extended relocatable data blocks  14-17Extended stack
organization of  4-4pointers (#SX, #MX)  4-11storage allocation  4-11
$EXTENDED#STACK  4-11EXTENDED#STACK#POINTERS  4-11EXTENSIBLE procedures
checking for parameters ($PARAM)  11-10converting from VARIABLE  11-13declaring  11-10parameter area  11-45parameter masks  11-42passing as parameters  11-25procedure entry sequence  11-47
External declarations (SOURCE directive)  14-11External Entry Point table  11-1EXTERNAL procedure declarations  11-9External references (SEARCH directive)  14-12
F
F suffix, FIXED numbers  5-9
%F suffix, FIXED numbers  5-9File ID  E-2File name map, compiler listing  15-10File names
defaults, specifying  E-4directives that accept  14-9disk  E-1incomplete, resolving  E-9internal  E-4

Index
Index–16 096254 Tandem Computers IncorporatedFile names (continued)
logical
directives that accept  14-9TACL ASSIGN command  E-8TACL DEFINE command  E-4
File records
See  Structures
File type, interlanguage correspondence  F-4File-system errors, testing for  5-25FILLER declaration  8-16FIXED data type
arrays  7-6fpoint  6-11numeric constants  5-9range of values allowed  5-4scaling of operands  5-17simple variables  6-11
FIXED parameter type
description  11-20reference parameters  11-32value parameters  11-22
FIXED(*) data type
arrays  7-6range of values allowed  5-4simple variables  6-11
FIXED(*) parameter type  11-22Fixed-point
arithmetic  5-17implied setting  5-5interlanguage correspondence  F-3numbers
description  5-9ranges by data type  5-4
scaling  5-17setting (fpoint)  6-11
Floating-point
interlanguage correspondence  F-3numbers
description  5-9ranges by data type  5-4

Index
096254 Tandem Computers Incorporated Index–17FOR keyword
FOR statement  12-12group comparison expression  13-6move statement  7-15
FOR loops
See  FOR statement
FOR statement
description  12-12optimized  12-15standard  12-13
Formal parameters
See  Parameters
Format of programs  3-13FORTRAN environment, ENV directive  17-39FORTRAN LANGUAGE attribute, TAL procedures  17-2FORWARD procedures  11-8fpoint
of reference parameters  11-32of value parameters  11-22positive or negative  5-5scaling in expressions  5-17specifying  6-11
Fractions
FIXED numbers  5-9REAL numbers  5-9REAL(64) numbers  5-9
Functions
declaring and calling  11-8in arithmetic expressions  5-15RETURN statement  12-21standard, by categories  5-12
Future software platforms  xxviii
G
GETPOOL system procedure
extended data segment  B-16upper 32K-word area  B-7
Getting started  2-1

Index
Index–18 096254 Tandem Computers Incorporated#GLOBAL
allocation  14-17description  14-16listing  15-14
$#GLOBAL
description  14-17listing  15-14
.#GLOBAL
description  14-17listing  15-14
Global data
declaring  3-5scope of  3-3sharing C data with TAL modules
using BLOCK declarations  17-18using pointers  17-16
sharing TAL data with C modules
using pointers  17-15
Global data blocks
and SECTION directive  14-20and SOURCE directive  14-20declaring  14-14sharing among source files  14-20specifying locations of  14-15storage allocation  14-16
Global data declarations
blocked  14-14saving and retrieving  14-23unblocked  14-16
Global map, compiler listing  15-9Global scope
data  3-5data blocks, relocatable  3-5identifiers  3-3procedure entry points  3-7procedures  3-6
Global storage area
extended data segment  4-4user data segment  4-9

Index
096254 Tandem Computers Incorporated Index–19GOTO statement
description  12-24local (with local labels)  11-48sublocal (with local labels)  11-49sublocal (with sublocal labels)  11-50
Group comparison expressions
description  13-5in conditional expressions  5-21
H
%H prefix,  hexadecimal constants  5-7
Hardware indicators, testing  5-25HEAP directive  17-41#HEAP (CRE user heap)  17-41Hexadecimal number base  5-7
I
I register  4-5
I/O
See  Input/output
Identifiers
rules for specifying  5-2scope of  3-3structure pointers, qualifying  9-18structures, qualifying  8-27TAL and C guidelines  17-9
IF directive  3-15IF expressions
description  13-4modular sample program  A-16performance guidelines  C-3
IF statement
description  12-2sample program
binary-to-ASCII conversion  A-6input file module  A-15mainline module  A-10message module  A-20string entry  A-3
IFNOT directive  3-15Implicit pointers  4-6

Index
Index–20 096254 Tandem Computers IncorporatedImproving performance
addressing  C-1arithmetic expressions  C-3general guidelines  C-1indexing  C-2STACK and STORE statements  C-2
IN file
compilation command  14-2RUN command  16-1
Index registers, as value parameters  11-27Indexing
arrays  7-12description  4-7equivalenced variables  10-19performance guidelines  C-2simple pointers  9-10structure pointers  9-20, 9-22structures  8-28, 8-30upper 32K-word area  B-8
Indirection
arrays  7-2definition structures  8-3description  4-6TAL and C guidelines  17-18
INHIBITXX directive
and indexing
structure pointers  9-23structures  8-30
and relocatable data blocks  14-21with USEGLOBALS  14-25
Initialization module, sample program  A-12Initializations
arrays  7-2simple pointers  9-3simple variables  6-2structure pointers  9-13
INNERLIST compiler listing  15-7Input file module, sample program  A-14

Index
096254 Tandem Computers Incorporated Index–21Input/output sample programs
input file module  A-14output file module  A-17string display  A-1string entry  A-3
Inspect product
and SYMBOLS directive  16-4commands
BREAK  16-5CLEAR  16-8DISPLAY  16-5RESUME  16-8STEP  16-5STOP  16-5
overview  16-4sample session  16-6specifying  16-4starting  16-4stopping  16-5
Instruction register  4-5INT attribute, structure pointers  9-13INT data type
arrays  7-5numeric constants  5-8range of values allowed  5-4simple variables  6-6
INT parameter type  11-20INT(16), alias of INT  5-4, 5-6INT(32) data type
arrays  7-5numeric constants  5-8range of values allowed  5-4simple variables  6-8
INT(32) parameter type  11-20INT(64), alias of FIXED(0)  5-4, 5-6INT32INDEX directive
extended indexing
structure pointers  9-24structures  8-32
with USEGLOBALS  14-25

Index
Index–22 096254 Tandem Computers IncorporatedIntegers
by data type  5-8interlanguage correspondence  F-2
Interface declaration in C  17-13Interlanguage type correspondence
character strings  F-3complex  F-3files  F-4fixed  F-3floating  F-3integers  F-2logical  F-4pointers  F-5sets  F-4structures  F-4
Internal file names  E-4
K
Keywords  5-3
LL register  4-5
L suffix, REAL(64) numbers  5-9Labeled CASE statement
See  CASE statement, labeled
Labels
declaring and using  11-48local (with local GOTOs)  11-48local (with sublocal GOTOs)  11-49local (with sublocal variables)  11-49local scope  3-8sublocal (with sublocal GOTOs)  11-50sublocal scope  3-12undeclared  11-51
LAND operator  5-20LANGUAGE attribute, procedures  17-2Layout
definition structures  8-3structures  8-2substructures  8-12template structures  8-7

Index
096254 Tandem Computers Incorporated Index–23Left shifts, bit  5-29
Lexical-level counter, compiler listing  15-4LIB option, RUN command  16-1Library code space  4-1LIBRARY directive  14-6Library file, binding  14-6Limitations
See Size
Line length, maximum  3-13Listings
See  Compiler listing
LITERALs
declaring  5-11in arithmetic expressions  5-15modular sample program  A-19with C enumeration variables  17-27
Load map, compiler listing  15-13Local data
accessing  11-4declaring  3-8scope of  3-3
Local map, compiler listing  15-6Local register  4-5Local scope
data  3-8identifiers  3-3labels  3-8statements  3-8subprocedure entry points  3-11subprocedures  3-10
Local storage area  4-9Logical file names
in directives  14-9TACL ASSIGN command  E-8TACL DEFINE command  E-4
Logical operators  5-20Logical type, interlanguage correspondence  F-4LOR operator  5-20Lower 32K-word area  4-2

Index
Index–24 096254 Tandem Computers IncorporatedM
MAIN procedures  11-7
Mainline module, sample program  A-10Manuals
program development  xxxprogramming  xxxsystem  xxix
MAP DEFINE command  E-5#MCB (CRE master control block)  17-39MEM option, RUN command  16-2Memory models, TAL and C guidelines  17-11Message module, sample program  A-19Minus operator
binary signed  5-16binary unsigned  5-18unary  5-16
Mixed-language programming
BLOCK declarations  17-1CRE guidelines  17-37LANGUAGE attribute, procedures  17-2NAME declarations  17-1parameter pairs  17-6procedure public name  17-3routines as parameters  17-4TAL and C guidelines  17-9
Modular programming
compiling with saved global data  14-23declaring relocatable data blocks  14-14description  3-1sample program  A-7
Modulo division operator  5-18Move statement
arrays  7-14sample program
binary-to-ASCII conversion  A-6mainline module  A-11string display  A-1string entry  A-3
simple pointers  9-9structure pointers  9-19structures  8-39

Index
096254 Tandem Computers Incorporated Index–25Multidimensional arrays  8-13
Multiplication by powers of two  5-30Multiplication operator
signed  5-16unsigned  5-18
#MX (extended stack pointer)  4-11
N
NAME declarations
description  14-14in program structure  3-5mixed-language programming  17-1sample program
CRE  17-50mainline module  A-10
Named data blocks
See  NAME declarations
NEUTRAL  keyword, ENV directive  17-39Next address
group comparison expression  13-7move statement  7-17
NOCROSSREF directive  14-26Node name in file names  E-2NOLIST directive and SOURCE  14-10NOT operator  5-22NOWAIT option, RUN command  16-2Null statements  3-18Number bases, formats of  5-7Numbers, description by data type  5-8
O
Object files
binding  14-5description  14-1generating  14-2running
getting started  2-5with run-time options  16-1
stopping
CRE_TERMINATOR_  17-45TACL STOP command  16-3

Index
Index–26 096254 Tandem Computers IncorporatedObject files, accelerated  xxviii
OBJECT, default target file  14-4Octal code, compiler listing  15-9Octal number base  5-7OF keyword
CASE expression  13-3CASE statement, labeled  12-5
Offsets, equivalenced variables  10-19OLD keyword, ENV directive  17-39Operands
accessing  5-27in arithmetic expressions  5-15in expressions  5-2
Operators
arithmetic
signed  5-16unsigned  5-18
bit-shift  5-29Boolean  5-22in expressions  5-13logical  5-20precedence of  5-13relational  5-23
OPTIMIZE directive, labeled CASE statement  12-7$OPTIONAL function  11-12OR operator  5-22OTHERWISE keyword
CASE expression  13-3CASE statement, labeled  12-5
OUT file
compilation command  14-2RUN command  16-1
Output file module, sample program  A-17Overflow
causes of  5-26handling CRE math routine errors  17-49
P
P register  4-5
P-relative arrays  7-24Page header, compiler listing  15-1

Index
096254 Tandem Computers Incorporated Index–27$PARAM, checking for parameters
EXTENSIBLE procedures  11-10VARIABLE procedures  11-9
PARAM BINSERV command  E-6PARAM message, saving  17-44PARAM SAMECPU command  E-6PARAM SWAPVOL command  E-7PARAM SYMSERV command  E-7Parameter area
procedures  11-36
EXTENSIBLE  11-45VARIABLE  11-40
subprocedures  11-36
Parameter list
procedures  11-3subprocedures  11-15
Parameter masks
EXTENSIBLE procedures  11-42procedures as parameters  11-25VARIABLE procedures  11-38
Parameter pairs
declaring  17-6passing
conditionally  11-12mixed-language guidelines  17-7unconditionally  11-11
Parameter types  11-20Parameters
See also  Reference parameters
See also  Value parameters
address conversions by compiler  11-35checking with $PARAM
EXTENSIBLE procedures  11-10VARIABLE procedures  11-9
declaring
in procedures  11-3
in subprocedures  11-15passing  12-19
conditionally  11-12unconditionally  11-11
run-time  16-3

Index
Index–28 096254 Tandem Computers IncorporatedParameters (continued)
scope of  11-36specifications  11-20
PASCAL LANGUAGE attribute, TAL procedures  17-2Pascal variant parts, emulating  10-21Passing parameters
CALL statement  12-19conditionally  11-12unconditionally  11-11
PEP table  11-1Performance guidelines
addressing  C-1arithmetic expressions  C-3general  C-1indexing  C-2STACK and STORE statements  C-2
Platforms, software  xxviiiPlus operator
binary signed  5-16binary unsigned  5-18unary  5-16
Pointers
accessing explicit extended data segments  B-10accessing upper 32K-word area  B-2as reference parameters  11-33as structure items  8-35equivalencing
simple pointers  10-6structure pointers  10-16
extended (32-bit) pointers  9-1implicit pointers  4-6interlanguage correspondence  F-5simple pointers  9-2standard (16-bit) pointers  9-1structure pointers  9-12TAL and C guidelines  17-25
POP prefix, directives  14-8Precedence of operators  5-13Primary relocatable data blocks  14-17Primary storage (global, local, sublocal)
allocation in  4-8description  4-9

Index
096254 Tandem Computers Incorporated Index–29PRINTSYM directive (with USEGLOBALS)  14-25
Private data area, as a TAL feature  1-1Private data blocks
declaring  14-15in program structure  3-5
PRIVATE keyword, BLOCK declaration  14-15PROC keyword
function declaration  11-8procedure declaration  11-2
PROC parameter type
description  11-23mixed-language programming  17-4passing C routines to TAL  17-32passing TAL routines to C  17-30
PROC(32) parameter type
description  11-24mixed-language programming  17-5passing C routines to TAL  17-32passing TAL routines to C  17-30
Procedure Entry Point table  11-1Procedure entry sequence  11-47Procedure mnemonics, compiler listing  15-9Procedures
address of (PEP number)  11-52as parameters  11-22
See  Value parameters
calling  11-2compared to subprocedures  11-14declaring  11-2EXTENSIBLE  11-10EXTERNAL  11-9FORWARD  11-8functions  11-8LANGUAGE attribute  17-2MAIN  11-7parameters  11-3public name  17-3RETURN statement  12-21scope of  3-6storage allocation  11-5

Index
Index–30 096254 Tandem Computers IncorporatedProcedures (continued)
typed
See  Functions
VARIABLE  11-9
Process environment  4-1Processes  4-1Processor, specifying for compiler  E-6Program control
ASSERT statement  12-17CALL statement  12-19CASE statement, labeled  12-5conditional expressions  5-21DO statement  12-10FOR statement  12-12GOTO statement  12-24IF statement  12-2labeled CASE statement  12-5relational expressions  5-24RETURN statement  12-21WHILE statement  12-8
Program flow, controlling  12-1Program register  4-5Programs
See also  Object files
formatting  3-13modular  3-1structuring  3-1
Public name, procedures  17-3PUSH prefix, directives  14-8PUTPOOL system procedure
extended data segment  B-16upper 32K-word area  B-7
Q
Quadrupleword  5-6
Question mark (?) (directive line symbol)  14-7Quotation mark (") (character string delimiter)  5-10

Index
096254 Tandem Computers Incorporated Index–31R
Ranges, data types  5-4
Read-only arrays  7-24REAL data type
arrays  7-5numeric constants  5-9range of values allowed  5-4simple variables  6-9
REAL parameter type  11-20REAL(32), alias of REAL  5-4, 5-6REAL(64) data type
arrays  7-6numeric constants  5-9range of values allowed  5-4simple variables  6-10
REAL(64) parameter type  11-20$RECEIVE, accessing in the CRE  17-48Records
See  Structures
Recursion, as a TAL feature  1-2Redefinitions
arrays  8-21definition substructures  8-23referral substructures  8-25simple pointers  8-26simple variables  8-21structure pointers  8-26TAL and C guidelines  17-24
Reference parameters
address conversions by compiler  11-35array size  11-30arrays  11-30declaring  11-3description  11-29number of structure occurrences  11-32pointers  11-33simple variables  11-29specifications  11-20storage allocation  11-29structures  11-31

Index
Index–32 096254 Tandem Computers IncorporatedReferral structures
addressability  8-9addressing  8-8as reference parameters  11-32declaring  8-8equivalenced  10-14storage allocation  8-9
Referral substructures
declaring  8-15redefinitions  8-25storage allocation  8-15
Register pointer  4-5Register stack
description  4-5performance guidelines  C-2
Registers in process environment  4-5Relational expressions
description  5-21program flow, controlling  5-24
Relational operators
conditional expressions  5-21group comparison expression  13-9signed  5-23testing condition code indicator  5-25unsigned  5-23
Relocatable data blocks
declaring  14-14directives for  14-21
RELOCATE directive  14-21Reserved keywords  5-3RESUME command, Inspect product  16-8RETURN statement
description  12-21modular sample program  A-16
Return types
functions  11-8interlanguage correspondence  F-2
Returning from procedures  11-7Right shifts, bit  5-29RISC systems  xxviiiRoutines  1-3RP  4-5

Index
096254 Tandem Computers Incorporated Index–33RSCAN statement
arrays  7-19example  7-21
RTLDECS (CRE external declarations file)  17-43RUN command, TACL product
running object files  16-1running the compiler  14-2
Run-time environment, specifying with ENV directive  17-39Run-time errors  16-3Run-time libraries
CLULIB  17-43CRELIB  17-43TALLIB  17-43
Run-time library, TALLIB  17-44RUND command, TACL product  16-4Running object files
getting started  2-5with run-time options  16-1
Running programs
See  Running object files
S
S register  4-5
Saved Messages Utility routines  17-43SAVEGLOBALS directive  14-23Saving system messages  17-44$SCALE, scaling FIXED values  5-17Scaling, FIXED values  5-17SCAN statement
arrays  7-19sample program (string entry)  A-3simple pointers  9-9structure pointers  9-18
Scope
global  3-5of identifiers  3-3of parameters  11-36
SEARCH directive
compiling with search lists  14-12retrieving saved global initializations  14-23
Search lists  14-12

Index
Index–34 096254 Tandem Computers IncorporatedSearch subvolume command  E-9
Secondary relocatable data blocks  14-17Secondary storage (global, local)
allocation in  4-8description  4-10
SECTION directive
and global data blocks  14-20and SOURCE directive  14-10
Section names, in SOURCE directive  14-10Segment specifier, extended pointer  B-2SEGMENT_ALLOCATE_
TAL and C guidelines  17-33TAL guidelines  B-10
SEGMENT_DEALLOCATE_
TAL and C guidelines  17-33TAL guidelines  B-10
SEGMENT_USE_
TAL and C guidelines  17-33TAL guidelines  B-10
Selector
CASE expression  13-3CASE statement, labeled  12-5
Semicolon  3-17Separate compilation
compiling with saved global data  14-23declaring relocatable global data blocks  14-14of source files  3-1sample program  A-7
Set type, interlanguage correspondence  F-4Sharing data
C data with TAL modules
using BLOCK declarations  17-18using pointers  17-16
TAL and C general guidelines  17-15TAL data with C modules
using BLOCK declarations  17-18using pointers  17-15
Shifts, bit  5-29

Index
096254 Tandem Computers Incorporated Index–35Simple pointers
accessing data
assignment statement  9-7, 9-9indexing  9-10move and SCAN statements  9-9upper 32K-word area  B-2
addresses in  9-3as structure items  8-17declaring  9-2equivalenced  10-6redefinitions  8-26storage allocation  9-6@ operator  9-3, 9-7
Simple variables
accessing  6-4as reference parameters  11-29as structure items  8-9as value parameters  11-21assignments  6-4by data type  6-5declaring  6-1dereferencing  5-27equivalenced  10-2initializing  6-2redefinitions  8-21storage allocation  6-3
Size
character strings  5-10code segments  4-1combined primary global data blocks  14-17data types  5-4definition structures  8-3extended data segments  4-4extended stack  4-11identifiers  5-2indexes
structure pointers  9-21structures  8-30
parameter area
procedures  11-36subprocedures  11-36
primary storage areas (global, local, sublocal)  4-9

Index
Index–36 096254 Tandem Computers IncorporatedSize (continued)
procedures  11-1referral structure occurrences  8-8referral structures  8-8secondary storage areas  4-10storage units  5-6sublocal storage area  11-15user data segment  4-2
SMU (Saved Messages Utility) routines  17-43Software platforms, future  xxviiiSource code, compiler listing  15-3SOURCE directive
and global data blocks  14-20compiling with  14-10effect on other directives  14-10
Source files  14-1
compiling  2-4, 14-2creating  2-2modular  3-1modular sample program  A-9
Special expressions  13-1
assignment expression  13-2CASE expression  13-3data types  13-1group comparison expression  13-5IF expression  13-4
SPOOL DEFINE command  E-5Spooler
accessing in the CRE  17-47settings, specifying
CRE_SPOOL_START_  17-47TACL SPOOL DEFINE command  E-5
SSV, TACL ASSIGN commands  E-9Stack register  4-5STACK statement, performance guidelines  C-2Standard files, CRE  17-46Standard functions
by categories  5-12for arrays  7-23for structures  8-43

Index
096254 Tandem Computers Incorporated Index–37Standard indirection
description  4-7TAL and C guidelines  17-18
Standard input file, CRE  17-46Standard log file, CRE  17-46Standard output file, CRE  17-46Standard pointers
accessing data
simple pointers  9-9structure pointers  9-18
declaring
simple pointers  9-2structure pointers  9-12
description  9-1
Startup message, saving  17-44Statement mnemonics, compiler listing  15-7Statements
ASSERT  12-17assignment
arrays  7-13simple pointers  9-7simple variables  6-4structure items  8-34structure pointers  9-16
CALL  12-19CASE, labeled  12-5DO  12-10FOR  12-12GOTO  12-24IF  12-2local scope  3-8move
arrays  7-14simple pointers  9-9structure pointers  9-19structures  8-39
RETURN  12-21RSCAN  7-19SCAN
arrays  7-19simple pointers  9-9structure pointers  9-18

Index
Index–38 096254 Tandem Computers IncorporatedStatements (continued)
sublocal scope  3-12WHILE  12-8
STEP command, Inspect product  16-5Stepping through programs  16-5STOP command
Inspect product  16-5TACL product  16-3
Stopping Inspect product  16-5Stopping object files
CRE_TERMINATOR_  17-45TACL STOP command  16-3
Storage allocation
arrays  7-8arrays in structures  8-10definition structures  8-4definition substructures  8-14extended data segment
automatic  4-10explicit  B-13, B-21
global data blocks  14-16object files bound with BLOCKs  14-19parameter areas
EXTENSIBLE procedures  11-45procedure  11-36subprocedure  11-36VARIABLE procedures  11-40
parameters
reference  11-29value  11-21
procedure variables  11-5referral structures  8-9referral substructures  8-15simple pointers  9-6simple pointers in structures  8-18simple variables  6-3simple variables in structures  8-10structure pointers  9-16structure pointers in structures  8-20

Index
096254 Tandem Computers Incorporated Index–39Storage allocation (continued)
user data segment
lower 32K-word area  4-8upper 32K-word area  B-5
variables  4-8
Storage units, by data type  5-6STORE statement, performance guidelines  C-2STRING and C char variables  17-19STRING attribute, structure pointers  9-13STRING data type
arrays  7-4numeric constants  5-8range of values allowed  5-4simple variables  6-5
STRING parameter type  11-20, 11-22String-display sample program  A-1String-entry sample program  A-3Strings, character  5-10STRUCT keyword, structures  8-3Structure data items
arrays  8-9definition substructures  8-12referral substructures  8-15simple pointers  8-17simple variables  8-9structure pointers  8-19
Structure items
See also  Structure data items
filler declarations  8-16
Structure pointers
accessing data
indexing  9-20move statement  9-19scan statements  9-18
as structure items  8-19assignments
to data  9-18to pointers  9-16
declaring  9-12equivalenced  10-16identifiers, qualifying  9-18initialization  9-14

Index
Index–40 096254 Tandem Computers IncorporatedStructure pointers (continued)
redefinitions  8-26storage allocation  9-16upper 32K-word area
copying data to  B-6storing addresses  B-4
$OFFSET function  9-14
Structures
accessing  8-27as parameters  11-31assignments  8-34declaring  8-1definition structure  8-3equivalenced
definition structures  10-10referral structures  10-14
identifiers, qualifying  8-27indexing  8-28indirection
definition structures  8-3referral structures  8-8
interlanguage correspondence  F-4kinds of  8-1layout  8-2referral structures  8-8storage allocation  8-4TAL and C guidelines  17-20template structures  8-7
Structuring programs  3-1Sublocal data
declaring  3-12scope of  3-3
Sublocal map, compiler listing  15-6Sublocal scope
data  3-12identifiers  3-3, 11-16labels  3-12statements  3-12

Index
096254 Tandem Computers Incorporated Index–41Sublocal storage
description  4-9formal parameters  11-15limitations
parameters  11-18variables  11-17
parameter area  11-36
Sublocal variables  11-16Subprocedures
address of (PEP number)  11-52compared to procedures  11-14declaring  11-15in program structure  3-10parameter area  11-36parameters  11-15RETURN statement  12-21sublocal storage area
limitations, parameters  11-18limitations, variables  11-17size  11-15
TAL and C guidelines  17-21
Substructures
declaring  8-12definition substructures  8-12referral substructures  8-15storage allocation  8-15TAL and C guidelines  17-21
Subtraction operator
signed  5-16unsigned  5-18
Subvolume name
defaults, specifying  E-4in file names  E-2
Suspending execution  16-5Swap volume
DEFAULT DEFINE  E-6PARAM SWAPVOL command  E-7
#SX (extended stack pointer)  4-11SYMBOLS directive (with USEGLOBALS)  14-25SYMSERV
description  14-1specifying which one  E-7

Index
Index–42 096254 Tandem Computers IncorporatedSYNTAX directive (with USEGLOBALS)  14-25
System code space  4-5System library space  4-5System messages, saving  17-44System name, in file names  E-2System procedures
overview of  2-3sample program
mainline module  A-12string display  A-1string entry  A-3
with SOURCE directive  14-11
System services  1-3Systems supported by TAL  xxviii
T
TACL commands
ASSIGN  E-8ASSIGN SSV  E-9DEFINE  E-4directives that accept  14-9PARAM  E-6RUN (running object files)  16-1RUND (debugging object files)  16-4starting the compiler  14-2STOP  16-3
TAL and C guidelines
arrays  17-19arrays of structures  17-23bit-field manipulation  17-28C calling TAL  17-13C enumeration variables  17-27data sharing  17-15data types  17-10identifiers  17-9indirection  17-18memory usage  17-11multidimensional arrays  17-23passing C routines to TAL  17-32passing TAL routines to C  17-30pointers  17-25

Index
096254 Tandem Computers Incorporated Index–43TAL and C guidelines (continued)
redefinitions and C unions  17-24structures  17-20TAL calling C  17-12UNSIGNED and C bit fields  17-29
TAL calling C  17-12TALLIB (TAL library file)  17-43TAL_CRE_INITIALIZER_  17-44Tandem NonStop Series system  xxviiiTandem NonStop Series/RISC system  xxviiiTAPE DEFINE command  E-5Target file
binding  14-6compilation command option  14-4
Template blocks 
allocation  14-17description  14-16
Template structures  8-7Temporary files, specifying volume  E-7Temporary pointer
See  Dereferencing operator
Terminating
See  Stopping
THEN keyword
IF expression  13-4IF statement  12-2
TNS system  xxviiiTNS/R system  xxviiiTO keyword, FOR statement  12-12Typed procedures
See  Functions
U
Underscore (_) in identifiers  5-2
Unions, C version of redefinitions  17-24UNSIGNED data type
arrays  7-7range of values allowed  5-4simple variables  6-13TAL and C guidelines  17-29
UNSIGNED parameter type  11-20

Index
Index–44 096254 Tandem Computers IncorporatedUNSPECIFIED language attribute, procedures  17-2
UNTIL keyword, DO statement  12-10Upper 32K-word area
accessing  B-2indexing  B-8managing storage allocation  B-5organization  4-2
USE statement with FOR statement  12-15USEGLOBALS directive
and CROSSREF directive  14-26compiling with saved globals  14-23
User code segment
accessing  B-9description  4-1
User code space  4-1User data segment
description  4-2organization  4-3specifying size with DATAPAGES directive  B-2storage allocation  4-8
User heap, CRE  17-41
V
Value parameters
addresses  11-26declaring  11-3description  11-21index registers  11-27procedures as parameters
EXTENSIBLE  11-25mixed-language programming  17-4passing C routines to TAL  17-32passing TAL routines to C  17-30PROC  11-23PROC(32)  11-24that have parameters  11-24VARIABLE  11-25
simple variables  11-21specifications  11-20storage allocation  11-21

Index
096254 Tandem Computers Incorporated Index–45VARIABLE procedures
checking for parameters ($PARAM)  11-9converting to EXTENSIBLE  11-13declaring  11-9parameter areas  11-40parameter masks  11-38passing as parameters  11-25sample program
initialization module  A-13string display  A-1
Variables
getting the address of  5-27in arithmetic expressions  5-15kinds of  5-7
arrays  7-1pointers  9-1simple variables  6-1structures  8-1
Variant parts, emulating  10-21Volume name
defaults
DEFAULT DEFINE  E-6specifying  E-4
in file names  E-2
W
WHILE keyword, WHILE statement  12-8
WHILE statement
description  12-8sample program
binary-to-ASCII conversion  A-6mainline module  A-11string entry  A-3
width (INT, REAL, UNSIGNED)  5-5Word  5-6Word addressing  4-5WORDS keyword
group comparison expression  13-6move statement  7-16

Index
Index–46 096254 Tandem Computers IncorporatedX
$XADR
procedures as parameters  11-24upper 32K-word area  B-8
XEP table  11-1XOR operator  5-20
Z
ZZBInnnn target file  14-4
Special characters" (character string delimiter)  5-10
#CRE_GLOBALS  (CRE control block)  17-39#CRE_HEAP  (CRE run-time heap)  17-39#GLOBAL
allocation  14-17description  14-16listing  15-14
#HEAP (CRE user heap)  17-41#MCB (CRE master control block)  17-39#MX (extended stack pointer)  4-11#SX (extended stack pointer)  4-11$#GLOBAL
description  14-17listing  15-14
$CARRY function  5-26$DBL
structure pointers  9-22structures  8-30
$DBLL, accessing user code segment  B-9$EXTENDED#STACK  4-11$OPTIONAL function  11-12$PARAM, checking for parameters
EXTENSIBLE procedures  11-10VARIABLE procedures  11-9
$RECEIVE, accessing in the CRE  17-48$SCALE, scaling FIXED values  5-17$XADR
procedures as parameters  11-24upper 32K-word area  B-8
% prefix,  octal constants  5-7

Index
096254 Tandem Computers Incorporated Index–47%B prefix,  binary constants  5-7
%D suffix,  hexadecimal INT(32) numbers  5-8%F suffix, FIXED numbers  5-9%H prefix,  hexadecimal constants  5-7&
concatenated move (copy) operations  7-18prefix, template block name
allocation  14-17description  14-16,listing  15-14
'*' (unsigned multiplication)  5-18'+' (unsigned addition)  5-18'-' (unsigned subtraction)  5-18'/' (unsigned division)  5-18'<' (unsigned less than)  5-23'<<' (unsigned left shift)  5-29'<=' (unsigned less than or equal to)  5-23'<>' (unsigned not equal to)  5-23'=' (unsigned equal to)  5-23':=' (left-to-right move operator)  7-14'=:' (right-to-left move operator)  7-14'>' (unsigned greater than)  5-23'>=' (unsigned greater than or equal to)  5-23'>>' (unsigned right shift)  5-29'\' (unsigned modulo division)  5-18( ) in expressions  5-14(*)
FIXED(*) data type  5-5template structures  8-7
* (asterisk)
in compiler listing  15-5repetition factor, constant list  7-14signed multiplication  5-16
+
binary signed addition  5-16unary plus  5-16
binary signed subtraction  5-16unary minus  5-16
-> (CASE statement, labeled)  12-5

Index
Index–48 096254 Tandem Computers Incorporated-> (next-address symbol)
group comparison expression  13-7move statement  7-17
. (period)
bit extractions  5-28dereferencing operator  5-27in file names  E-2
. (standard indirection symbol)
arrays  7-1definition structures  8-3referral structures  8-8simple pointers  9-2structure pointers  9-12
.. (ellipsis in labeled CASE statement  12-5.#GLOBAL
description  14-17listing  15-14
.EXT (extended indirection symbol)
arrays  7-1definition structures  8-3referral structures  8-8simple pointers  9-2structure pointers  9-12
/ (signed division)  5-16; (semicolon)  3-17< (signed less than)  5-23<< (signed left shift)  5-29<= (signed less than or equal to)  5-23<> (signed not equal to)  5-23<n:n> (bit-extraction field)  5-28= (signed equal to)  5-23> (signed greater than)  5-23>= (signed greater than or equal to)  5-23>> (signed right shift)  5-29? (directive line symbol)  14-7@ operator
pointers  9-3procedure/subprocedure addresses  11-52procedures as parameters  11-24
[constant]
group comparison expression  13-5move statement  7-15