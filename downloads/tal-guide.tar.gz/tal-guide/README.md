# TAL Programmer's Guide

## Document Information

- **Title**: TAL (Transaction Application Language) Programmer's Guide
- **Part Number**: 096254
- **Edition**: Second
- **Published**: September 1993
- **Product Version**: TAL C30, TAL D10, TAL D20
- **Release ID**: D20.00
- **Publisher**: Tandem Computers Incorporated

## About This Document

This manual provides usage information for TAL (Transaction Application Language) and the TAL compiler for system and application programmers. TAL is a high-level, block-structured language that works efficiently with system hardware to provide optimal object program performance.

The TAL compiler compiles TAL source programs into executable object programs that execute under control of the Tandem NonStop Kernel.

## Document Organization

This guide is organized into sections covering different aspects of TAL programming, from introductory concepts to advanced topics, followed by practical appendices.

### [Front Matter](00-front-matter.md)
Title page, document history, and publication information.

---

## Main Sections

### Getting Started

1. **[Introducing TAL](sections/section-01.md)** - Overview of TAL features and capabilities
2. **[Getting Started](sections/section-02.md)** - How to create, compile, and run TAL programs
3. **[Structuring Programs](sections/section-03.md)** - Program structure and organization

### Core Concepts

4. **[Introducing the Environment](sections/section-04.md)** - Process environment, addressing modes, and storage allocation
5. **[Using Expressions](sections/section-05.md)** - Arithmetic and conditional expressions
6. **[Using Simple Variables](sections/section-06.md)** - Working with basic data types

### Data Structures

7. **[Using Arrays](sections/section-07.md)** - Array declaration, manipulation, and operations
8. **[Using Structures](sections/section-08.md)** - Complex data structures and their usage
9. **[Using Pointers](sections/section-09.md)** - Pointer operations and memory management
10. **[Using Equivalenced Variables](sections/section-10.md)** - Variable equivalencing and memory sharing

### Program Flow and Procedures

11. **[Using Procedures](sections/section-11.md)** - Procedure declaration, parameters, and calling conventions
12. **[Controlling Program Flow](sections/section-12.md)** - Control structures and program flow
13. **[Using Special Expressions](sections/section-13.md)** - Advanced expression features

### Development and Debugging

14. **[Compiling Programs](sections/section-14.md)** - Compilation process and compiler directives
15. **[Compiler Listing](sections/section-15.md)** - Understanding compiler output
16. **[Running and Debugging](sections/section-16.md)** - Program execution and debugging techniques

---

## Appendices

- **[Appendix A: Sample Programs](appendices/appendix-A.md)** - Complete example programs
- **[Appendix B: Managing Addressing](appendices/appendix-B.md)** - Memory addressing techniques
- **[Appendix C: Improving Performance](appendices/appendix-C.md)** - Performance optimization tips
- **[Appendix D: ASCII Character Set](appendices/appendix-D.md)** - ASCII character reference
- **[Appendix E: File Names and TACL](appendices/appendix-E.md)** - File naming conventions and TACL commands
- **[Appendix F: Data Type Correspondence](appendices/appendix-F.md)** - Data type mappings between languages

---

## Reference Materials

- **[Glossary](glossary.md)** - Comprehensive glossary of TAL programming terms and definitions
- **[Index](index.md)** - Complete alphabetical index of topics, keywords, and concepts

---

## About TAL

TAL (Transaction Application Language) is most often used for:

- **Systems Software**: Operating system components, compilers, interpreters, command interpreters, special subsystems
- **Transaction-Oriented Applications**: Server processes, data management software, high-performance applications
- **Special Routines**: Data communication activities, conversion routines, callable procedures from other languages

Many Tandem software products were written in TAL, making it a critical language for the Tandem NonStop ecosystem.

---

## Source

This documentation was extracted from the original PDF manual published by Tandem Computers Incorporated in September 1993.
